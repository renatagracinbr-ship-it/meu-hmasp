var Dc=Object.defineProperty;var Rc=(t,e,n)=>e in t?Dc(t,e,{enumerable:!0,configurable:!0,writable:!0,value:n}):t[e]=n;var Is=(t,e,n)=>Rc(t,typeof e!="symbol"?e+"":e,n);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))o(r);new MutationObserver(r=>{for(const a of r)if(a.type==="childList")for(const l of a.addedNodes)l.tagName==="LINK"&&l.rel==="modulepreload"&&o(l)}).observe(document,{childList:!0,subtree:!0});function n(r){const a={};return r.integrity&&(a.integrity=r.integrity),r.referrerPolicy&&(a.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?a.credentials="include":r.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function o(r){if(r.ep)return;r.ep=!0;const a=n(r);fetch(r.href,a)}})();const he=class he{static now(){return new Date(new Date().toLocaleString("en-US",{timeZone:he.TIMEZONE}))}static format(e){if(!e)return"";const n=new Date(e),o=String(n.getDate()).padStart(2,"0"),r=String(n.getMonth()+1).padStart(2,"0"),a=n.getFullYear(),l=String(n.getHours()).padStart(2,"0"),d=String(n.getMinutes()).padStart(2,"0");return`${o}/${r}/${a} ${l}:${d}`}static formatDate(e){if(!e)return"";const n=new Date(e),o=String(n.getDate()).padStart(2,"0"),r=String(n.getMonth()+1).padStart(2,"0"),a=n.getFullYear();return`${o}/${r}/${a}`}static formatTime(e){if(!e)return"";const n=new Date(e),o=String(n.getHours()).padStart(2,"0"),r=String(n.getMinutes()).padStart(2,"0");return`${o}:${r}`}static parse(e){if(!e)return null;const n=/^(\d{2})\/(\d{2})\/(\d{4})\s+(\d{2}):(\d{2})$/,o=e.match(n);if(!o)return null;const[,r,a,l,d,p]=o;return new Date(l,a-1,r,d,p)}static addMinutes(e,n){const o=new Date(e);return o.setMinutes(o.getMinutes()+n),o}static addHours(e,n){const o=new Date(e);return o.setHours(o.getHours()+n),o}static addDays(e,n){const o=new Date(e);return o.setDate(o.getDate()+n),o}static diffInMinutes(e,n){const o=Math.abs(new Date(e)-new Date(n));return Math.floor(o/6e4)}static diffInHours(e,n){return Math.floor(he.diffInMinutes(e,n)/60)}static isPast(e){return new Date(e)<he.now()}static isFuture(e){return new Date(e)>he.now()}static toISOString(e=null){return(e?new Date(e):he.now()).toISOString()}static formatRelative(e){const n=he.now(),o=new Date(e)-n,r=Math.floor(Math.abs(o)/6e4),a=Math.floor(r/60),l=Math.floor(a/24),p=o<0?"há":"em";return r<1?"agora":r<60?`${p} ${r} minuto${r>1?"s":""}`:a<24?`${p} ${a} hora${a>1?"s":""}`:l<7?`${p} ${l} dia${l>1?"s":""}`:he.formatDate(e)}};Is(he,"TIMEZONE","America/Sao_Paulo"),Is(he,"DISPLAY_FORMAT","dd/MM/yyyy HH:mm");let Rn=he;class ue{static normalize(e){if(!e)return{normalized:null,valid:!1,type:"invalid"};let n=e.toString().replace(/\D/g,"");if(n=n.replace(/^0+/,""),n.startsWith("55")&&(n=n.substring(2)),n.length<10)return{normalized:null,valid:!1,type:"invalid"};const o=n.substring(0,2);if(!["11","12","13","14","15","16","17","18","19","21","22","24","27","28","31","32","33","34","35","37","38","41","42","43","44","45","46","47","48","49","51","53","54","55","61","62","64","63","65","66","67","68","69","71","73","74","75","77","79","81","87","82","83","84","85","88","86","89","91","93","94","92","97","95","96","98","99"].includes(o))return{normalized:null,valid:!1,type:"invalid"};let a=n.substring(2),l="landline";if(a.length===9){if(!a.startsWith("9"))return{normalized:null,valid:!1,type:"invalid"};l="mobile"}else if(a.length===8){const p=a.charAt(0);["6","7","8","9"].includes(p)?(a="9"+a,l="mobile"):l="landline"}else if(a.length===10&&a.startsWith("9"))a=a.substring(2),l="mobile";else return{normalized:null,valid:!1,type:"invalid"};return{normalized:`+55${o}${a}`,valid:!0,type:l,ddd:o,number:a}}static normalizeMultiple(e){if(!Array.isArray(e)||e.length===0)return[];const n=[],o=new Set,r={Celular:1,Adicional:2,Fixo:3},a=e.sort((l,d)=>(r[l.type]||99)-(r[d.type]||99));for(const l of a){const d=ue.normalize(l.number);d.valid&&!o.has(d.normalized)&&(o.add(d.normalized),n.push({original:l.number,normalized:d.normalized,type:l.type,phoneType:d.type,ddd:d.ddd,number:d.number}))}return n}static formatForDisplay(e){if(!e||!e.startsWith("+55"))return e;const n=e.replace("+55",""),o=n.substring(0,2),r=n.substring(2);return r.length===9?`(${o}) ${r.substring(0,5)}-${r.substring(5)}`:r.length===8?`(${o}) ${r.substring(0,4)}-${r.substring(4)}`:e}static isWhatsAppValid(e){const n=ue.normalize(e);return n.valid&&n.type==="mobile"}}const js={WHATSAPP_BACKEND:window.location.hostname==="localhost"?"http://localhost:3000":`${window.location.protocol}//${window.location.host}`,AGHUSE_BACKEND:window.location.hostname==="localhost"?"http://localhost:3000":`${window.location.protocol}//${window.location.host}`,DATABASE_BACKEND:window.location.hostname==="localhost"?"http://localhost:3000":`${window.location.protocol}//${window.location.host}`},kc="hmasp_auth_session";function Vs(){try{const t=localStorage.getItem(kc);return t?JSON.parse(t):null}catch(t){return console.error("[Auth] Erro ao ler sessão:",t),null}}function Pc(){const t=Vs();return t?t.user:null}const ot=js.WHATSAPP_BACKEND;async function qs(){try{return await(await fetch(`${ot}/api/status`)).json()}catch(t){return console.error("[WhatsApp] Erro ao verificar status:",t),{isReady:!1,hasQr:!1}}}async function Nc(){try{return await(await fetch(`${ot}/api/qr`)).json()}catch(t){throw console.error("[WhatsApp] Erro ao obter QR Code:",t),t}}async function Ti(){try{const e=await(await fetch(`${ot}/api/chats`)).json();return e.success?e.chats:(console.warn("[WhatsApp] WhatsApp não está conectado:",e.error),[])}catch(t){return console.error("[WhatsApp] Erro ao buscar chats:",t),[]}}async function Mc(t,e=50){try{const o=await(await fetch(`${ot}/api/messages/${t}?limit=${e}`)).json();return o.success?o.messages:(console.warn("[WhatsApp] Erro ao buscar mensagens:",o.error),[])}catch(n){return console.error("[WhatsApp] Erro ao buscar mensagens:",n),[]}}async function Ai(t,e,n=null){try{const o={to:t,message:e};n&&n.length>0&&(o.buttons=n);const a=await(await fetch(`${ot}/api/send`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(o)})).json();if(!a.success)throw new Error(a.error);return a}catch(o){throw console.error("[WhatsApp] Erro ao enviar mensagem:",o),o}}async function Oc(t){try{return await(await fetch(`${ot}/api/read/${t}`,{method:"POST"})).json()}catch(e){throw console.error("[WhatsApp] Erro ao marcar como lido:",e),e}}async function Lc(t,e){try{return console.log(`[WhatsApp] Enviando estado "${e}" para ${t}`),{success:!0}}catch(n){return console.error("[WhatsApp] Erro ao enviar estado do chat:",n),{success:!1}}}async function $c(){try{return await(await fetch(`${ot}/api/logout`,{method:"POST"})).json()}catch(t){throw console.error("[WhatsApp] Erro ao fazer logout:",t),t}}let Ft=null;function Bc(t,e=5e3){Ft&&Si(),Ft=setInterval(async()=>{try{if((await qs()).isReady){const o=await Ti();t(o)}}catch(n){console.error("[Polling] Erro:",n)}},e)}function Si(){Ft&&(clearInterval(Ft),Ft=null)}const Wt=`${js.AGHUSE_BACKEND}/api`;console.log("[AGHUse] Usando backend:",Wt);async function Ci(){try{return await(await fetch(`${Wt}/aghuse/test-connection`)).json()}catch(t){return console.error("[AGHUse Client] Erro ao testar conexão:",t),{success:!1,error:t.message}}}async function xc(t=5){try{const n=await(await fetch(`${Wt}/aghuse/recent-appointments?minutes=${t}`)).json();if(!n.success)throw new Error(n.error);return n.appointments.map(o=>zs(o))}catch(e){throw console.error("[AGHUse Client] Erro ao buscar consultas:",e),e}}function zs(t){console.log(`[AGHUse] Consulta ${t.consulta_numero} - Telefones brutos:`,{celular:t.telefone_celular,fixo:t.telefone_fixo,recado:t.telefone_adicional});const n=[{type:"Celular",number:t.telefone_celular},{type:"Fixo",number:t.telefone_fixo},{type:"Recado",number:t.telefone_adicional}].filter(D=>D.number).map(D=>{const R=Fc(D.number);return console.log(`[AGHUse] Telefone ${D.number} -> Tipo: ${R?"mobile":"landline"}`),{original:D.number,normalized:Uc(D.number),type:D.type,phoneType:R?"mobile":"landline"}}).filter(D=>D.normalized);console.log(`[AGHUse] Consulta ${t.consulta_numero} - Telefones normalizados:`,n);const o=t.nome_paciente||"",r=o.trim().split(" ").filter(D=>D),a=r[0]||"",l=r.length>1?r[r.length-1]:"",d=l?`${a} ${l}`:a,p=new Date(t.data_hora_consulta),w=p.toLocaleDateString("pt-BR",{day:"2-digit",month:"2-digit",year:"numeric",timeZone:"America/Sao_Paulo"}),A=p.toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit",timeZone:"America/Sao_Paulo"});return{consultaNumero:t.consulta_numero,pacCodigo:t.pac_codigo,prontuario:t.prontuario,cpf:t.cpf_paciente||null,nomeCompleto:o,nomeExibicao:d,primeiroNome:a,ultimoNome:l,telefones:n,telefonesPrincipais:n.map(D=>D.normalized),especialidade:t.especialidade||"Não informada",dataConsulta:p,dataFormatada:w,horaFormatada:A,dataHoraFormatada:`${w} ${A}`,profissional:t.profissional_nome||"Não informado",local:t.local_descricao||"Não informado",dataMarcacao:t.data_hora_marcacao?new Date(t.data_hora_marcacao):null,situacao:t.situacao_codigo,situacaoDescricao:t.situacao_descricao}}function Uc(t){if(!t)return null;let e=t.toString().replace(/\D/g,"");return e=e.replace(/^0+/,""),e.startsWith("55")&&(e=e.substring(2)),e.length===9&&e.startsWith("9")&&(e="11"+e,console.log("[AGHUse] Telefone sem DDD detectado, adicionado DDD 11:",e)),e.length===8&&(e="11"+e,console.log("[AGHUse] Telefone fixo sem DDD detectado, adicionado DDD 11:",e)),e.length<10?(console.warn("[AGHUse] Telefone inválido (menos de 10 dígitos):",e),null):`+55${e}`}function Fc(t){const e=(t||"").replace(/\D/g,"");return e.length===9&&e.charAt(0)==="9"||e.length===11&&e.charAt(2)==="9"}async function Hc(t=60){try{const n=await(await fetch(`${Wt}/aghuse/cancelled-appointments?minutes=${t}`)).json();if(!n.success)throw new Error(n.error);return n.appointments.map(o=>zs(o))}catch(e){throw console.error("[AGHUse Client] Erro ao buscar consultas desmarcadas:",e),e}}async function jc(){try{const e=await(await fetch(`${Wt}/aghuse/appointments-72h`)).json();if(!e.success)throw new Error(e.error);return e.appointments.map(n=>zs(n))}catch(t){throw console.error("[AGHUse Client] Erro ao buscar consultas 72h:",t),t}}const Vc={MARCACAO_CONFIRMACAO:{id:"marcacao_confirmacao",categoria:"UTILITY",idioma:"pt_BR",texto:(t,e,n,o)=>{const r=n.split(" "),a=r[0],l=r[1];return`Olá, ${t}. Aqui é a Central de Marcação de Consultas do HMASP. Consta consulta de *${e}* em *${a}*, às *${l} h*, com o Dr(a) ${o}. Por gentileza, confirme sua presença.`},botoes:[{id:"confirmar",text:"✅ Confirmo presença"},{id:"nao_poderei",text:"❌ Não poderei comparecer"},{id:"nao_agendei",text:"⚠️ Não agendei essa consulta"}]},LEMBRETE_72H:{id:"lembrete_72h",categoria:"UTILITY",idioma:"pt_BR",texto:(t,e,n,o)=>`Olá, ${t}. Este é um lembrete da sua consulta de ${n} em ${e}, no ${o}. Por favor, confirme sua presença usando os botões abaixo.`,botoes:[{id:"confirmar",text:"Confirmo presença"},{id:"nao_poderei",text:"Não poderei ir"}]},RESPOSTA_CONFIRMADO:{id:"resposta_confirmado",categoria:"UTILITY",idioma:"pt_BR",texto:t=>`Presença confirmada, ${t}. Por favor, chegue com 15 minutos de antecedência. Em caso de imprevistos, contate a Central. Agradecemos.`,botoes:[]},RESPOSTA_NAO_PODEREI:{id:"resposta_nao_poderei",categoria:"UTILITY",idioma:"pt_BR",texto:t=>`Obrigado pelo aviso, ${t}. Para remarcar, procure o balcão da Central de Marcação de Consultas do HMASP, utilize o EB Saúde ou ligue para nosso telefone de atendimento. Estamos à disposição.`,botoes:[]},LEMBRETE_SEM_RESPOSTA:{id:"lembrete_sem_resposta",categoria:"UTILITY",idioma:"pt_BR",texto:(t,e,n,o)=>`${t}, ainda não recebemos sua confirmação. Lembramos que sua consulta de ${n} está marcada para ${e}, no ${o}. Por favor, confirme sua presença.`,botoes:[{id:"confirmar",text:"Confirmo presença"},{id:"nao_poderei",text:"Não poderei ir"}]}},Ps={PENDING:"pending",FAILED:"failed"};function qc(t,e){const n=Object.values(Vc).find(r=>r.id===t);if(!n)throw new Error(`Template não encontrado: ${t}`);let o="";switch(t){case"marcacao_confirmacao":o=n.texto(e.nomePaciente,e.especialidade,e.dataHora,e.medico);break;case"lembrete_72h":case"lembrete_sem_resposta":o=n.texto(e.nomePaciente,e.dataHora,e.especialidade,e.local);break;case"resposta_confirmado":case"resposta_nao_poderei":o=n.texto(e.nomePaciente);break;default:throw new Error(`Template não suportado: ${t}`)}return{templateId:n.id,categoria:n.categoria,idioma:n.idioma,texto:o,botoes:n.botoes}}function Di(t){return`${t.replace("+","")}@c.us`}function yr(t){return{consultaNumero:t.consultaNumero,pacCodigo:t.pacCodigo,telefone:t.telefone,telefoneType:t.telefoneType,templateId:t.templateId,status:t.status,messageId:t.messageId||null,timestamp:new Date().toISOString(),botaoClicado:t.botaoClicado||null,timestampResposta:t.timestampResposta||null,tentativa:t.tentativa||1,erro:t.erro||null}}var _r={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ri=function(t){const e=[];let n=0;for(let o=0;o<t.length;o++){let r=t.charCodeAt(o);r<128?e[n++]=r:r<2048?(e[n++]=r>>6|192,e[n++]=r&63|128):(r&64512)===55296&&o+1<t.length&&(t.charCodeAt(o+1)&64512)===56320?(r=65536+((r&1023)<<10)+(t.charCodeAt(++o)&1023),e[n++]=r>>18|240,e[n++]=r>>12&63|128,e[n++]=r>>6&63|128,e[n++]=r&63|128):(e[n++]=r>>12|224,e[n++]=r>>6&63|128,e[n++]=r&63|128)}return e},zc=function(t){const e=[];let n=0,o=0;for(;n<t.length;){const r=t[n++];if(r<128)e[o++]=String.fromCharCode(r);else if(r>191&&r<224){const a=t[n++];e[o++]=String.fromCharCode((r&31)<<6|a&63)}else if(r>239&&r<365){const a=t[n++],l=t[n++],d=t[n++],p=((r&7)<<18|(a&63)<<12|(l&63)<<6|d&63)-65536;e[o++]=String.fromCharCode(55296+(p>>10)),e[o++]=String.fromCharCode(56320+(p&1023))}else{const a=t[n++],l=t[n++];e[o++]=String.fromCharCode((r&15)<<12|(a&63)<<6|l&63)}}return e.join("")},ki={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(t,e){if(!Array.isArray(t))throw Error("encodeByteArray takes an array as a parameter");this.init_();const n=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,o=[];for(let r=0;r<t.length;r+=3){const a=t[r],l=r+1<t.length,d=l?t[r+1]:0,p=r+2<t.length,w=p?t[r+2]:0,A=a>>2,D=(a&3)<<4|d>>4;let R=(d&15)<<2|w>>6,H=w&63;p||(H=64,l||(R=64)),o.push(n[A],n[D],n[R],n[H])}return o.join("")},encodeString(t,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(t):this.encodeByteArray(Ri(t),e)},decodeString(t,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(t):zc(this.decodeStringToByteArray(t,e))},decodeStringToByteArray(t,e){this.init_();const n=e?this.charToByteMapWebSafe_:this.charToByteMap_,o=[];for(let r=0;r<t.length;){const a=n[t.charAt(r++)],d=r<t.length?n[t.charAt(r)]:0;++r;const w=r<t.length?n[t.charAt(r)]:64;++r;const D=r<t.length?n[t.charAt(r)]:64;if(++r,a==null||d==null||w==null||D==null)throw new Wc;const R=a<<2|d>>4;if(o.push(R),w!==64){const H=d<<4&240|w>>2;if(o.push(H),D!==64){const N=w<<6&192|D;o.push(N)}}}return o},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let t=0;t<this.ENCODED_VALS.length;t++)this.byteToCharMap_[t]=this.ENCODED_VALS.charAt(t),this.charToByteMap_[this.byteToCharMap_[t]]=t,this.byteToCharMapWebSafe_[t]=this.ENCODED_VALS_WEBSAFE.charAt(t),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[t]]=t,t>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(t)]=t,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(t)]=t)}}};class Wc extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const Gc=function(t){const e=Ri(t);return ki.encodeByteArray(e,!0)},kn=function(t){return Gc(t).replace(/\./g,"")},Pi=function(t){try{return ki.decodeString(t,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Kc(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Jc=()=>Kc().__FIREBASE_DEFAULTS__,Xc=()=>{if(typeof process>"u"||typeof _r>"u")return;const t=_r.__FIREBASE_DEFAULTS__;if(t)return JSON.parse(t)},Yc=()=>{if(typeof document>"u")return;let t;try{t=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=t&&Pi(t[1]);return e&&JSON.parse(e)},Ws=()=>{try{return Jc()||Xc()||Yc()}catch(t){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${t}`);return}},Ni=t=>{var e,n;return(n=(e=Ws())===null||e===void 0?void 0:e.emulatorHosts)===null||n===void 0?void 0:n[t]},Mi=t=>{const e=Ni(t);if(!e)return;const n=e.lastIndexOf(":");if(n<=0||n+1===e.length)throw new Error(`Invalid host ${e} with no separate hostname and port!`);const o=parseInt(e.substring(n+1),10);return e[0]==="["?[e.substring(1,n-1),o]:[e.substring(0,n),o]},Oi=()=>{var t;return(t=Ws())===null||t===void 0?void 0:t.config},Li=t=>{var e;return(e=Ws())===null||e===void 0?void 0:e[`_${t}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qc{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,n)=>{this.resolve=e,this.reject=n})}wrapCallback(e){return(n,o)=>{n?this.reject(n):this.resolve(o),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(n):e(n,o))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $i(t,e){if(t.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const n={alg:"none",type:"JWT"},o=e||"demo-project",r=t.iat||0,a=t.sub||t.user_id;if(!a)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const l=Object.assign({iss:`https://securetoken.google.com/${o}`,aud:o,iat:r,exp:r+3600,auth_time:r,sub:a,user_id:a,firebase:{sign_in_provider:"custom",identities:{}}},t);return[kn(JSON.stringify(n)),kn(JSON.stringify(l)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function oe(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function Zc(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(oe())}function el(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function tl(){const t=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof t=="object"&&t.id!==void 0}function nl(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function sl(){const t=oe();return t.indexOf("MSIE ")>=0||t.indexOf("Trident/")>=0}function ol(){try{return typeof indexedDB=="object"}catch{return!1}}function rl(){return new Promise((t,e)=>{try{let n=!0;const o="validate-browser-context-for-indexeddb-analytics-module",r=self.indexedDB.open(o);r.onsuccess=()=>{r.result.close(),n||self.indexedDB.deleteDatabase(o),t(!0)},r.onupgradeneeded=()=>{n=!1},r.onerror=()=>{var a;e(((a=r.error)===null||a===void 0?void 0:a.message)||"")}}catch(n){e(n)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const il="FirebaseError";class Ee extends Error{constructor(e,n,o){super(n),this.code=e,this.customData=o,this.name=il,Object.setPrototypeOf(this,Ee.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Gt.prototype.create)}}class Gt{constructor(e,n,o){this.service=e,this.serviceName=n,this.errors=o}create(e,...n){const o=n[0]||{},r=`${this.service}/${e}`,a=this.errors[e],l=a?al(a,o):"Error",d=`${this.serviceName}: ${l} (${r}).`;return new Ee(r,d,o)}}function al(t,e){return t.replace(cl,(n,o)=>{const r=e[o];return r!=null?String(r):`<${o}?>`})}const cl=/\{\$([^}]+)}/g;function ll(t){for(const e in t)if(Object.prototype.hasOwnProperty.call(t,e))return!1;return!0}function Pn(t,e){if(t===e)return!0;const n=Object.keys(t),o=Object.keys(e);for(const r of n){if(!o.includes(r))return!1;const a=t[r],l=e[r];if(Er(a)&&Er(l)){if(!Pn(a,l))return!1}else if(a!==l)return!1}for(const r of o)if(!n.includes(r))return!1;return!0}function Er(t){return t!==null&&typeof t=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Kt(t){const e=[];for(const[n,o]of Object.entries(t))Array.isArray(o)?o.forEach(r=>{e.push(encodeURIComponent(n)+"="+encodeURIComponent(r))}):e.push(encodeURIComponent(n)+"="+encodeURIComponent(o));return e.length?"&"+e.join("&"):""}function ul(t,e){const n=new dl(t,e);return n.subscribe.bind(n)}class dl{constructor(e,n){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=n,this.task.then(()=>{e(this)}).catch(o=>{this.error(o)})}next(e){this.forEachObserver(n=>{n.next(e)})}error(e){this.forEachObserver(n=>{n.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,n,o){let r;if(e===void 0&&n===void 0&&o===void 0)throw new Error("Missing Observer.");hl(e,["next","error","complete"])?r=e:r={next:e,error:n,complete:o},r.next===void 0&&(r.next=ws),r.error===void 0&&(r.error=ws),r.complete===void 0&&(r.complete=ws);const a=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?r.error(this.finalError):r.complete()}catch{}}),this.observers.push(r),a}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let n=0;n<this.observers.length;n++)this.sendOne(n,e)}sendOne(e,n){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{n(this.observers[e])}catch(o){typeof console<"u"&&console.error&&console.error(o)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function hl(t,e){if(typeof t!="object"||t===null)return!1;for(const n of e)if(n in t&&typeof t[n]=="function")return!0;return!1}function ws(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function rt(t){return t&&t._delegate?t._delegate:t}class Ge{constructor(e,n,o){this.name=e,this.instanceFactory=n,this.type=o,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qe="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fl{constructor(e,n){this.name=e,this.container=n,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const n=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(n)){const o=new Qc;if(this.instancesDeferred.set(n,o),this.isInitialized(n)||this.shouldAutoInitialize())try{const r=this.getOrInitializeService({instanceIdentifier:n});r&&o.resolve(r)}catch{}}return this.instancesDeferred.get(n).promise}getImmediate(e){var n;const o=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),r=(n=e==null?void 0:e.optional)!==null&&n!==void 0?n:!1;if(this.isInitialized(o)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:o})}catch(a){if(r)return null;throw a}else{if(r)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(pl(e))try{this.getOrInitializeService({instanceIdentifier:Qe})}catch{}for(const[n,o]of this.instancesDeferred.entries()){const r=this.normalizeInstanceIdentifier(n);try{const a=this.getOrInitializeService({instanceIdentifier:r});o.resolve(a)}catch{}}}}clearInstance(e=Qe){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(n=>"INTERNAL"in n).map(n=>n.INTERNAL.delete()),...e.filter(n=>"_delete"in n).map(n=>n._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=Qe){return this.instances.has(e)}getOptions(e=Qe){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:n={}}=e,o=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(o))throw Error(`${this.name}(${o}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const r=this.getOrInitializeService({instanceIdentifier:o,options:n});for(const[a,l]of this.instancesDeferred.entries()){const d=this.normalizeInstanceIdentifier(a);o===d&&l.resolve(r)}return r}onInit(e,n){var o;const r=this.normalizeInstanceIdentifier(n),a=(o=this.onInitCallbacks.get(r))!==null&&o!==void 0?o:new Set;a.add(e),this.onInitCallbacks.set(r,a);const l=this.instances.get(r);return l&&e(l,r),()=>{a.delete(e)}}invokeOnInitCallbacks(e,n){const o=this.onInitCallbacks.get(n);if(o)for(const r of o)try{r(e,n)}catch{}}getOrInitializeService({instanceIdentifier:e,options:n={}}){let o=this.instances.get(e);if(!o&&this.component&&(o=this.component.instanceFactory(this.container,{instanceIdentifier:ml(e),options:n}),this.instances.set(e,o),this.instancesOptions.set(e,n),this.invokeOnInitCallbacks(o,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,o)}catch{}return o||null}normalizeInstanceIdentifier(e=Qe){return this.component?this.component.multipleInstances?e:Qe:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function ml(t){return t===Qe?void 0:t}function pl(t){return t.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gl{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const n=this.getProvider(e.name);if(n.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);n.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const n=new fl(e,this);return this.providers.set(e,n),n}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var x;(function(t){t[t.DEBUG=0]="DEBUG",t[t.VERBOSE=1]="VERBOSE",t[t.INFO=2]="INFO",t[t.WARN=3]="WARN",t[t.ERROR=4]="ERROR",t[t.SILENT=5]="SILENT"})(x||(x={}));const vl={debug:x.DEBUG,verbose:x.VERBOSE,info:x.INFO,warn:x.WARN,error:x.ERROR,silent:x.SILENT},yl=x.INFO,_l={[x.DEBUG]:"log",[x.VERBOSE]:"log",[x.INFO]:"info",[x.WARN]:"warn",[x.ERROR]:"error"},El=(t,e,...n)=>{if(e<t.logLevel)return;const o=new Date().toISOString(),r=_l[e];if(r)console[r](`[${o}]  ${t.name}:`,...n);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Gs{constructor(e){this.name=e,this._logLevel=yl,this._logHandler=El,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in x))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?vl[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,x.DEBUG,...e),this._logHandler(this,x.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,x.VERBOSE,...e),this._logHandler(this,x.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,x.INFO,...e),this._logHandler(this,x.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,x.WARN,...e),this._logHandler(this,x.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,x.ERROR,...e),this._logHandler(this,x.ERROR,...e)}}const Il=(t,e)=>e.some(n=>t instanceof n);let Ir,wr;function wl(){return Ir||(Ir=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function bl(){return wr||(wr=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const Bi=new WeakMap,Ns=new WeakMap,xi=new WeakMap,bs=new WeakMap,Ks=new WeakMap;function Tl(t){const e=new Promise((n,o)=>{const r=()=>{t.removeEventListener("success",a),t.removeEventListener("error",l)},a=()=>{n(ze(t.result)),r()},l=()=>{o(t.error),r()};t.addEventListener("success",a),t.addEventListener("error",l)});return e.then(n=>{n instanceof IDBCursor&&Bi.set(n,t)}).catch(()=>{}),Ks.set(e,t),e}function Al(t){if(Ns.has(t))return;const e=new Promise((n,o)=>{const r=()=>{t.removeEventListener("complete",a),t.removeEventListener("error",l),t.removeEventListener("abort",l)},a=()=>{n(),r()},l=()=>{o(t.error||new DOMException("AbortError","AbortError")),r()};t.addEventListener("complete",a),t.addEventListener("error",l),t.addEventListener("abort",l)});Ns.set(t,e)}let Ms={get(t,e,n){if(t instanceof IDBTransaction){if(e==="done")return Ns.get(t);if(e==="objectStoreNames")return t.objectStoreNames||xi.get(t);if(e==="store")return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return ze(t[e])},set(t,e,n){return t[e]=n,!0},has(t,e){return t instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in t}};function Sl(t){Ms=t(Ms)}function Cl(t){return t===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...n){const o=t.call(Ts(this),e,...n);return xi.set(o,e.sort?e.sort():[e]),ze(o)}:bl().includes(t)?function(...e){return t.apply(Ts(this),e),ze(Bi.get(this))}:function(...e){return ze(t.apply(Ts(this),e))}}function Dl(t){return typeof t=="function"?Cl(t):(t instanceof IDBTransaction&&Al(t),Il(t,wl())?new Proxy(t,Ms):t)}function ze(t){if(t instanceof IDBRequest)return Tl(t);if(bs.has(t))return bs.get(t);const e=Dl(t);return e!==t&&(bs.set(t,e),Ks.set(e,t)),e}const Ts=t=>Ks.get(t);function Rl(t,e,{blocked:n,upgrade:o,blocking:r,terminated:a}={}){const l=indexedDB.open(t,e),d=ze(l);return o&&l.addEventListener("upgradeneeded",p=>{o(ze(l.result),p.oldVersion,p.newVersion,ze(l.transaction),p)}),n&&l.addEventListener("blocked",p=>n(p.oldVersion,p.newVersion,p)),d.then(p=>{a&&p.addEventListener("close",()=>a()),r&&p.addEventListener("versionchange",w=>r(w.oldVersion,w.newVersion,w))}).catch(()=>{}),d}const kl=["get","getKey","getAll","getAllKeys","count"],Pl=["put","add","delete","clear"],As=new Map;function br(t,e){if(!(t instanceof IDBDatabase&&!(e in t)&&typeof e=="string"))return;if(As.get(e))return As.get(e);const n=e.replace(/FromIndex$/,""),o=e!==n,r=Pl.includes(n);if(!(n in(o?IDBIndex:IDBObjectStore).prototype)||!(r||kl.includes(n)))return;const a=async function(l,...d){const p=this.transaction(l,r?"readwrite":"readonly");let w=p.store;return o&&(w=w.index(d.shift())),(await Promise.all([w[n](...d),r&&p.done]))[0]};return As.set(e,a),a}Sl(t=>({...t,get:(e,n,o)=>br(e,n)||t.get(e,n,o),has:(e,n)=>!!br(e,n)||t.has(e,n)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nl{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(n=>{if(Ml(n)){const o=n.getImmediate();return`${o.library}/${o.version}`}else return null}).filter(n=>n).join(" ")}}function Ml(t){const e=t.getComponent();return(e==null?void 0:e.type)==="VERSION"}const Os="@firebase/app",Tr="0.10.13";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ke=new Gs("@firebase/app"),Ol="@firebase/app-compat",Ll="@firebase/analytics-compat",$l="@firebase/analytics",Bl="@firebase/app-check-compat",xl="@firebase/app-check",Ul="@firebase/auth",Fl="@firebase/auth-compat",Hl="@firebase/database",jl="@firebase/data-connect",Vl="@firebase/database-compat",ql="@firebase/functions",zl="@firebase/functions-compat",Wl="@firebase/installations",Gl="@firebase/installations-compat",Kl="@firebase/messaging",Jl="@firebase/messaging-compat",Xl="@firebase/performance",Yl="@firebase/performance-compat",Ql="@firebase/remote-config",Zl="@firebase/remote-config-compat",eu="@firebase/storage",tu="@firebase/storage-compat",nu="@firebase/firestore",su="@firebase/vertexai-preview",ou="@firebase/firestore-compat",ru="firebase",iu="10.14.1";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ls="[DEFAULT]",au={[Os]:"fire-core",[Ol]:"fire-core-compat",[$l]:"fire-analytics",[Ll]:"fire-analytics-compat",[xl]:"fire-app-check",[Bl]:"fire-app-check-compat",[Ul]:"fire-auth",[Fl]:"fire-auth-compat",[Hl]:"fire-rtdb",[jl]:"fire-data-connect",[Vl]:"fire-rtdb-compat",[ql]:"fire-fn",[zl]:"fire-fn-compat",[Wl]:"fire-iid",[Gl]:"fire-iid-compat",[Kl]:"fire-fcm",[Jl]:"fire-fcm-compat",[Xl]:"fire-perf",[Yl]:"fire-perf-compat",[Ql]:"fire-rc",[Zl]:"fire-rc-compat",[eu]:"fire-gcs",[tu]:"fire-gcs-compat",[nu]:"fire-fst",[ou]:"fire-fst-compat",[su]:"fire-vertex","fire-js":"fire-js",[ru]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Nn=new Map,cu=new Map,$s=new Map;function Ar(t,e){try{t.container.addComponent(e)}catch(n){ke.debug(`Component ${e.name} failed to register with FirebaseApp ${t.name}`,n)}}function tt(t){const e=t.name;if($s.has(e))return ke.debug(`There were multiple attempts to register component ${e}.`),!1;$s.set(e,t);for(const n of Nn.values())Ar(n,t);for(const n of cu.values())Ar(n,t);return!0}function qn(t,e){const n=t.container.getProvider("heartbeat").getImmediate({optional:!0});return n&&n.triggerHeartbeat(),t.container.getProvider(e)}function qe(t){return t.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lu={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},We=new Gt("app","Firebase",lu);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uu{constructor(e,n,o){this._isDeleted=!1,this._options=Object.assign({},e),this._config=Object.assign({},n),this._name=n.name,this._automaticDataCollectionEnabled=n.automaticDataCollectionEnabled,this._container=o,this.container.addComponent(new Ge("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw We.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const it=iu;function Ui(t,e={}){let n=t;typeof e!="object"&&(e={name:e});const o=Object.assign({name:Ls,automaticDataCollectionEnabled:!1},e),r=o.name;if(typeof r!="string"||!r)throw We.create("bad-app-name",{appName:String(r)});if(n||(n=Oi()),!n)throw We.create("no-options");const a=Nn.get(r);if(a){if(Pn(n,a.options)&&Pn(o,a.config))return a;throw We.create("duplicate-app",{appName:r})}const l=new gl(r);for(const p of $s.values())l.addComponent(p);const d=new uu(n,o,l);return Nn.set(r,d),d}function Js(t=Ls){const e=Nn.get(t);if(!e&&t===Ls&&Oi())return Ui();if(!e)throw We.create("no-app",{appName:t});return e}function pe(t,e,n){var o;let r=(o=au[t])!==null&&o!==void 0?o:t;n&&(r+=`-${n}`);const a=r.match(/\s|\//),l=e.match(/\s|\//);if(a||l){const d=[`Unable to register library "${r}" with version "${e}":`];a&&d.push(`library name "${r}" contains illegal characters (whitespace or "/")`),a&&l&&d.push("and"),l&&d.push(`version name "${e}" contains illegal characters (whitespace or "/")`),ke.warn(d.join(" "));return}tt(new Ge(`${r}-version`,()=>({library:r,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const du="firebase-heartbeat-database",hu=1,qt="firebase-heartbeat-store";let Ss=null;function Fi(){return Ss||(Ss=Rl(du,hu,{upgrade:(t,e)=>{switch(e){case 0:try{t.createObjectStore(qt)}catch(n){console.warn(n)}}}}).catch(t=>{throw We.create("idb-open",{originalErrorMessage:t.message})})),Ss}async function fu(t){try{const n=(await Fi()).transaction(qt),o=await n.objectStore(qt).get(Hi(t));return await n.done,o}catch(e){if(e instanceof Ee)ke.warn(e.message);else{const n=We.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});ke.warn(n.message)}}}async function Sr(t,e){try{const o=(await Fi()).transaction(qt,"readwrite");await o.objectStore(qt).put(e,Hi(t)),await o.done}catch(n){if(n instanceof Ee)ke.warn(n.message);else{const o=We.create("idb-set",{originalErrorMessage:n==null?void 0:n.message});ke.warn(o.message)}}}function Hi(t){return`${t.name}!${t.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mu=1024,pu=30*24*60*60*1e3;class gu{constructor(e){this.container=e,this._heartbeatsCache=null;const n=this.container.getProvider("app").getImmediate();this._storage=new yu(n),this._heartbeatsCachePromise=this._storage.read().then(o=>(this._heartbeatsCache=o,o))}async triggerHeartbeat(){var e,n;try{const r=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),a=Cr();return((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((n=this._heartbeatsCache)===null||n===void 0?void 0:n.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===a||this._heartbeatsCache.heartbeats.some(l=>l.date===a)?void 0:(this._heartbeatsCache.heartbeats.push({date:a,agent:r}),this._heartbeatsCache.heartbeats=this._heartbeatsCache.heartbeats.filter(l=>{const d=new Date(l.date).valueOf();return Date.now()-d<=pu}),this._storage.overwrite(this._heartbeatsCache))}catch(o){ke.warn(o)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const n=Cr(),{heartbeatsToSend:o,unsentEntries:r}=vu(this._heartbeatsCache.heartbeats),a=kn(JSON.stringify({version:2,heartbeats:o}));return this._heartbeatsCache.lastSentHeartbeatDate=n,r.length>0?(this._heartbeatsCache.heartbeats=r,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),a}catch(n){return ke.warn(n),""}}}function Cr(){return new Date().toISOString().substring(0,10)}function vu(t,e=mu){const n=[];let o=t.slice();for(const r of t){const a=n.find(l=>l.agent===r.agent);if(a){if(a.dates.push(r.date),Dr(n)>e){a.dates.pop();break}}else if(n.push({agent:r.agent,dates:[r.date]}),Dr(n)>e){n.pop();break}o=o.slice(1)}return{heartbeatsToSend:n,unsentEntries:o}}class yu{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return ol()?rl().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const n=await fu(this.app);return n!=null&&n.heartbeats?n:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){var n;if(await this._canUseIndexedDBPromise){const r=await this.read();return Sr(this.app,{lastSentHeartbeatDate:(n=e.lastSentHeartbeatDate)!==null&&n!==void 0?n:r.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){var n;if(await this._canUseIndexedDBPromise){const r=await this.read();return Sr(this.app,{lastSentHeartbeatDate:(n=e.lastSentHeartbeatDate)!==null&&n!==void 0?n:r.lastSentHeartbeatDate,heartbeats:[...r.heartbeats,...e.heartbeats]})}else return}}function Dr(t){return kn(JSON.stringify({version:2,heartbeats:t})).length}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _u(t){tt(new Ge("platform-logger",e=>new Nl(e),"PRIVATE")),tt(new Ge("heartbeat",e=>new gu(e),"PRIVATE")),pe(Os,Tr,t),pe(Os,Tr,"esm2017"),pe("fire-js","")}_u("");var Rr=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var ji;(function(){var t;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(y,h){function m(){}m.prototype=h.prototype,y.D=h.prototype,y.prototype=new m,y.prototype.constructor=y,y.C=function(g,v,E){for(var f=Array(arguments.length-2),be=2;be<arguments.length;be++)f[be-2]=arguments[be];return h.prototype[v].apply(g,f)}}function n(){this.blockSize=-1}function o(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.B=Array(this.blockSize),this.o=this.h=0,this.s()}e(o,n),o.prototype.s=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function r(y,h,m){m||(m=0);var g=Array(16);if(typeof h=="string")for(var v=0;16>v;++v)g[v]=h.charCodeAt(m++)|h.charCodeAt(m++)<<8|h.charCodeAt(m++)<<16|h.charCodeAt(m++)<<24;else for(v=0;16>v;++v)g[v]=h[m++]|h[m++]<<8|h[m++]<<16|h[m++]<<24;h=y.g[0],m=y.g[1],v=y.g[2];var E=y.g[3],f=h+(E^m&(v^E))+g[0]+3614090360&4294967295;h=m+(f<<7&4294967295|f>>>25),f=E+(v^h&(m^v))+g[1]+3905402710&4294967295,E=h+(f<<12&4294967295|f>>>20),f=v+(m^E&(h^m))+g[2]+606105819&4294967295,v=E+(f<<17&4294967295|f>>>15),f=m+(h^v&(E^h))+g[3]+3250441966&4294967295,m=v+(f<<22&4294967295|f>>>10),f=h+(E^m&(v^E))+g[4]+4118548399&4294967295,h=m+(f<<7&4294967295|f>>>25),f=E+(v^h&(m^v))+g[5]+1200080426&4294967295,E=h+(f<<12&4294967295|f>>>20),f=v+(m^E&(h^m))+g[6]+2821735955&4294967295,v=E+(f<<17&4294967295|f>>>15),f=m+(h^v&(E^h))+g[7]+4249261313&4294967295,m=v+(f<<22&4294967295|f>>>10),f=h+(E^m&(v^E))+g[8]+1770035416&4294967295,h=m+(f<<7&4294967295|f>>>25),f=E+(v^h&(m^v))+g[9]+2336552879&4294967295,E=h+(f<<12&4294967295|f>>>20),f=v+(m^E&(h^m))+g[10]+4294925233&4294967295,v=E+(f<<17&4294967295|f>>>15),f=m+(h^v&(E^h))+g[11]+2304563134&4294967295,m=v+(f<<22&4294967295|f>>>10),f=h+(E^m&(v^E))+g[12]+1804603682&4294967295,h=m+(f<<7&4294967295|f>>>25),f=E+(v^h&(m^v))+g[13]+4254626195&4294967295,E=h+(f<<12&4294967295|f>>>20),f=v+(m^E&(h^m))+g[14]+2792965006&4294967295,v=E+(f<<17&4294967295|f>>>15),f=m+(h^v&(E^h))+g[15]+1236535329&4294967295,m=v+(f<<22&4294967295|f>>>10),f=h+(v^E&(m^v))+g[1]+4129170786&4294967295,h=m+(f<<5&4294967295|f>>>27),f=E+(m^v&(h^m))+g[6]+3225465664&4294967295,E=h+(f<<9&4294967295|f>>>23),f=v+(h^m&(E^h))+g[11]+643717713&4294967295,v=E+(f<<14&4294967295|f>>>18),f=m+(E^h&(v^E))+g[0]+3921069994&4294967295,m=v+(f<<20&4294967295|f>>>12),f=h+(v^E&(m^v))+g[5]+3593408605&4294967295,h=m+(f<<5&4294967295|f>>>27),f=E+(m^v&(h^m))+g[10]+38016083&4294967295,E=h+(f<<9&4294967295|f>>>23),f=v+(h^m&(E^h))+g[15]+3634488961&4294967295,v=E+(f<<14&4294967295|f>>>18),f=m+(E^h&(v^E))+g[4]+3889429448&4294967295,m=v+(f<<20&4294967295|f>>>12),f=h+(v^E&(m^v))+g[9]+568446438&4294967295,h=m+(f<<5&4294967295|f>>>27),f=E+(m^v&(h^m))+g[14]+3275163606&4294967295,E=h+(f<<9&4294967295|f>>>23),f=v+(h^m&(E^h))+g[3]+4107603335&4294967295,v=E+(f<<14&4294967295|f>>>18),f=m+(E^h&(v^E))+g[8]+1163531501&4294967295,m=v+(f<<20&4294967295|f>>>12),f=h+(v^E&(m^v))+g[13]+2850285829&4294967295,h=m+(f<<5&4294967295|f>>>27),f=E+(m^v&(h^m))+g[2]+4243563512&4294967295,E=h+(f<<9&4294967295|f>>>23),f=v+(h^m&(E^h))+g[7]+1735328473&4294967295,v=E+(f<<14&4294967295|f>>>18),f=m+(E^h&(v^E))+g[12]+2368359562&4294967295,m=v+(f<<20&4294967295|f>>>12),f=h+(m^v^E)+g[5]+4294588738&4294967295,h=m+(f<<4&4294967295|f>>>28),f=E+(h^m^v)+g[8]+2272392833&4294967295,E=h+(f<<11&4294967295|f>>>21),f=v+(E^h^m)+g[11]+1839030562&4294967295,v=E+(f<<16&4294967295|f>>>16),f=m+(v^E^h)+g[14]+4259657740&4294967295,m=v+(f<<23&4294967295|f>>>9),f=h+(m^v^E)+g[1]+2763975236&4294967295,h=m+(f<<4&4294967295|f>>>28),f=E+(h^m^v)+g[4]+1272893353&4294967295,E=h+(f<<11&4294967295|f>>>21),f=v+(E^h^m)+g[7]+4139469664&4294967295,v=E+(f<<16&4294967295|f>>>16),f=m+(v^E^h)+g[10]+3200236656&4294967295,m=v+(f<<23&4294967295|f>>>9),f=h+(m^v^E)+g[13]+681279174&4294967295,h=m+(f<<4&4294967295|f>>>28),f=E+(h^m^v)+g[0]+3936430074&4294967295,E=h+(f<<11&4294967295|f>>>21),f=v+(E^h^m)+g[3]+3572445317&4294967295,v=E+(f<<16&4294967295|f>>>16),f=m+(v^E^h)+g[6]+76029189&4294967295,m=v+(f<<23&4294967295|f>>>9),f=h+(m^v^E)+g[9]+3654602809&4294967295,h=m+(f<<4&4294967295|f>>>28),f=E+(h^m^v)+g[12]+3873151461&4294967295,E=h+(f<<11&4294967295|f>>>21),f=v+(E^h^m)+g[15]+530742520&4294967295,v=E+(f<<16&4294967295|f>>>16),f=m+(v^E^h)+g[2]+3299628645&4294967295,m=v+(f<<23&4294967295|f>>>9),f=h+(v^(m|~E))+g[0]+4096336452&4294967295,h=m+(f<<6&4294967295|f>>>26),f=E+(m^(h|~v))+g[7]+1126891415&4294967295,E=h+(f<<10&4294967295|f>>>22),f=v+(h^(E|~m))+g[14]+2878612391&4294967295,v=E+(f<<15&4294967295|f>>>17),f=m+(E^(v|~h))+g[5]+4237533241&4294967295,m=v+(f<<21&4294967295|f>>>11),f=h+(v^(m|~E))+g[12]+1700485571&4294967295,h=m+(f<<6&4294967295|f>>>26),f=E+(m^(h|~v))+g[3]+2399980690&4294967295,E=h+(f<<10&4294967295|f>>>22),f=v+(h^(E|~m))+g[10]+4293915773&4294967295,v=E+(f<<15&4294967295|f>>>17),f=m+(E^(v|~h))+g[1]+2240044497&4294967295,m=v+(f<<21&4294967295|f>>>11),f=h+(v^(m|~E))+g[8]+1873313359&4294967295,h=m+(f<<6&4294967295|f>>>26),f=E+(m^(h|~v))+g[15]+4264355552&4294967295,E=h+(f<<10&4294967295|f>>>22),f=v+(h^(E|~m))+g[6]+2734768916&4294967295,v=E+(f<<15&4294967295|f>>>17),f=m+(E^(v|~h))+g[13]+1309151649&4294967295,m=v+(f<<21&4294967295|f>>>11),f=h+(v^(m|~E))+g[4]+4149444226&4294967295,h=m+(f<<6&4294967295|f>>>26),f=E+(m^(h|~v))+g[11]+3174756917&4294967295,E=h+(f<<10&4294967295|f>>>22),f=v+(h^(E|~m))+g[2]+718787259&4294967295,v=E+(f<<15&4294967295|f>>>17),f=m+(E^(v|~h))+g[9]+3951481745&4294967295,y.g[0]=y.g[0]+h&4294967295,y.g[1]=y.g[1]+(v+(f<<21&4294967295|f>>>11))&4294967295,y.g[2]=y.g[2]+v&4294967295,y.g[3]=y.g[3]+E&4294967295}o.prototype.u=function(y,h){h===void 0&&(h=y.length);for(var m=h-this.blockSize,g=this.B,v=this.h,E=0;E<h;){if(v==0)for(;E<=m;)r(this,y,E),E+=this.blockSize;if(typeof y=="string"){for(;E<h;)if(g[v++]=y.charCodeAt(E++),v==this.blockSize){r(this,g),v=0;break}}else for(;E<h;)if(g[v++]=y[E++],v==this.blockSize){r(this,g),v=0;break}}this.h=v,this.o+=h},o.prototype.v=function(){var y=Array((56>this.h?this.blockSize:2*this.blockSize)-this.h);y[0]=128;for(var h=1;h<y.length-8;++h)y[h]=0;var m=8*this.o;for(h=y.length-8;h<y.length;++h)y[h]=m&255,m/=256;for(this.u(y),y=Array(16),h=m=0;4>h;++h)for(var g=0;32>g;g+=8)y[m++]=this.g[h]>>>g&255;return y};function a(y,h){var m=d;return Object.prototype.hasOwnProperty.call(m,y)?m[y]:m[y]=h(y)}function l(y,h){this.h=h;for(var m=[],g=!0,v=y.length-1;0<=v;v--){var E=y[v]|0;g&&E==h||(m[v]=E,g=!1)}this.g=m}var d={};function p(y){return-128<=y&&128>y?a(y,function(h){return new l([h|0],0>h?-1:0)}):new l([y|0],0>y?-1:0)}function w(y){if(isNaN(y)||!isFinite(y))return D;if(0>y)return M(w(-y));for(var h=[],m=1,g=0;y>=m;g++)h[g]=y/m|0,m*=4294967296;return new l(h,0)}function A(y,h){if(y.length==0)throw Error("number format error: empty string");if(h=h||10,2>h||36<h)throw Error("radix out of range: "+h);if(y.charAt(0)=="-")return M(A(y.substring(1),h));if(0<=y.indexOf("-"))throw Error('number format error: interior "-" character');for(var m=w(Math.pow(h,8)),g=D,v=0;v<y.length;v+=8){var E=Math.min(8,y.length-v),f=parseInt(y.substring(v,v+E),h);8>E?(E=w(Math.pow(h,E)),g=g.j(E).add(w(f))):(g=g.j(m),g=g.add(w(f)))}return g}var D=p(0),R=p(1),H=p(16777216);t=l.prototype,t.m=function(){if(V(this))return-M(this).m();for(var y=0,h=1,m=0;m<this.g.length;m++){var g=this.i(m);y+=(0<=g?g:4294967296+g)*h,h*=4294967296}return y},t.toString=function(y){if(y=y||10,2>y||36<y)throw Error("radix out of range: "+y);if(N(this))return"0";if(V(this))return"-"+M(this).toString(y);for(var h=w(Math.pow(y,6)),m=this,g="";;){var v=z(m,h).g;m=re(m,v.j(h));var E=((0<m.g.length?m.g[0]:m.h)>>>0).toString(y);if(m=v,N(m))return E+g;for(;6>E.length;)E="0"+E;g=E+g}},t.i=function(y){return 0>y?0:y<this.g.length?this.g[y]:this.h};function N(y){if(y.h!=0)return!1;for(var h=0;h<y.g.length;h++)if(y.g[h]!=0)return!1;return!0}function V(y){return y.h==-1}t.l=function(y){return y=re(this,y),V(y)?-1:N(y)?0:1};function M(y){for(var h=y.g.length,m=[],g=0;g<h;g++)m[g]=~y.g[g];return new l(m,~y.h).add(R)}t.abs=function(){return V(this)?M(this):this},t.add=function(y){for(var h=Math.max(this.g.length,y.g.length),m=[],g=0,v=0;v<=h;v++){var E=g+(this.i(v)&65535)+(y.i(v)&65535),f=(E>>>16)+(this.i(v)>>>16)+(y.i(v)>>>16);g=f>>>16,E&=65535,f&=65535,m[v]=f<<16|E}return new l(m,m[m.length-1]&-2147483648?-1:0)};function re(y,h){return y.add(M(h))}t.j=function(y){if(N(this)||N(y))return D;if(V(this))return V(y)?M(this).j(M(y)):M(M(this).j(y));if(V(y))return M(this.j(M(y)));if(0>this.l(H)&&0>y.l(H))return w(this.m()*y.m());for(var h=this.g.length+y.g.length,m=[],g=0;g<2*h;g++)m[g]=0;for(g=0;g<this.g.length;g++)for(var v=0;v<y.g.length;v++){var E=this.i(g)>>>16,f=this.i(g)&65535,be=y.i(v)>>>16,bt=y.i(v)&65535;m[2*g+2*v]+=f*bt,ee(m,2*g+2*v),m[2*g+2*v+1]+=E*bt,ee(m,2*g+2*v+1),m[2*g+2*v+1]+=f*be,ee(m,2*g+2*v+1),m[2*g+2*v+2]+=E*be,ee(m,2*g+2*v+2)}for(g=0;g<h;g++)m[g]=m[2*g+1]<<16|m[2*g];for(g=h;g<2*h;g++)m[g]=0;return new l(m,0)};function ee(y,h){for(;(y[h]&65535)!=y[h];)y[h+1]+=y[h]>>>16,y[h]&=65535,h++}function q(y,h){this.g=y,this.h=h}function z(y,h){if(N(h))throw Error("division by zero");if(N(y))return new q(D,D);if(V(y))return h=z(M(y),h),new q(M(h.g),M(h.h));if(V(h))return h=z(y,M(h)),new q(M(h.g),h.h);if(30<y.g.length){if(V(y)||V(h))throw Error("slowDivide_ only works with positive integers.");for(var m=R,g=h;0>=g.l(y);)m=ce(m),g=ce(g);var v=K(m,1),E=K(g,1);for(g=K(g,2),m=K(m,2);!N(g);){var f=E.add(g);0>=f.l(y)&&(v=v.add(m),E=f),g=K(g,1),m=K(m,1)}return h=re(y,v.j(h)),new q(v,h)}for(v=D;0<=y.l(h);){for(m=Math.max(1,Math.floor(y.m()/h.m())),g=Math.ceil(Math.log(m)/Math.LN2),g=48>=g?1:Math.pow(2,g-48),E=w(m),f=E.j(h);V(f)||0<f.l(y);)m-=g,E=w(m),f=E.j(h);N(E)&&(E=R),v=v.add(E),y=re(y,f)}return new q(v,y)}t.A=function(y){return z(this,y).h},t.and=function(y){for(var h=Math.max(this.g.length,y.g.length),m=[],g=0;g<h;g++)m[g]=this.i(g)&y.i(g);return new l(m,this.h&y.h)},t.or=function(y){for(var h=Math.max(this.g.length,y.g.length),m=[],g=0;g<h;g++)m[g]=this.i(g)|y.i(g);return new l(m,this.h|y.h)},t.xor=function(y){for(var h=Math.max(this.g.length,y.g.length),m=[],g=0;g<h;g++)m[g]=this.i(g)^y.i(g);return new l(m,this.h^y.h)};function ce(y){for(var h=y.g.length+1,m=[],g=0;g<h;g++)m[g]=y.i(g)<<1|y.i(g-1)>>>31;return new l(m,y.h)}function K(y,h){var m=h>>5;h%=32;for(var g=y.g.length-m,v=[],E=0;E<g;E++)v[E]=0<h?y.i(E+m)>>>h|y.i(E+m+1)<<32-h:y.i(E+m);return new l(v,y.h)}o.prototype.digest=o.prototype.v,o.prototype.reset=o.prototype.s,o.prototype.update=o.prototype.u,l.prototype.add=l.prototype.add,l.prototype.multiply=l.prototype.j,l.prototype.modulo=l.prototype.A,l.prototype.compare=l.prototype.l,l.prototype.toNumber=l.prototype.m,l.prototype.toString=l.prototype.toString,l.prototype.getBits=l.prototype.i,l.fromNumber=w,l.fromString=A,ji=l}).apply(typeof Rr<"u"?Rr:typeof self<"u"?self:typeof window<"u"?window:{});var _n=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};(function(){var t,e=typeof Object.defineProperties=="function"?Object.defineProperty:function(s,i,c){return s==Array.prototype||s==Object.prototype||(s[i]=c.value),s};function n(s){s=[typeof globalThis=="object"&&globalThis,s,typeof window=="object"&&window,typeof self=="object"&&self,typeof _n=="object"&&_n];for(var i=0;i<s.length;++i){var c=s[i];if(c&&c.Math==Math)return c}throw Error("Cannot find global object")}var o=n(this);function r(s,i){if(i)e:{var c=o;s=s.split(".");for(var u=0;u<s.length-1;u++){var _=s[u];if(!(_ in c))break e;c=c[_]}s=s[s.length-1],u=c[s],i=i(u),i!=u&&i!=null&&e(c,s,{configurable:!0,writable:!0,value:i})}}function a(s,i){s instanceof String&&(s+="");var c=0,u=!1,_={next:function(){if(!u&&c<s.length){var I=c++;return{value:i(I,s[I]),done:!1}}return u=!0,{done:!0,value:void 0}}};return _[Symbol.iterator]=function(){return _},_}r("Array.prototype.values",function(s){return s||function(){return a(this,function(i,c){return c})}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var l=l||{},d=this||self;function p(s){var i=typeof s;return i=i!="object"?i:s?Array.isArray(s)?"array":i:"null",i=="array"||i=="object"&&typeof s.length=="number"}function w(s){var i=typeof s;return i=="object"&&s!=null||i=="function"}function A(s,i,c){return s.call.apply(s.bind,arguments)}function D(s,i,c){if(!s)throw Error();if(2<arguments.length){var u=Array.prototype.slice.call(arguments,2);return function(){var _=Array.prototype.slice.call(arguments);return Array.prototype.unshift.apply(_,u),s.apply(i,_)}}return function(){return s.apply(i,arguments)}}function R(s,i,c){return R=Function.prototype.bind&&Function.prototype.bind.toString().indexOf("native code")!=-1?A:D,R.apply(null,arguments)}function H(s,i){var c=Array.prototype.slice.call(arguments,1);return function(){var u=c.slice();return u.push.apply(u,arguments),s.apply(this,u)}}function N(s,i){function c(){}c.prototype=i.prototype,s.aa=i.prototype,s.prototype=new c,s.prototype.constructor=s,s.Qb=function(u,_,I){for(var b=Array(arguments.length-2),F=2;F<arguments.length;F++)b[F-2]=arguments[F];return i.prototype[_].apply(u,b)}}function V(s){const i=s.length;if(0<i){const c=Array(i);for(let u=0;u<i;u++)c[u]=s[u];return c}return[]}function M(s,i){for(let c=1;c<arguments.length;c++){const u=arguments[c];if(p(u)){const _=s.length||0,I=u.length||0;s.length=_+I;for(let b=0;b<I;b++)s[_+b]=u[b]}else s.push(u)}}class re{constructor(i,c){this.i=i,this.j=c,this.h=0,this.g=null}get(){let i;return 0<this.h?(this.h--,i=this.g,this.g=i.next,i.next=null):i=this.i(),i}}function ee(s){return/^[\s\xa0]*$/.test(s)}function q(){var s=d.navigator;return s&&(s=s.userAgent)?s:""}function z(s){return z[" "](s),s}z[" "]=function(){};var ce=q().indexOf("Gecko")!=-1&&!(q().toLowerCase().indexOf("webkit")!=-1&&q().indexOf("Edge")==-1)&&!(q().indexOf("Trident")!=-1||q().indexOf("MSIE")!=-1)&&q().indexOf("Edge")==-1;function K(s,i,c){for(const u in s)i.call(c,s[u],u,s)}function y(s,i){for(const c in s)i.call(void 0,s[c],c,s)}function h(s){const i={};for(const c in s)i[c]=s[c];return i}const m="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function g(s,i){let c,u;for(let _=1;_<arguments.length;_++){u=arguments[_];for(c in u)s[c]=u[c];for(let I=0;I<m.length;I++)c=m[I],Object.prototype.hasOwnProperty.call(u,c)&&(s[c]=u[c])}}function v(s){var i=1;s=s.split(":");const c=[];for(;0<i&&s.length;)c.push(s.shift()),i--;return s.length&&c.push(s.join(":")),c}function E(s){d.setTimeout(()=>{throw s},0)}function f(){var s=Jn;let i=null;return s.g&&(i=s.g,s.g=s.g.next,s.g||(s.h=null),i.next=null),i}class be{constructor(){this.h=this.g=null}add(i,c){const u=bt.get();u.set(i,c),this.h?this.h.next=u:this.g=u,this.h=u}}var bt=new re(()=>new za,s=>s.reset());class za{constructor(){this.next=this.g=this.h=null}set(i,c){this.h=i,this.g=c,this.next=null}reset(){this.next=this.g=this.h=null}}let Tt,At=!1,Jn=new be,Eo=()=>{const s=d.Promise.resolve(void 0);Tt=()=>{s.then(Wa)}};var Wa=()=>{for(var s;s=f();){try{s.h.call(s.g)}catch(c){E(c)}var i=bt;i.j(s),100>i.h&&(i.h++,s.next=i.g,i.g=s)}At=!1};function Oe(){this.s=this.s,this.C=this.C}Oe.prototype.s=!1,Oe.prototype.ma=function(){this.s||(this.s=!0,this.N())},Oe.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function X(s,i){this.type=s,this.g=this.target=i,this.defaultPrevented=!1}X.prototype.h=function(){this.defaultPrevented=!0};var Ga=function(){if(!d.addEventListener||!Object.defineProperty)return!1;var s=!1,i=Object.defineProperty({},"passive",{get:function(){s=!0}});try{const c=()=>{};d.addEventListener("test",c,i),d.removeEventListener("test",c,i)}catch{}return s}();function St(s,i){if(X.call(this,s?s.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,s){var c=this.type=s.type,u=s.changedTouches&&s.changedTouches.length?s.changedTouches[0]:null;if(this.target=s.target||s.srcElement,this.g=i,i=s.relatedTarget){if(ce){e:{try{z(i.nodeName);var _=!0;break e}catch{}_=!1}_||(i=null)}}else c=="mouseover"?i=s.fromElement:c=="mouseout"&&(i=s.toElement);this.relatedTarget=i,u?(this.clientX=u.clientX!==void 0?u.clientX:u.pageX,this.clientY=u.clientY!==void 0?u.clientY:u.pageY,this.screenX=u.screenX||0,this.screenY=u.screenY||0):(this.clientX=s.clientX!==void 0?s.clientX:s.pageX,this.clientY=s.clientY!==void 0?s.clientY:s.pageY,this.screenX=s.screenX||0,this.screenY=s.screenY||0),this.button=s.button,this.key=s.key||"",this.ctrlKey=s.ctrlKey,this.altKey=s.altKey,this.shiftKey=s.shiftKey,this.metaKey=s.metaKey,this.pointerId=s.pointerId||0,this.pointerType=typeof s.pointerType=="string"?s.pointerType:Ka[s.pointerType]||"",this.state=s.state,this.i=s,s.defaultPrevented&&St.aa.h.call(this)}}N(St,X);var Ka={2:"touch",3:"pen",4:"mouse"};St.prototype.h=function(){St.aa.h.call(this);var s=this.i;s.preventDefault?s.preventDefault():s.returnValue=!1};var nn="closure_listenable_"+(1e6*Math.random()|0),Ja=0;function Xa(s,i,c,u,_){this.listener=s,this.proxy=null,this.src=i,this.type=c,this.capture=!!u,this.ha=_,this.key=++Ja,this.da=this.fa=!1}function sn(s){s.da=!0,s.listener=null,s.proxy=null,s.src=null,s.ha=null}function on(s){this.src=s,this.g={},this.h=0}on.prototype.add=function(s,i,c,u,_){var I=s.toString();s=this.g[I],s||(s=this.g[I]=[],this.h++);var b=Yn(s,i,u,_);return-1<b?(i=s[b],c||(i.fa=!1)):(i=new Xa(i,this.src,I,!!u,_),i.fa=c,s.push(i)),i};function Xn(s,i){var c=i.type;if(c in s.g){var u=s.g[c],_=Array.prototype.indexOf.call(u,i,void 0),I;(I=0<=_)&&Array.prototype.splice.call(u,_,1),I&&(sn(i),s.g[c].length==0&&(delete s.g[c],s.h--))}}function Yn(s,i,c,u){for(var _=0;_<s.length;++_){var I=s[_];if(!I.da&&I.listener==i&&I.capture==!!c&&I.ha==u)return _}return-1}var Qn="closure_lm_"+(1e6*Math.random()|0),Zn={};function Io(s,i,c,u,_){if(Array.isArray(i)){for(var I=0;I<i.length;I++)Io(s,i[I],c,u,_);return null}return c=To(c),s&&s[nn]?s.K(i,c,w(u)?!!u.capture:!1,_):Ya(s,i,c,!1,u,_)}function Ya(s,i,c,u,_,I){if(!i)throw Error("Invalid event type");var b=w(_)?!!_.capture:!!_,F=ts(s);if(F||(s[Qn]=F=new on(s)),c=F.add(i,c,u,b,I),c.proxy)return c;if(u=Qa(),c.proxy=u,u.src=s,u.listener=c,s.addEventListener)Ga||(_=b),_===void 0&&(_=!1),s.addEventListener(i.toString(),u,_);else if(s.attachEvent)s.attachEvent(bo(i.toString()),u);else if(s.addListener&&s.removeListener)s.addListener(u);else throw Error("addEventListener and attachEvent are unavailable.");return c}function Qa(){function s(c){return i.call(s.src,s.listener,c)}const i=Za;return s}function wo(s,i,c,u,_){if(Array.isArray(i))for(var I=0;I<i.length;I++)wo(s,i[I],c,u,_);else u=w(u)?!!u.capture:!!u,c=To(c),s&&s[nn]?(s=s.i,i=String(i).toString(),i in s.g&&(I=s.g[i],c=Yn(I,c,u,_),-1<c&&(sn(I[c]),Array.prototype.splice.call(I,c,1),I.length==0&&(delete s.g[i],s.h--)))):s&&(s=ts(s))&&(i=s.g[i.toString()],s=-1,i&&(s=Yn(i,c,u,_)),(c=-1<s?i[s]:null)&&es(c))}function es(s){if(typeof s!="number"&&s&&!s.da){var i=s.src;if(i&&i[nn])Xn(i.i,s);else{var c=s.type,u=s.proxy;i.removeEventListener?i.removeEventListener(c,u,s.capture):i.detachEvent?i.detachEvent(bo(c),u):i.addListener&&i.removeListener&&i.removeListener(u),(c=ts(i))?(Xn(c,s),c.h==0&&(c.src=null,i[Qn]=null)):sn(s)}}}function bo(s){return s in Zn?Zn[s]:Zn[s]="on"+s}function Za(s,i){if(s.da)s=!0;else{i=new St(i,this);var c=s.listener,u=s.ha||s.src;s.fa&&es(s),s=c.call(u,i)}return s}function ts(s){return s=s[Qn],s instanceof on?s:null}var ns="__closure_events_fn_"+(1e9*Math.random()>>>0);function To(s){return typeof s=="function"?s:(s[ns]||(s[ns]=function(i){return s.handleEvent(i)}),s[ns])}function Y(){Oe.call(this),this.i=new on(this),this.M=this,this.F=null}N(Y,Oe),Y.prototype[nn]=!0,Y.prototype.removeEventListener=function(s,i,c,u){wo(this,s,i,c,u)};function te(s,i){var c,u=s.F;if(u)for(c=[];u;u=u.F)c.push(u);if(s=s.M,u=i.type||i,typeof i=="string")i=new X(i,s);else if(i instanceof X)i.target=i.target||s;else{var _=i;i=new X(u,s),g(i,_)}if(_=!0,c)for(var I=c.length-1;0<=I;I--){var b=i.g=c[I];_=rn(b,u,!0,i)&&_}if(b=i.g=s,_=rn(b,u,!0,i)&&_,_=rn(b,u,!1,i)&&_,c)for(I=0;I<c.length;I++)b=i.g=c[I],_=rn(b,u,!1,i)&&_}Y.prototype.N=function(){if(Y.aa.N.call(this),this.i){var s=this.i,i;for(i in s.g){for(var c=s.g[i],u=0;u<c.length;u++)sn(c[u]);delete s.g[i],s.h--}}this.F=null},Y.prototype.K=function(s,i,c,u){return this.i.add(String(s),i,!1,c,u)},Y.prototype.L=function(s,i,c,u){return this.i.add(String(s),i,!0,c,u)};function rn(s,i,c,u){if(i=s.i.g[String(i)],!i)return!0;i=i.concat();for(var _=!0,I=0;I<i.length;++I){var b=i[I];if(b&&!b.da&&b.capture==c){var F=b.listener,J=b.ha||b.src;b.fa&&Xn(s.i,b),_=F.call(J,u)!==!1&&_}}return _&&!u.defaultPrevented}function Ao(s,i,c){if(typeof s=="function")c&&(s=R(s,c));else if(s&&typeof s.handleEvent=="function")s=R(s.handleEvent,s);else throw Error("Invalid listener argument");return 2147483647<Number(i)?-1:d.setTimeout(s,i||0)}function So(s){s.g=Ao(()=>{s.g=null,s.i&&(s.i=!1,So(s))},s.l);const i=s.h;s.h=null,s.m.apply(null,i)}class ec extends Oe{constructor(i,c){super(),this.m=i,this.l=c,this.h=null,this.i=!1,this.g=null}j(i){this.h=arguments,this.g?this.i=!0:So(this)}N(){super.N(),this.g&&(d.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function Ct(s){Oe.call(this),this.h=s,this.g={}}N(Ct,Oe);var Co=[];function Do(s){K(s.g,function(i,c){this.g.hasOwnProperty(c)&&es(i)},s),s.g={}}Ct.prototype.N=function(){Ct.aa.N.call(this),Do(this)},Ct.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var ss=d.JSON.stringify,tc=d.JSON.parse,nc=class{stringify(s){return d.JSON.stringify(s,void 0)}parse(s){return d.JSON.parse(s,void 0)}};function os(){}os.prototype.h=null;function Ro(s){return s.h||(s.h=s.i())}function sc(){}var Dt={OPEN:"a",kb:"b",Ja:"c",wb:"d"};function rs(){X.call(this,"d")}N(rs,X);function is(){X.call(this,"c")}N(is,X);var ct={},ko=null;function as(){return ko=ko||new Y}ct.La="serverreachability";function Po(s){X.call(this,ct.La,s)}N(Po,X);function Rt(s){const i=as();te(i,new Po(i))}ct.STAT_EVENT="statevent";function No(s,i){X.call(this,ct.STAT_EVENT,s),this.stat=i}N(No,X);function ne(s){const i=as();te(i,new No(i,s))}ct.Ma="timingevent";function Mo(s,i){X.call(this,ct.Ma,s),this.size=i}N(Mo,X);function kt(s,i){if(typeof s!="function")throw Error("Fn must not be null and must be a function");return d.setTimeout(function(){s()},i)}function Pt(){this.g=!0}Pt.prototype.xa=function(){this.g=!1};function oc(s,i,c,u,_,I){s.info(function(){if(s.g)if(I)for(var b="",F=I.split("&"),J=0;J<F.length;J++){var B=F[J].split("=");if(1<B.length){var Q=B[0];B=B[1];var Z=Q.split("_");b=2<=Z.length&&Z[1]=="type"?b+(Q+"="+B+"&"):b+(Q+"=redacted&")}}else b=null;else b=I;return"XMLHTTP REQ ("+u+") [attempt "+_+"]: "+i+`
`+c+`
`+b})}function rc(s,i,c,u,_,I,b){s.info(function(){return"XMLHTTP RESP ("+u+") [ attempt "+_+"]: "+i+`
`+c+`
`+I+" "+b})}function lt(s,i,c,u){s.info(function(){return"XMLHTTP TEXT ("+i+"): "+ac(s,c)+(u?" "+u:"")})}function ic(s,i){s.info(function(){return"TIMEOUT: "+i})}Pt.prototype.info=function(){};function ac(s,i){if(!s.g)return i;if(!i)return null;try{var c=JSON.parse(i);if(c){for(s=0;s<c.length;s++)if(Array.isArray(c[s])){var u=c[s];if(!(2>u.length)){var _=u[1];if(Array.isArray(_)&&!(1>_.length)){var I=_[0];if(I!="noop"&&I!="stop"&&I!="close")for(var b=1;b<_.length;b++)_[b]=""}}}}return ss(c)}catch{return i}}var cs={NO_ERROR:0,TIMEOUT:8},cc={},ls;function an(){}N(an,os),an.prototype.g=function(){return new XMLHttpRequest},an.prototype.i=function(){return{}},ls=new an;function Le(s,i,c,u){this.j=s,this.i=i,this.l=c,this.R=u||1,this.U=new Ct(this),this.I=45e3,this.H=null,this.o=!1,this.m=this.A=this.v=this.L=this.F=this.S=this.B=null,this.D=[],this.g=null,this.C=0,this.s=this.u=null,this.X=-1,this.J=!1,this.O=0,this.M=null,this.W=this.K=this.T=this.P=!1,this.h=new Oo}function Oo(){this.i=null,this.g="",this.h=!1}var Lo={},us={};function ds(s,i,c){s.L=1,s.v=dn(Te(i)),s.m=c,s.P=!0,$o(s,null)}function $o(s,i){s.F=Date.now(),cn(s),s.A=Te(s.v);var c=s.A,u=s.R;Array.isArray(u)||(u=[String(u)]),Xo(c.i,"t",u),s.C=0,c=s.j.J,s.h=new Oo,s.g=mr(s.j,c?i:null,!s.m),0<s.O&&(s.M=new ec(R(s.Y,s,s.g),s.O)),i=s.U,c=s.g,u=s.ca;var _="readystatechange";Array.isArray(_)||(_&&(Co[0]=_.toString()),_=Co);for(var I=0;I<_.length;I++){var b=Io(c,_[I],u||i.handleEvent,!1,i.h||i);if(!b)break;i.g[b.key]=b}i=s.H?h(s.H):{},s.m?(s.u||(s.u="POST"),i["Content-Type"]="application/x-www-form-urlencoded",s.g.ea(s.A,s.u,s.m,i)):(s.u="GET",s.g.ea(s.A,s.u,null,i)),Rt(),oc(s.i,s.u,s.A,s.l,s.R,s.m)}Le.prototype.ca=function(s){s=s.target;const i=this.M;i&&Ae(s)==3?i.j():this.Y(s)},Le.prototype.Y=function(s){try{if(s==this.g)e:{const Z=Ae(this.g);var i=this.g.Ba();const ht=this.g.Z();if(!(3>Z)&&(Z!=3||this.g&&(this.h.h||this.g.oa()||sr(this.g)))){this.J||Z!=4||i==7||(i==8||0>=ht?Rt(3):Rt(2)),hs(this);var c=this.g.Z();this.X=c;t:if(Bo(this)){var u=sr(this.g);s="";var _=u.length,I=Ae(this.g)==4;if(!this.h.i){if(typeof TextDecoder>"u"){Je(this),Nt(this);var b="";break t}this.h.i=new d.TextDecoder}for(i=0;i<_;i++)this.h.h=!0,s+=this.h.i.decode(u[i],{stream:!(I&&i==_-1)});u.length=0,this.h.g+=s,this.C=0,b=this.h.g}else b=this.g.oa();if(this.o=c==200,rc(this.i,this.u,this.A,this.l,this.R,Z,c),this.o){if(this.T&&!this.K){t:{if(this.g){var F,J=this.g;if((F=J.g?J.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!ee(F)){var B=F;break t}}B=null}if(c=B)lt(this.i,this.l,c,"Initial handshake response via X-HTTP-Initial-Response"),this.K=!0,fs(this,c);else{this.o=!1,this.s=3,ne(12),Je(this),Nt(this);break e}}if(this.P){c=!0;let de;for(;!this.J&&this.C<b.length;)if(de=lc(this,b),de==us){Z==4&&(this.s=4,ne(14),c=!1),lt(this.i,this.l,null,"[Incomplete Response]");break}else if(de==Lo){this.s=4,ne(15),lt(this.i,this.l,b,"[Invalid Chunk]"),c=!1;break}else lt(this.i,this.l,de,null),fs(this,de);if(Bo(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),Z!=4||b.length!=0||this.h.h||(this.s=1,ne(16),c=!1),this.o=this.o&&c,!c)lt(this.i,this.l,b,"[Invalid Chunked Response]"),Je(this),Nt(this);else if(0<b.length&&!this.W){this.W=!0;var Q=this.j;Q.g==this&&Q.ba&&!Q.M&&(Q.j.info("Great, no buffering proxy detected. Bytes received: "+b.length),_s(Q),Q.M=!0,ne(11))}}else lt(this.i,this.l,b,null),fs(this,b);Z==4&&Je(this),this.o&&!this.J&&(Z==4?ur(this.j,this):(this.o=!1,cn(this)))}else Sc(this.g),c==400&&0<b.indexOf("Unknown SID")?(this.s=3,ne(12)):(this.s=0,ne(13)),Je(this),Nt(this)}}}catch{}finally{}};function Bo(s){return s.g?s.u=="GET"&&s.L!=2&&s.j.Ca:!1}function lc(s,i){var c=s.C,u=i.indexOf(`
`,c);return u==-1?us:(c=Number(i.substring(c,u)),isNaN(c)?Lo:(u+=1,u+c>i.length?us:(i=i.slice(u,u+c),s.C=u+c,i)))}Le.prototype.cancel=function(){this.J=!0,Je(this)};function cn(s){s.S=Date.now()+s.I,xo(s,s.I)}function xo(s,i){if(s.B!=null)throw Error("WatchDog timer not null");s.B=kt(R(s.ba,s),i)}function hs(s){s.B&&(d.clearTimeout(s.B),s.B=null)}Le.prototype.ba=function(){this.B=null;const s=Date.now();0<=s-this.S?(ic(this.i,this.A),this.L!=2&&(Rt(),ne(17)),Je(this),this.s=2,Nt(this)):xo(this,this.S-s)};function Nt(s){s.j.G==0||s.J||ur(s.j,s)}function Je(s){hs(s);var i=s.M;i&&typeof i.ma=="function"&&i.ma(),s.M=null,Do(s.U),s.g&&(i=s.g,s.g=null,i.abort(),i.ma())}function fs(s,i){try{var c=s.j;if(c.G!=0&&(c.g==s||ms(c.h,s))){if(!s.K&&ms(c.h,s)&&c.G==3){try{var u=c.Da.g.parse(i)}catch{u=null}if(Array.isArray(u)&&u.length==3){var _=u;if(_[0]==0){e:if(!c.u){if(c.g)if(c.g.F+3e3<s.F)vn(c),pn(c);else break e;ys(c),ne(18)}}else c.za=_[1],0<c.za-c.T&&37500>_[2]&&c.F&&c.v==0&&!c.C&&(c.C=kt(R(c.Za,c),6e3));if(1>=Ho(c.h)&&c.ca){try{c.ca()}catch{}c.ca=void 0}}else Ye(c,11)}else if((s.K||c.g==s)&&vn(c),!ee(i))for(_=c.Da.g.parse(i),i=0;i<_.length;i++){let B=_[i];if(c.T=B[0],B=B[1],c.G==2)if(B[0]=="c"){c.K=B[1],c.ia=B[2];const Q=B[3];Q!=null&&(c.la=Q,c.j.info("VER="+c.la));const Z=B[4];Z!=null&&(c.Aa=Z,c.j.info("SVER="+c.Aa));const ht=B[5];ht!=null&&typeof ht=="number"&&0<ht&&(u=1.5*ht,c.L=u,c.j.info("backChannelRequestTimeoutMs_="+u)),u=c;const de=s.g;if(de){const yn=de.g?de.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(yn){var I=u.h;I.g||yn.indexOf("spdy")==-1&&yn.indexOf("quic")==-1&&yn.indexOf("h2")==-1||(I.j=I.l,I.g=new Set,I.h&&(ps(I,I.h),I.h=null))}if(u.D){const Es=de.g?de.g.getResponseHeader("X-HTTP-Session-Id"):null;Es&&(u.ya=Es,j(u.I,u.D,Es))}}c.G=3,c.l&&c.l.ua(),c.ba&&(c.R=Date.now()-s.F,c.j.info("Handshake RTT: "+c.R+"ms")),u=c;var b=s;if(u.qa=fr(u,u.J?u.ia:null,u.W),b.K){jo(u.h,b);var F=b,J=u.L;J&&(F.I=J),F.B&&(hs(F),cn(F)),u.g=b}else cr(u);0<c.i.length&&gn(c)}else B[0]!="stop"&&B[0]!="close"||Ye(c,7);else c.G==3&&(B[0]=="stop"||B[0]=="close"?B[0]=="stop"?Ye(c,7):vs(c):B[0]!="noop"&&c.l&&c.l.ta(B),c.v=0)}}Rt(4)}catch{}}var uc=class{constructor(s,i){this.g=s,this.map=i}};function Uo(s){this.l=s||10,d.PerformanceNavigationTiming?(s=d.performance.getEntriesByType("navigation"),s=0<s.length&&(s[0].nextHopProtocol=="hq"||s[0].nextHopProtocol=="h2")):s=!!(d.chrome&&d.chrome.loadTimes&&d.chrome.loadTimes()&&d.chrome.loadTimes().wasFetchedViaSpdy),this.j=s?this.l:1,this.g=null,1<this.j&&(this.g=new Set),this.h=null,this.i=[]}function Fo(s){return s.h?!0:s.g?s.g.size>=s.j:!1}function Ho(s){return s.h?1:s.g?s.g.size:0}function ms(s,i){return s.h?s.h==i:s.g?s.g.has(i):!1}function ps(s,i){s.g?s.g.add(i):s.h=i}function jo(s,i){s.h&&s.h==i?s.h=null:s.g&&s.g.has(i)&&s.g.delete(i)}Uo.prototype.cancel=function(){if(this.i=Vo(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const s of this.g.values())s.cancel();this.g.clear()}};function Vo(s){if(s.h!=null)return s.i.concat(s.h.D);if(s.g!=null&&s.g.size!==0){let i=s.i;for(const c of s.g.values())i=i.concat(c.D);return i}return V(s.i)}function dc(s){if(s.V&&typeof s.V=="function")return s.V();if(typeof Map<"u"&&s instanceof Map||typeof Set<"u"&&s instanceof Set)return Array.from(s.values());if(typeof s=="string")return s.split("");if(p(s)){for(var i=[],c=s.length,u=0;u<c;u++)i.push(s[u]);return i}i=[],c=0;for(u in s)i[c++]=s[u];return i}function hc(s){if(s.na&&typeof s.na=="function")return s.na();if(!s.V||typeof s.V!="function"){if(typeof Map<"u"&&s instanceof Map)return Array.from(s.keys());if(!(typeof Set<"u"&&s instanceof Set)){if(p(s)||typeof s=="string"){var i=[];s=s.length;for(var c=0;c<s;c++)i.push(c);return i}i=[],c=0;for(const u in s)i[c++]=u;return i}}}function qo(s,i){if(s.forEach&&typeof s.forEach=="function")s.forEach(i,void 0);else if(p(s)||typeof s=="string")Array.prototype.forEach.call(s,i,void 0);else for(var c=hc(s),u=dc(s),_=u.length,I=0;I<_;I++)i.call(void 0,u[I],c&&c[I],s)}var zo=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function fc(s,i){if(s){s=s.split("&");for(var c=0;c<s.length;c++){var u=s[c].indexOf("="),_=null;if(0<=u){var I=s[c].substring(0,u);_=s[c].substring(u+1)}else I=s[c];i(I,_?decodeURIComponent(_.replace(/\+/g," ")):"")}}}function Xe(s){if(this.g=this.o=this.j="",this.s=null,this.m=this.l="",this.h=!1,s instanceof Xe){this.h=s.h,ln(this,s.j),this.o=s.o,this.g=s.g,un(this,s.s),this.l=s.l;var i=s.i,c=new Lt;c.i=i.i,i.g&&(c.g=new Map(i.g),c.h=i.h),Wo(this,c),this.m=s.m}else s&&(i=String(s).match(zo))?(this.h=!1,ln(this,i[1]||"",!0),this.o=Mt(i[2]||""),this.g=Mt(i[3]||"",!0),un(this,i[4]),this.l=Mt(i[5]||"",!0),Wo(this,i[6]||"",!0),this.m=Mt(i[7]||"")):(this.h=!1,this.i=new Lt(null,this.h))}Xe.prototype.toString=function(){var s=[],i=this.j;i&&s.push(Ot(i,Go,!0),":");var c=this.g;return(c||i=="file")&&(s.push("//"),(i=this.o)&&s.push(Ot(i,Go,!0),"@"),s.push(encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),c=this.s,c!=null&&s.push(":",String(c))),(c=this.l)&&(this.g&&c.charAt(0)!="/"&&s.push("/"),s.push(Ot(c,c.charAt(0)=="/"?gc:pc,!0))),(c=this.i.toString())&&s.push("?",c),(c=this.m)&&s.push("#",Ot(c,yc)),s.join("")};function Te(s){return new Xe(s)}function ln(s,i,c){s.j=c?Mt(i,!0):i,s.j&&(s.j=s.j.replace(/:$/,""))}function un(s,i){if(i){if(i=Number(i),isNaN(i)||0>i)throw Error("Bad port number "+i);s.s=i}else s.s=null}function Wo(s,i,c){i instanceof Lt?(s.i=i,_c(s.i,s.h)):(c||(i=Ot(i,vc)),s.i=new Lt(i,s.h))}function j(s,i,c){s.i.set(i,c)}function dn(s){return j(s,"zx",Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^Date.now()).toString(36)),s}function Mt(s,i){return s?i?decodeURI(s.replace(/%25/g,"%2525")):decodeURIComponent(s):""}function Ot(s,i,c){return typeof s=="string"?(s=encodeURI(s).replace(i,mc),c&&(s=s.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),s):null}function mc(s){return s=s.charCodeAt(0),"%"+(s>>4&15).toString(16)+(s&15).toString(16)}var Go=/[#\/\?@]/g,pc=/[#\?:]/g,gc=/[#\?]/g,vc=/[#\?@]/g,yc=/#/g;function Lt(s,i){this.h=this.g=null,this.i=s||null,this.j=!!i}function $e(s){s.g||(s.g=new Map,s.h=0,s.i&&fc(s.i,function(i,c){s.add(decodeURIComponent(i.replace(/\+/g," ")),c)}))}t=Lt.prototype,t.add=function(s,i){$e(this),this.i=null,s=ut(this,s);var c=this.g.get(s);return c||this.g.set(s,c=[]),c.push(i),this.h+=1,this};function Ko(s,i){$e(s),i=ut(s,i),s.g.has(i)&&(s.i=null,s.h-=s.g.get(i).length,s.g.delete(i))}function Jo(s,i){return $e(s),i=ut(s,i),s.g.has(i)}t.forEach=function(s,i){$e(this),this.g.forEach(function(c,u){c.forEach(function(_){s.call(i,_,u,this)},this)},this)},t.na=function(){$e(this);const s=Array.from(this.g.values()),i=Array.from(this.g.keys()),c=[];for(let u=0;u<i.length;u++){const _=s[u];for(let I=0;I<_.length;I++)c.push(i[u])}return c},t.V=function(s){$e(this);let i=[];if(typeof s=="string")Jo(this,s)&&(i=i.concat(this.g.get(ut(this,s))));else{s=Array.from(this.g.values());for(let c=0;c<s.length;c++)i=i.concat(s[c])}return i},t.set=function(s,i){return $e(this),this.i=null,s=ut(this,s),Jo(this,s)&&(this.h-=this.g.get(s).length),this.g.set(s,[i]),this.h+=1,this},t.get=function(s,i){return s?(s=this.V(s),0<s.length?String(s[0]):i):i};function Xo(s,i,c){Ko(s,i),0<c.length&&(s.i=null,s.g.set(ut(s,i),V(c)),s.h+=c.length)}t.toString=function(){if(this.i)return this.i;if(!this.g)return"";const s=[],i=Array.from(this.g.keys());for(var c=0;c<i.length;c++){var u=i[c];const I=encodeURIComponent(String(u)),b=this.V(u);for(u=0;u<b.length;u++){var _=I;b[u]!==""&&(_+="="+encodeURIComponent(String(b[u]))),s.push(_)}}return this.i=s.join("&")};function ut(s,i){return i=String(i),s.j&&(i=i.toLowerCase()),i}function _c(s,i){i&&!s.j&&($e(s),s.i=null,s.g.forEach(function(c,u){var _=u.toLowerCase();u!=_&&(Ko(this,u),Xo(this,_,c))},s)),s.j=i}function Ec(s,i){const c=new Pt;if(d.Image){const u=new Image;u.onload=H(Be,c,"TestLoadImage: loaded",!0,i,u),u.onerror=H(Be,c,"TestLoadImage: error",!1,i,u),u.onabort=H(Be,c,"TestLoadImage: abort",!1,i,u),u.ontimeout=H(Be,c,"TestLoadImage: timeout",!1,i,u),d.setTimeout(function(){u.ontimeout&&u.ontimeout()},1e4),u.src=s}else i(!1)}function Ic(s,i){const c=new Pt,u=new AbortController,_=setTimeout(()=>{u.abort(),Be(c,"TestPingServer: timeout",!1,i)},1e4);fetch(s,{signal:u.signal}).then(I=>{clearTimeout(_),I.ok?Be(c,"TestPingServer: ok",!0,i):Be(c,"TestPingServer: server error",!1,i)}).catch(()=>{clearTimeout(_),Be(c,"TestPingServer: error",!1,i)})}function Be(s,i,c,u,_){try{_&&(_.onload=null,_.onerror=null,_.onabort=null,_.ontimeout=null),u(c)}catch{}}function wc(){this.g=new nc}function bc(s,i,c){const u=c||"";try{qo(s,function(_,I){let b=_;w(_)&&(b=ss(_)),i.push(u+I+"="+encodeURIComponent(b))})}catch(_){throw i.push(u+"type="+encodeURIComponent("_badmap")),_}}function hn(s){this.l=s.Ub||null,this.j=s.eb||!1}N(hn,os),hn.prototype.g=function(){return new fn(this.l,this.j)},hn.prototype.i=function(s){return function(){return s}}({});function fn(s,i){Y.call(this),this.D=s,this.o=i,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.u=new Headers,this.h=null,this.B="GET",this.A="",this.g=!1,this.v=this.j=this.l=null}N(fn,Y),t=fn.prototype,t.open=function(s,i){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.B=s,this.A=i,this.readyState=1,Bt(this)},t.send=function(s){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");this.g=!0;const i={headers:this.u,method:this.B,credentials:this.m,cache:void 0};s&&(i.body=s),(this.D||d).fetch(new Request(this.A,i)).then(this.Sa.bind(this),this.ga.bind(this))},t.abort=function(){this.response=this.responseText="",this.u=new Headers,this.status=0,this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),1<=this.readyState&&this.g&&this.readyState!=4&&(this.g=!1,$t(this)),this.readyState=0},t.Sa=function(s){if(this.g&&(this.l=s,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=s.headers,this.readyState=2,Bt(this)),this.g&&(this.readyState=3,Bt(this),this.g)))if(this.responseType==="arraybuffer")s.arrayBuffer().then(this.Qa.bind(this),this.ga.bind(this));else if(typeof d.ReadableStream<"u"&&"body"in s){if(this.j=s.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.v=new TextDecoder;Yo(this)}else s.text().then(this.Ra.bind(this),this.ga.bind(this))};function Yo(s){s.j.read().then(s.Pa.bind(s)).catch(s.ga.bind(s))}t.Pa=function(s){if(this.g){if(this.o&&s.value)this.response.push(s.value);else if(!this.o){var i=s.value?s.value:new Uint8Array(0);(i=this.v.decode(i,{stream:!s.done}))&&(this.response=this.responseText+=i)}s.done?$t(this):Bt(this),this.readyState==3&&Yo(this)}},t.Ra=function(s){this.g&&(this.response=this.responseText=s,$t(this))},t.Qa=function(s){this.g&&(this.response=s,$t(this))},t.ga=function(){this.g&&$t(this)};function $t(s){s.readyState=4,s.l=null,s.j=null,s.v=null,Bt(s)}t.setRequestHeader=function(s,i){this.u.append(s,i)},t.getResponseHeader=function(s){return this.h&&this.h.get(s.toLowerCase())||""},t.getAllResponseHeaders=function(){if(!this.h)return"";const s=[],i=this.h.entries();for(var c=i.next();!c.done;)c=c.value,s.push(c[0]+": "+c[1]),c=i.next();return s.join(`\r
`)};function Bt(s){s.onreadystatechange&&s.onreadystatechange.call(s)}Object.defineProperty(fn.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(s){this.m=s?"include":"same-origin"}});function Qo(s){let i="";return K(s,function(c,u){i+=u,i+=":",i+=c,i+=`\r
`}),i}function gs(s,i,c){e:{for(u in c){var u=!1;break e}u=!0}u||(c=Qo(c),typeof s=="string"?c!=null&&encodeURIComponent(String(c)):j(s,i,c))}function W(s){Y.call(this),this.headers=new Map,this.o=s||null,this.h=!1,this.v=this.g=null,this.D="",this.m=0,this.l="",this.j=this.B=this.u=this.A=!1,this.I=null,this.H="",this.J=!1}N(W,Y);var Tc=/^https?$/i,Ac=["POST","PUT"];t=W.prototype,t.Ha=function(s){this.J=s},t.ea=function(s,i,c,u){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+s);i=i?i.toUpperCase():"GET",this.D=s,this.l="",this.m=0,this.A=!1,this.h=!0,this.g=this.o?this.o.g():ls.g(),this.v=this.o?Ro(this.o):Ro(ls),this.g.onreadystatechange=R(this.Ea,this);try{this.B=!0,this.g.open(i,String(s),!0),this.B=!1}catch(I){Zo(this,I);return}if(s=c||"",c=new Map(this.headers),u)if(Object.getPrototypeOf(u)===Object.prototype)for(var _ in u)c.set(_,u[_]);else if(typeof u.keys=="function"&&typeof u.get=="function")for(const I of u.keys())c.set(I,u.get(I));else throw Error("Unknown input type for opt_headers: "+String(u));u=Array.from(c.keys()).find(I=>I.toLowerCase()=="content-type"),_=d.FormData&&s instanceof d.FormData,!(0<=Array.prototype.indexOf.call(Ac,i,void 0))||u||_||c.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[I,b]of c)this.g.setRequestHeader(I,b);this.H&&(this.g.responseType=this.H),"withCredentials"in this.g&&this.g.withCredentials!==this.J&&(this.g.withCredentials=this.J);try{nr(this),this.u=!0,this.g.send(s),this.u=!1}catch(I){Zo(this,I)}};function Zo(s,i){s.h=!1,s.g&&(s.j=!0,s.g.abort(),s.j=!1),s.l=i,s.m=5,er(s),mn(s)}function er(s){s.A||(s.A=!0,te(s,"complete"),te(s,"error"))}t.abort=function(s){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.m=s||7,te(this,"complete"),te(this,"abort"),mn(this))},t.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),mn(this,!0)),W.aa.N.call(this)},t.Ea=function(){this.s||(this.B||this.u||this.j?tr(this):this.bb())},t.bb=function(){tr(this)};function tr(s){if(s.h&&typeof l<"u"&&(!s.v[1]||Ae(s)!=4||s.Z()!=2)){if(s.u&&Ae(s)==4)Ao(s.Ea,0,s);else if(te(s,"readystatechange"),Ae(s)==4){s.h=!1;try{const b=s.Z();e:switch(b){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var i=!0;break e;default:i=!1}var c;if(!(c=i)){var u;if(u=b===0){var _=String(s.D).match(zo)[1]||null;!_&&d.self&&d.self.location&&(_=d.self.location.protocol.slice(0,-1)),u=!Tc.test(_?_.toLowerCase():"")}c=u}if(c)te(s,"complete"),te(s,"success");else{s.m=6;try{var I=2<Ae(s)?s.g.statusText:""}catch{I=""}s.l=I+" ["+s.Z()+"]",er(s)}}finally{mn(s)}}}}function mn(s,i){if(s.g){nr(s);const c=s.g,u=s.v[0]?()=>{}:null;s.g=null,s.v=null,i||te(s,"ready");try{c.onreadystatechange=u}catch{}}}function nr(s){s.I&&(d.clearTimeout(s.I),s.I=null)}t.isActive=function(){return!!this.g};function Ae(s){return s.g?s.g.readyState:0}t.Z=function(){try{return 2<Ae(this)?this.g.status:-1}catch{return-1}},t.oa=function(){try{return this.g?this.g.responseText:""}catch{return""}},t.Oa=function(s){if(this.g){var i=this.g.responseText;return s&&i.indexOf(s)==0&&(i=i.substring(s.length)),tc(i)}};function sr(s){try{if(!s.g)return null;if("response"in s.g)return s.g.response;switch(s.H){case"":case"text":return s.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in s.g)return s.g.mozResponseArrayBuffer}return null}catch{return null}}function Sc(s){const i={};s=(s.g&&2<=Ae(s)&&s.g.getAllResponseHeaders()||"").split(`\r
`);for(let u=0;u<s.length;u++){if(ee(s[u]))continue;var c=v(s[u]);const _=c[0];if(c=c[1],typeof c!="string")continue;c=c.trim();const I=i[_]||[];i[_]=I,I.push(c)}y(i,function(u){return u.join(", ")})}t.Ba=function(){return this.m},t.Ka=function(){return typeof this.l=="string"?this.l:String(this.l)};function xt(s,i,c){return c&&c.internalChannelParams&&c.internalChannelParams[s]||i}function or(s){this.Aa=0,this.i=[],this.j=new Pt,this.ia=this.qa=this.I=this.W=this.g=this.ya=this.D=this.H=this.m=this.S=this.o=null,this.Ya=this.U=0,this.Va=xt("failFast",!1,s),this.F=this.C=this.u=this.s=this.l=null,this.X=!0,this.za=this.T=-1,this.Y=this.v=this.B=0,this.Ta=xt("baseRetryDelayMs",5e3,s),this.cb=xt("retryDelaySeedMs",1e4,s),this.Wa=xt("forwardChannelMaxRetries",2,s),this.wa=xt("forwardChannelRequestTimeoutMs",2e4,s),this.pa=s&&s.xmlHttpFactory||void 0,this.Xa=s&&s.Tb||void 0,this.Ca=s&&s.useFetchStreams||!1,this.L=void 0,this.J=s&&s.supportsCrossDomainXhr||!1,this.K="",this.h=new Uo(s&&s.concurrentRequestLimit),this.Da=new wc,this.P=s&&s.fastHandshake||!1,this.O=s&&s.encodeInitMessageHeaders||!1,this.P&&this.O&&(this.O=!1),this.Ua=s&&s.Rb||!1,s&&s.xa&&this.j.xa(),s&&s.forceLongPolling&&(this.X=!1),this.ba=!this.P&&this.X&&s&&s.detectBufferingProxy||!1,this.ja=void 0,s&&s.longPollingTimeout&&0<s.longPollingTimeout&&(this.ja=s.longPollingTimeout),this.ca=void 0,this.R=0,this.M=!1,this.ka=this.A=null}t=or.prototype,t.la=8,t.G=1,t.connect=function(s,i,c,u){ne(0),this.W=s,this.H=i||{},c&&u!==void 0&&(this.H.OSID=c,this.H.OAID=u),this.F=this.X,this.I=fr(this,null,this.W),gn(this)};function vs(s){if(rr(s),s.G==3){var i=s.U++,c=Te(s.I);if(j(c,"SID",s.K),j(c,"RID",i),j(c,"TYPE","terminate"),Ut(s,c),i=new Le(s,s.j,i),i.L=2,i.v=dn(Te(c)),c=!1,d.navigator&&d.navigator.sendBeacon)try{c=d.navigator.sendBeacon(i.v.toString(),"")}catch{}!c&&d.Image&&(new Image().src=i.v,c=!0),c||(i.g=mr(i.j,null),i.g.ea(i.v)),i.F=Date.now(),cn(i)}hr(s)}function pn(s){s.g&&(_s(s),s.g.cancel(),s.g=null)}function rr(s){pn(s),s.u&&(d.clearTimeout(s.u),s.u=null),vn(s),s.h.cancel(),s.s&&(typeof s.s=="number"&&d.clearTimeout(s.s),s.s=null)}function gn(s){if(!Fo(s.h)&&!s.s){s.s=!0;var i=s.Ga;Tt||Eo(),At||(Tt(),At=!0),Jn.add(i,s),s.B=0}}function Cc(s,i){return Ho(s.h)>=s.h.j-(s.s?1:0)?!1:s.s?(s.i=i.D.concat(s.i),!0):s.G==1||s.G==2||s.B>=(s.Va?0:s.Wa)?!1:(s.s=kt(R(s.Ga,s,i),dr(s,s.B)),s.B++,!0)}t.Ga=function(s){if(this.s)if(this.s=null,this.G==1){if(!s){this.U=Math.floor(1e5*Math.random()),s=this.U++;const _=new Le(this,this.j,s);let I=this.o;if(this.S&&(I?(I=h(I),g(I,this.S)):I=this.S),this.m!==null||this.O||(_.H=I,I=null),this.P)e:{for(var i=0,c=0;c<this.i.length;c++){t:{var u=this.i[c];if("__data__"in u.map&&(u=u.map.__data__,typeof u=="string")){u=u.length;break t}u=void 0}if(u===void 0)break;if(i+=u,4096<i){i=c;break e}if(i===4096||c===this.i.length-1){i=c+1;break e}}i=1e3}else i=1e3;i=ar(this,_,i),c=Te(this.I),j(c,"RID",s),j(c,"CVER",22),this.D&&j(c,"X-HTTP-Session-Id",this.D),Ut(this,c),I&&(this.O?i="headers="+encodeURIComponent(String(Qo(I)))+"&"+i:this.m&&gs(c,this.m,I)),ps(this.h,_),this.Ua&&j(c,"TYPE","init"),this.P?(j(c,"$req",i),j(c,"SID","null"),_.T=!0,ds(_,c,null)):ds(_,c,i),this.G=2}}else this.G==3&&(s?ir(this,s):this.i.length==0||Fo(this.h)||ir(this))};function ir(s,i){var c;i?c=i.l:c=s.U++;const u=Te(s.I);j(u,"SID",s.K),j(u,"RID",c),j(u,"AID",s.T),Ut(s,u),s.m&&s.o&&gs(u,s.m,s.o),c=new Le(s,s.j,c,s.B+1),s.m===null&&(c.H=s.o),i&&(s.i=i.D.concat(s.i)),i=ar(s,c,1e3),c.I=Math.round(.5*s.wa)+Math.round(.5*s.wa*Math.random()),ps(s.h,c),ds(c,u,i)}function Ut(s,i){s.H&&K(s.H,function(c,u){j(i,u,c)}),s.l&&qo({},function(c,u){j(i,u,c)})}function ar(s,i,c){c=Math.min(s.i.length,c);var u=s.l?R(s.l.Na,s.l,s):null;e:{var _=s.i;let I=-1;for(;;){const b=["count="+c];I==-1?0<c?(I=_[0].g,b.push("ofs="+I)):I=0:b.push("ofs="+I);let F=!0;for(let J=0;J<c;J++){let B=_[J].g;const Q=_[J].map;if(B-=I,0>B)I=Math.max(0,_[J].g-100),F=!1;else try{bc(Q,b,"req"+B+"_")}catch{u&&u(Q)}}if(F){u=b.join("&");break e}}}return s=s.i.splice(0,c),i.D=s,u}function cr(s){if(!s.g&&!s.u){s.Y=1;var i=s.Fa;Tt||Eo(),At||(Tt(),At=!0),Jn.add(i,s),s.v=0}}function ys(s){return s.g||s.u||3<=s.v?!1:(s.Y++,s.u=kt(R(s.Fa,s),dr(s,s.v)),s.v++,!0)}t.Fa=function(){if(this.u=null,lr(this),this.ba&&!(this.M||this.g==null||0>=this.R)){var s=2*this.R;this.j.info("BP detection timer enabled: "+s),this.A=kt(R(this.ab,this),s)}},t.ab=function(){this.A&&(this.A=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.M=!0,ne(10),pn(this),lr(this))};function _s(s){s.A!=null&&(d.clearTimeout(s.A),s.A=null)}function lr(s){s.g=new Le(s,s.j,"rpc",s.Y),s.m===null&&(s.g.H=s.o),s.g.O=0;var i=Te(s.qa);j(i,"RID","rpc"),j(i,"SID",s.K),j(i,"AID",s.T),j(i,"CI",s.F?"0":"1"),!s.F&&s.ja&&j(i,"TO",s.ja),j(i,"TYPE","xmlhttp"),Ut(s,i),s.m&&s.o&&gs(i,s.m,s.o),s.L&&(s.g.I=s.L);var c=s.g;s=s.ia,c.L=1,c.v=dn(Te(i)),c.m=null,c.P=!0,$o(c,s)}t.Za=function(){this.C!=null&&(this.C=null,pn(this),ys(this),ne(19))};function vn(s){s.C!=null&&(d.clearTimeout(s.C),s.C=null)}function ur(s,i){var c=null;if(s.g==i){vn(s),_s(s),s.g=null;var u=2}else if(ms(s.h,i))c=i.D,jo(s.h,i),u=1;else return;if(s.G!=0){if(i.o)if(u==1){c=i.m?i.m.length:0,i=Date.now()-i.F;var _=s.B;u=as(),te(u,new Mo(u,c)),gn(s)}else cr(s);else if(_=i.s,_==3||_==0&&0<i.X||!(u==1&&Cc(s,i)||u==2&&ys(s)))switch(c&&0<c.length&&(i=s.h,i.i=i.i.concat(c)),_){case 1:Ye(s,5);break;case 4:Ye(s,10);break;case 3:Ye(s,6);break;default:Ye(s,2)}}}function dr(s,i){let c=s.Ta+Math.floor(Math.random()*s.cb);return s.isActive()||(c*=2),c*i}function Ye(s,i){if(s.j.info("Error code "+i),i==2){var c=R(s.fb,s),u=s.Xa;const _=!u;u=new Xe(u||"//www.google.com/images/cleardot.gif"),d.location&&d.location.protocol=="http"||ln(u,"https"),dn(u),_?Ec(u.toString(),c):Ic(u.toString(),c)}else ne(2);s.G=0,s.l&&s.l.sa(i),hr(s),rr(s)}t.fb=function(s){s?(this.j.info("Successfully pinged google.com"),ne(2)):(this.j.info("Failed to ping google.com"),ne(1))};function hr(s){if(s.G=0,s.ka=[],s.l){const i=Vo(s.h);(i.length!=0||s.i.length!=0)&&(M(s.ka,i),M(s.ka,s.i),s.h.i.length=0,V(s.i),s.i.length=0),s.l.ra()}}function fr(s,i,c){var u=c instanceof Xe?Te(c):new Xe(c);if(u.g!="")i&&(u.g=i+"."+u.g),un(u,u.s);else{var _=d.location;u=_.protocol,i=i?i+"."+_.hostname:_.hostname,_=+_.port;var I=new Xe(null);u&&ln(I,u),i&&(I.g=i),_&&un(I,_),c&&(I.l=c),u=I}return c=s.D,i=s.ya,c&&i&&j(u,c,i),j(u,"VER",s.la),Ut(s,u),u}function mr(s,i,c){if(i&&!s.J)throw Error("Can't create secondary domain capable XhrIo object.");return i=s.Ca&&!s.pa?new W(new hn({eb:c})):new W(s.pa),i.Ha(s.J),i}t.isActive=function(){return!!this.l&&this.l.isActive(this)};function pr(){}t=pr.prototype,t.ua=function(){},t.ta=function(){},t.sa=function(){},t.ra=function(){},t.isActive=function(){return!0},t.Na=function(){};function le(s,i){Y.call(this),this.g=new or(i),this.l=s,this.h=i&&i.messageUrlParams||null,s=i&&i.messageHeaders||null,i&&i.clientProtocolHeaderRequired&&(s?s["X-Client-Protocol"]="webchannel":s={"X-Client-Protocol":"webchannel"}),this.g.o=s,s=i&&i.initMessageHeaders||null,i&&i.messageContentType&&(s?s["X-WebChannel-Content-Type"]=i.messageContentType:s={"X-WebChannel-Content-Type":i.messageContentType}),i&&i.va&&(s?s["X-WebChannel-Client-Profile"]=i.va:s={"X-WebChannel-Client-Profile":i.va}),this.g.S=s,(s=i&&i.Sb)&&!ee(s)&&(this.g.m=s),this.v=i&&i.supportsCrossDomainXhr||!1,this.u=i&&i.sendRawJson||!1,(i=i&&i.httpSessionIdParam)&&!ee(i)&&(this.g.D=i,s=this.h,s!==null&&i in s&&(s=this.h,i in s&&delete s[i])),this.j=new dt(this)}N(le,Y),le.prototype.m=function(){this.g.l=this.j,this.v&&(this.g.J=!0),this.g.connect(this.l,this.h||void 0)},le.prototype.close=function(){vs(this.g)},le.prototype.o=function(s){var i=this.g;if(typeof s=="string"){var c={};c.__data__=s,s=c}else this.u&&(c={},c.__data__=ss(s),s=c);i.i.push(new uc(i.Ya++,s)),i.G==3&&gn(i)},le.prototype.N=function(){this.g.l=null,delete this.j,vs(this.g),delete this.g,le.aa.N.call(this)};function gr(s){rs.call(this),s.__headers__&&(this.headers=s.__headers__,this.statusCode=s.__status__,delete s.__headers__,delete s.__status__);var i=s.__sm__;if(i){e:{for(const c in i){s=c;break e}s=void 0}(this.i=s)&&(s=this.i,i=i!==null&&s in i?i[s]:void 0),this.data=i}else this.data=s}N(gr,rs);function vr(){is.call(this),this.status=1}N(vr,is);function dt(s){this.g=s}N(dt,pr),dt.prototype.ua=function(){te(this.g,"a")},dt.prototype.ta=function(s){te(this.g,new gr(s))},dt.prototype.sa=function(s){te(this.g,new vr)},dt.prototype.ra=function(){te(this.g,"b")},le.prototype.send=le.prototype.o,le.prototype.open=le.prototype.m,le.prototype.close=le.prototype.close,cs.NO_ERROR=0,cs.TIMEOUT=8,cs.HTTP_ERROR=6,cc.COMPLETE="complete",sc.EventType=Dt,Dt.OPEN="a",Dt.CLOSE="b",Dt.ERROR="c",Dt.MESSAGE="d",Y.prototype.listen=Y.prototype.K,W.prototype.listenOnce=W.prototype.L,W.prototype.getLastError=W.prototype.Ka,W.prototype.getLastErrorCode=W.prototype.Ba,W.prototype.getStatus=W.prototype.Z,W.prototype.getResponseJson=W.prototype.Oa,W.prototype.getResponseText=W.prototype.oa,W.prototype.send=W.prototype.ea,W.prototype.setWithCredentials=W.prototype.Ha}).apply(typeof _n<"u"?_n:typeof self<"u"?self:typeof window<"u"?window:{});const kr="@firebase/firestore";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class se{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}se.UNAUTHENTICATED=new se(null),se.GOOGLE_CREDENTIALS=new se("google-credentials-uid"),se.FIRST_PARTY=new se("first-party-uid"),se.MOCK_USER=new se("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Jt="10.14.0";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _t=new Gs("@firebase/firestore");function fe(t,...e){if(_t.logLevel<=x.DEBUG){const n=e.map(Xs);_t.debug(`Firestore (${Jt}): ${t}`,...n)}}function Vi(t,...e){if(_t.logLevel<=x.ERROR){const n=e.map(Xs);_t.error(`Firestore (${Jt}): ${t}`,...n)}}function Eu(t,...e){if(_t.logLevel<=x.WARN){const n=e.map(Xs);_t.warn(`Firestore (${Jt}): ${t}`,...n)}}function Xs(t){if(typeof t=="string")return t;try{/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/return function(n){return JSON.stringify(n)}(t)}catch{return t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ys(t="Unexpected state"){const e=`FIRESTORE (${Jt}) INTERNAL ASSERTION FAILED: `+t;throw Vi(e),new Error(e)}function Ht(t,e){t||Ys()}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ie={CANCELLED:"cancelled",INVALID_ARGUMENT:"invalid-argument",FAILED_PRECONDITION:"failed-precondition"};class ae extends Ee{constructor(e,n){super(e,n),this.code=e,this.message=n,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jt{constructor(){this.promise=new Promise((e,n)=>{this.resolve=e,this.reject=n})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qi{constructor(e,n){this.user=n,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class Iu{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,n){e.enqueueRetryable(()=>n(se.UNAUTHENTICATED))}shutdown(){}}class wu{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,n){this.changeListener=n,e.enqueueRetryable(()=>n(this.token.user))}shutdown(){this.changeListener=null}}class bu{constructor(e){this.t=e,this.currentUser=se.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,n){Ht(this.o===void 0);let o=this.i;const r=p=>this.i!==o?(o=this.i,n(p)):Promise.resolve();let a=new jt;this.o=()=>{this.i++,this.currentUser=this.u(),a.resolve(),a=new jt,e.enqueueRetryable(()=>r(this.currentUser))};const l=()=>{const p=a;e.enqueueRetryable(async()=>{await p.promise,await r(this.currentUser)})},d=p=>{fe("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=p,this.o&&(this.auth.addAuthTokenListener(this.o),l())};this.t.onInit(p=>d(p)),setTimeout(()=>{if(!this.auth){const p=this.t.getImmediate({optional:!0});p?d(p):(fe("FirebaseAuthCredentialsProvider","Auth not yet detected"),a.resolve(),a=new jt)}},0),l()}getToken(){const e=this.i,n=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(n).then(o=>this.i!==e?(fe("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):o?(Ht(typeof o.accessToken=="string"),new qi(o.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.o&&this.auth.removeAuthTokenListener(this.o),this.o=void 0}u(){const e=this.auth&&this.auth.getUid();return Ht(e===null||typeof e=="string"),new se(e)}}class Tu{constructor(e,n,o){this.l=e,this.h=n,this.P=o,this.type="FirstParty",this.user=se.FIRST_PARTY,this.I=new Map}T(){return this.P?this.P():null}get headers(){this.I.set("X-Goog-AuthUser",this.l);const e=this.T();return e&&this.I.set("Authorization",e),this.h&&this.I.set("X-Goog-Iam-Authorization-Token",this.h),this.I}}class Au{constructor(e,n,o){this.l=e,this.h=n,this.P=o}getToken(){return Promise.resolve(new Tu(this.l,this.h,this.P))}start(e,n){e.enqueueRetryable(()=>n(se.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class Su{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class Cu{constructor(e){this.A=e,this.forceRefresh=!1,this.appCheck=null,this.R=null}start(e,n){Ht(this.o===void 0);const o=a=>{a.error!=null&&fe("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${a.error.message}`);const l=a.token!==this.R;return this.R=a.token,fe("FirebaseAppCheckTokenProvider",`Received ${l?"new":"existing"} token.`),l?n(a.token):Promise.resolve()};this.o=a=>{e.enqueueRetryable(()=>o(a))};const r=a=>{fe("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=a,this.o&&this.appCheck.addTokenListener(this.o)};this.A.onInit(a=>r(a)),setTimeout(()=>{if(!this.appCheck){const a=this.A.getImmediate({optional:!0});a?r(a):fe("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(n=>n?(Ht(typeof n.token=="string"),this.R=n.token,new Su(n.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.o&&this.appCheck.removeTokenListener(this.o),this.o=void 0}}function Du(t){return t.name==="IndexedDbTransactionError"}class Mn{constructor(e,n){this.projectId=e,this.database=n||"(default)"}static empty(){return new Mn("","")}get isDefaultDatabase(){return this.database==="(default)"}isEqual(e){return e instanceof Mn&&e.projectId===this.projectId&&e.database===this.database}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Pr,L;(L=Pr||(Pr={}))[L.OK=0]="OK",L[L.CANCELLED=1]="CANCELLED",L[L.UNKNOWN=2]="UNKNOWN",L[L.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",L[L.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",L[L.NOT_FOUND=5]="NOT_FOUND",L[L.ALREADY_EXISTS=6]="ALREADY_EXISTS",L[L.PERMISSION_DENIED=7]="PERMISSION_DENIED",L[L.UNAUTHENTICATED=16]="UNAUTHENTICATED",L[L.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",L[L.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",L[L.ABORTED=10]="ABORTED",L[L.OUT_OF_RANGE=11]="OUT_OF_RANGE",L[L.UNIMPLEMENTED=12]="UNIMPLEMENTED",L[L.INTERNAL=13]="INTERNAL",L[L.UNAVAILABLE=14]="UNAVAILABLE",L[L.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */new ji([4294967295,4294967295],0);function Cs(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ru{constructor(e,n,o=1e3,r=1.5,a=6e4){this.ui=e,this.timerId=n,this.ko=o,this.qo=r,this.Qo=a,this.Ko=0,this.$o=null,this.Uo=Date.now(),this.reset()}reset(){this.Ko=0}Wo(){this.Ko=this.Qo}Go(e){this.cancel();const n=Math.floor(this.Ko+this.zo()),o=Math.max(0,Date.now()-this.Uo),r=Math.max(0,n-o);r>0&&fe("ExponentialBackoff",`Backing off for ${r} ms (base delay: ${this.Ko} ms, delay with jitter: ${n} ms, last attempt: ${o} ms ago)`),this.$o=this.ui.enqueueAfterDelay(this.timerId,r,()=>(this.Uo=Date.now(),e())),this.Ko*=this.qo,this.Ko<this.ko&&(this.Ko=this.ko),this.Ko>this.Qo&&(this.Ko=this.Qo)}jo(){this.$o!==null&&(this.$o.skipDelay(),this.$o=null)}cancel(){this.$o!==null&&(this.$o.cancel(),this.$o=null)}zo(){return(Math.random()-.5)*this.Ko}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qs{constructor(e,n,o,r,a){this.asyncQueue=e,this.timerId=n,this.targetTimeMs=o,this.op=r,this.removalCallback=a,this.deferred=new jt,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(l=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,n,o,r,a){const l=Date.now()+o,d=new Qs(e,n,l,r,a);return d.start(o),d}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new ae(ie.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}var Nr,Mr;(Mr=Nr||(Nr={})).ea="default",Mr.Cache="cache";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ku(t){const e={};return t.timeoutSeconds!==void 0&&(e.timeoutSeconds=t.timeoutSeconds),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Or=new Map;function Pu(t,e,n,o){if(e===!0&&o===!0)throw new ae(ie.INVALID_ARGUMENT,`${t} and ${n} cannot be used together.`)}function Nu(t){if(t===void 0)return"undefined";if(t===null)return"null";if(typeof t=="string")return t.length>20&&(t=`${t.substring(0,20)}...`),JSON.stringify(t);if(typeof t=="number"||typeof t=="boolean")return""+t;if(typeof t=="object"){if(t instanceof Array)return"an array";{const e=function(o){return o.constructor?o.constructor.name:null}(t);return e?`a custom ${e} object`:"an object"}}return typeof t=="function"?"a function":Ys()}function Mu(t,e){if("_delegate"in t&&(t=t._delegate),!(t instanceof e)){if(e.name===t.constructor.name)throw new ae(ie.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const n=Nu(t);throw new ae(ie.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${n}`)}}return t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lr{constructor(e){var n,o;if(e.host===void 0){if(e.ssl!==void 0)throw new ae(ie.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host="firestore.googleapis.com",this.ssl=!0}else this.host=e.host,this.ssl=(n=e.ssl)===null||n===void 0||n;if(this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=41943040;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<1048576)throw new ae(ie.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}Pu("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=ku((o=e.experimentalLongPollingOptions)!==null&&o!==void 0?o:{}),function(a){if(a.timeoutSeconds!==void 0){if(isNaN(a.timeoutSeconds))throw new ae(ie.INVALID_ARGUMENT,`invalid long polling timeout: ${a.timeoutSeconds} (must not be NaN)`);if(a.timeoutSeconds<5)throw new ae(ie.INVALID_ARGUMENT,`invalid long polling timeout: ${a.timeoutSeconds} (minimum allowed value is 5)`);if(a.timeoutSeconds>30)throw new ae(ie.INVALID_ARGUMENT,`invalid long polling timeout: ${a.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&function(o,r){return o.timeoutSeconds===r.timeoutSeconds}(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class zi{constructor(e,n,o,r){this._authCredentials=e,this._appCheckCredentials=n,this._databaseId=o,this._app=r,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new Lr({}),this._settingsFrozen=!1,this._terminateTask="notTerminated"}get app(){if(!this._app)throw new ae(ie.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(e){if(this._settingsFrozen)throw new ae(ie.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new Lr(e),e.credentials!==void 0&&(this._authCredentials=function(o){if(!o)return new Iu;switch(o.type){case"firstParty":return new Au(o.sessionIndex||"0",o.iamToken||null,o.authTokenFactory||null);case"provider":return o.client;default:throw new ae(ie.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(n){const o=Or.get(n);o&&(fe("ComponentProvider","Removing Datastore"),Or.delete(n),o.terminate())}(this),Promise.resolve()}}function Ou(t,e,n,o={}){var r;const a=(t=Mu(t,zi))._getSettings(),l=`${e}:${n}`;if(a.host!=="firestore.googleapis.com"&&a.host!==l&&Eu("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used."),t._setSettings(Object.assign(Object.assign({},a),{host:l,ssl:!1})),o.mockUserToken){let d,p;if(typeof o.mockUserToken=="string")d=o.mockUserToken,p=se.MOCK_USER;else{d=$i(o.mockUserToken,(r=t._app)===null||r===void 0?void 0:r.options.projectId);const w=o.mockUserToken.sub||o.mockUserToken.user_id;if(!w)throw new ae(ie.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");p=new se(w)}t._authCredentials=new wu(new qi(d,p))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $r{constructor(e=Promise.resolve()){this.Pu=[],this.Iu=!1,this.Tu=[],this.Eu=null,this.du=!1,this.Au=!1,this.Ru=[],this.t_=new Ru(this,"async_queue_retry"),this.Vu=()=>{const o=Cs();o&&fe("AsyncQueue","Visibility state changed to "+o.visibilityState),this.t_.jo()},this.mu=e;const n=Cs();n&&typeof n.addEventListener=="function"&&n.addEventListener("visibilitychange",this.Vu)}get isShuttingDown(){return this.Iu}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.fu(),this.gu(e)}enterRestrictedMode(e){if(!this.Iu){this.Iu=!0,this.Au=e||!1;const n=Cs();n&&typeof n.removeEventListener=="function"&&n.removeEventListener("visibilitychange",this.Vu)}}enqueue(e){if(this.fu(),this.Iu)return new Promise(()=>{});const n=new jt;return this.gu(()=>this.Iu&&this.Au?Promise.resolve():(e().then(n.resolve,n.reject),n.promise)).then(()=>n.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.Pu.push(e),this.pu()))}async pu(){if(this.Pu.length!==0){try{await this.Pu[0](),this.Pu.shift(),this.t_.reset()}catch(e){if(!Du(e))throw e;fe("AsyncQueue","Operation failed with retryable error: "+e)}this.Pu.length>0&&this.t_.Go(()=>this.pu())}}gu(e){const n=this.mu.then(()=>(this.du=!0,e().catch(o=>{this.Eu=o,this.du=!1;const r=function(l){let d=l.message||"";return l.stack&&(d=l.stack.includes(l.message)?l.stack:l.message+`
`+l.stack),d}(o);throw Vi("INTERNAL UNHANDLED ERROR: ",r),o}).then(o=>(this.du=!1,o))));return this.mu=n,n}enqueueAfterDelay(e,n,o){this.fu(),this.Ru.indexOf(e)>-1&&(n=0);const r=Qs.createAndSchedule(this,e,n,o,a=>this.yu(a));return this.Tu.push(r),r}fu(){this.Eu&&Ys()}verifyOperationInProgress(){}async wu(){let e;do e=this.mu,await e;while(e!==this.mu)}Su(e){for(const n of this.Tu)if(n.timerId===e)return!0;return!1}bu(e){return this.wu().then(()=>{this.Tu.sort((n,o)=>n.targetTimeMs-o.targetTimeMs);for(const n of this.Tu)if(n.skipDelay(),e!=="all"&&n.timerId===e)break;return this.wu()})}Du(e){this.Ru.push(e)}yu(e){const n=this.Tu.indexOf(e);this.Tu.splice(n,1)}}class Lu extends zi{constructor(e,n,o,r){super(e,n,o,r),this.type="firestore",this._queue=new $r,this._persistenceKey=(r==null?void 0:r.name)||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const e=this._firestoreClient.terminate();this._queue=new $r(e),this._firestoreClient=void 0,await e}}}function $u(t,e){const n=typeof t=="object"?t:Js(),o=typeof t=="string"?t:"(default)",r=qn(n,"firestore").getImmediate({identifier:o});if(!r._initialized){const a=Mi("firestore");a&&Ou(r,...a)}return r}(function(e,n=!0){(function(r){Jt=r})(it),tt(new Ge("firestore",(o,{instanceIdentifier:r,options:a})=>{const l=o.getProvider("app").getImmediate(),d=new Lu(new bu(o.getProvider("auth-internal")),new Cu(o.getProvider("app-check-internal")),function(w,A){if(!Object.prototype.hasOwnProperty.apply(w.options,["projectId"]))throw new ae(ie.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new Mn(w.options.projectId,A)}(l,r),l);return a=Object.assign({useFetchStreams:n},a),d._setSettings(a),d},"PUBLIC").setMultipleInstances(!0)),pe(kr,"4.7.3",e),pe(kr,"4.7.3","esm2017")})();var Bu="firebase",xu="10.14.1";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */pe(Bu,xu,"app");function Zs(t,e){var n={};for(var o in t)Object.prototype.hasOwnProperty.call(t,o)&&e.indexOf(o)<0&&(n[o]=t[o]);if(t!=null&&typeof Object.getOwnPropertySymbols=="function")for(var r=0,o=Object.getOwnPropertySymbols(t);r<o.length;r++)e.indexOf(o[r])<0&&Object.prototype.propertyIsEnumerable.call(t,o[r])&&(n[o[r]]=t[o[r]]);return n}function Wi(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const Uu=Wi,Gi=new Gt("auth","Firebase",Wi());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const On=new Gs("@firebase/auth");function Fu(t,...e){On.logLevel<=x.WARN&&On.warn(`Auth (${it}): ${t}`,...e)}function An(t,...e){On.logLevel<=x.ERROR&&On.error(`Auth (${it}): ${t}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Pe(t,...e){throw eo(t,...e)}function ge(t,...e){return eo(t,...e)}function Ki(t,e,n){const o=Object.assign(Object.assign({},Uu()),{[e]:n});return new Gt("auth","Firebase",o).create(e,{appName:t.name})}function et(t){return Ki(t,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function eo(t,...e){if(typeof t!="string"){const n=e[0],o=[...e.slice(1)];return o[0]&&(o[0].appName=t.name),t._errorFactory.create(n,...o)}return Gi.create(t,...e)}function k(t,e,...n){if(!t)throw eo(e,...n)}function Ce(t){const e="INTERNAL ASSERTION FAILED: "+t;throw An(e),new Error(e)}function Ne(t,e){t||Ce(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Bs(){var t;return typeof self<"u"&&((t=self.location)===null||t===void 0?void 0:t.href)||""}function Hu(){return Br()==="http:"||Br()==="https:"}function Br(){var t;return typeof self<"u"&&((t=self.location)===null||t===void 0?void 0:t.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ju(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(Hu()||tl()||"connection"in navigator)?navigator.onLine:!0}function Vu(){if(typeof navigator>"u")return null;const t=navigator;return t.languages&&t.languages[0]||t.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xt{constructor(e,n){this.shortDelay=e,this.longDelay=n,Ne(n>e,"Short delay should be less than long delay!"),this.isMobile=Zc()||nl()}get(){return ju()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function to(t,e){Ne(t.emulator,"Emulator should always be set here");const{url:n}=t.emulator;return e?`${n}${e.startsWith("/")?e.slice(1):e}`:n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ji{static initialize(e,n,o){this.fetchImpl=e,n&&(this.headersImpl=n),o&&(this.responseImpl=o)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;Ce("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;Ce("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;Ce("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qu={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zu=new Xt(3e4,6e4);function no(t,e){return t.tenantId&&!e.tenantId?Object.assign(Object.assign({},e),{tenantId:t.tenantId}):e}async function It(t,e,n,o,r={}){return Xi(t,r,async()=>{let a={},l={};o&&(e==="GET"?l=o:a={body:JSON.stringify(o)});const d=Kt(Object.assign({key:t.config.apiKey},l)).slice(1),p=await t._getAdditionalHeaders();p["Content-Type"]="application/json",t.languageCode&&(p["X-Firebase-Locale"]=t.languageCode);const w=Object.assign({method:e,headers:p},a);return el()||(w.referrerPolicy="no-referrer"),Ji.fetch()(Yi(t,t.config.apiHost,n,d),w)})}async function Xi(t,e,n){t._canInitEmulator=!1;const o=Object.assign(Object.assign({},qu),e);try{const r=new Gu(t),a=await Promise.race([n(),r.promise]);r.clearNetworkTimeout();const l=await a.json();if("needConfirmation"in l)throw En(t,"account-exists-with-different-credential",l);if(a.ok&&!("errorMessage"in l))return l;{const d=a.ok?l.errorMessage:l.error.message,[p,w]=d.split(" : ");if(p==="FEDERATED_USER_ID_ALREADY_LINKED")throw En(t,"credential-already-in-use",l);if(p==="EMAIL_EXISTS")throw En(t,"email-already-in-use",l);if(p==="USER_DISABLED")throw En(t,"user-disabled",l);const A=o[p]||p.toLowerCase().replace(/[_\s]+/g,"-");if(w)throw Ki(t,A,w);Pe(t,A)}}catch(r){if(r instanceof Ee)throw r;Pe(t,"network-request-failed",{message:String(r)})}}async function Wu(t,e,n,o,r={}){const a=await It(t,e,n,o,r);return"mfaPendingCredential"in a&&Pe(t,"multi-factor-auth-required",{_serverResponse:a}),a}function Yi(t,e,n,o){const r=`${e}${n}?${o}`;return t.config.emulator?to(t.config,r):`${t.config.apiScheme}://${r}`}class Gu{constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((n,o)=>{this.timer=setTimeout(()=>o(ge(this.auth,"network-request-failed")),zu.get())})}clearNetworkTimeout(){clearTimeout(this.timer)}}function En(t,e,n){const o={appName:t.name};n.email&&(o.email=n.email),n.phoneNumber&&(o.phoneNumber=n.phoneNumber);const r=ge(t,e,o);return r.customData._tokenResponse=n,r}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ku(t,e){return It(t,"POST","/v1/accounts:delete",e)}async function Qi(t,e){return It(t,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Vt(t){if(t)try{const e=new Date(Number(t));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function Ju(t,e=!1){const n=rt(t),o=await n.getIdToken(e),r=so(o);k(r&&r.exp&&r.auth_time&&r.iat,n.auth,"internal-error");const a=typeof r.firebase=="object"?r.firebase:void 0,l=a==null?void 0:a.sign_in_provider;return{claims:r,token:o,authTime:Vt(Ds(r.auth_time)),issuedAtTime:Vt(Ds(r.iat)),expirationTime:Vt(Ds(r.exp)),signInProvider:l||null,signInSecondFactor:(a==null?void 0:a.sign_in_second_factor)||null}}function Ds(t){return Number(t)*1e3}function so(t){const[e,n,o]=t.split(".");if(e===void 0||n===void 0||o===void 0)return An("JWT malformed, contained fewer than 3 sections"),null;try{const r=Pi(n);return r?JSON.parse(r):(An("Failed to decode base64 JWT payload"),null)}catch(r){return An("Caught error parsing JWT payload as JSON",r==null?void 0:r.toString()),null}}function xr(t){const e=so(t);return k(e,"internal-error"),k(typeof e.exp<"u","internal-error"),k(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function zt(t,e,n=!1){if(n)return e;try{return await e}catch(o){throw o instanceof Ee&&Xu(o)&&t.auth.currentUser===t&&await t.auth.signOut(),o}}function Xu({code:t}){return t==="auth/user-disabled"||t==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yu{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){var n;if(e){const o=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),o}else{this.errorBackoff=3e4;const r=((n=this.user.stsTokenManager.expirationTime)!==null&&n!==void 0?n:0)-Date.now()-3e5;return Math.max(0,r)}}schedule(e=!1){if(!this.isRunning)return;const n=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},n)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xs{constructor(e,n){this.createdAt=e,this.lastLoginAt=n,this._initializeTime()}_initializeTime(){this.lastSignInTime=Vt(this.lastLoginAt),this.creationTime=Vt(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ln(t){var e;const n=t.auth,o=await t.getIdToken(),r=await zt(t,Qi(n,{idToken:o}));k(r==null?void 0:r.users.length,n,"internal-error");const a=r.users[0];t._notifyReloadListener(a);const l=!((e=a.providerUserInfo)===null||e===void 0)&&e.length?Zi(a.providerUserInfo):[],d=Zu(t.providerData,l),p=t.isAnonymous,w=!(t.email&&a.passwordHash)&&!(d!=null&&d.length),A=p?w:!1,D={uid:a.localId,displayName:a.displayName||null,photoURL:a.photoUrl||null,email:a.email||null,emailVerified:a.emailVerified||!1,phoneNumber:a.phoneNumber||null,tenantId:a.tenantId||null,providerData:d,metadata:new xs(a.createdAt,a.lastLoginAt),isAnonymous:A};Object.assign(t,D)}async function Qu(t){const e=rt(t);await Ln(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function Zu(t,e){return[...t.filter(o=>!e.some(r=>r.providerId===o.providerId)),...e]}function Zi(t){return t.map(e=>{var{providerId:n}=e,o=Zs(e,["providerId"]);return{providerId:n,uid:o.rawId||"",displayName:o.displayName||null,email:o.email||null,phoneNumber:o.phoneNumber||null,photoURL:o.photoUrl||null}})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ed(t,e){const n=await Xi(t,{},async()=>{const o=Kt({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:r,apiKey:a}=t.config,l=Yi(t,r,"/v1/token",`key=${a}`),d=await t._getAdditionalHeaders();return d["Content-Type"]="application/x-www-form-urlencoded",Ji.fetch()(l,{method:"POST",headers:d,body:o})});return{accessToken:n.access_token,expiresIn:n.expires_in,refreshToken:n.refresh_token}}async function td(t,e){return It(t,"POST","/v2/accounts:revokeToken",no(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gt{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){k(e.idToken,"internal-error"),k(typeof e.idToken<"u","internal-error"),k(typeof e.refreshToken<"u","internal-error");const n="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):xr(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,n)}updateFromIdToken(e){k(e.length!==0,"internal-error");const n=xr(e);this.updateTokensAndExpiration(e,null,n)}async getToken(e,n=!1){return!n&&this.accessToken&&!this.isExpired?this.accessToken:(k(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,n){const{accessToken:o,refreshToken:r,expiresIn:a}=await ed(e,n);this.updateTokensAndExpiration(o,r,Number(a))}updateTokensAndExpiration(e,n,o){this.refreshToken=n||null,this.accessToken=e||null,this.expirationTime=Date.now()+o*1e3}static fromJSON(e,n){const{refreshToken:o,accessToken:r,expirationTime:a}=n,l=new gt;return o&&(k(typeof o=="string","internal-error",{appName:e}),l.refreshToken=o),r&&(k(typeof r=="string","internal-error",{appName:e}),l.accessToken=r),a&&(k(typeof a=="number","internal-error",{appName:e}),l.expirationTime=a),l}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new gt,this.toJSON())}_performRefresh(){return Ce("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xe(t,e){k(typeof t=="string"||typeof t>"u","internal-error",{appName:e})}class De{constructor(e){var{uid:n,auth:o,stsTokenManager:r}=e,a=Zs(e,["uid","auth","stsTokenManager"]);this.providerId="firebase",this.proactiveRefresh=new Yu(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=n,this.auth=o,this.stsTokenManager=r,this.accessToken=r.accessToken,this.displayName=a.displayName||null,this.email=a.email||null,this.emailVerified=a.emailVerified||!1,this.phoneNumber=a.phoneNumber||null,this.photoURL=a.photoURL||null,this.isAnonymous=a.isAnonymous||!1,this.tenantId=a.tenantId||null,this.providerData=a.providerData?[...a.providerData]:[],this.metadata=new xs(a.createdAt||void 0,a.lastLoginAt||void 0)}async getIdToken(e){const n=await zt(this,this.stsTokenManager.getToken(this.auth,e));return k(n,this.auth,"internal-error"),this.accessToken!==n&&(this.accessToken=n,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),n}getIdTokenResult(e){return Ju(this,e)}reload(){return Qu(this)}_assign(e){this!==e&&(k(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(n=>Object.assign({},n)),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const n=new De(Object.assign(Object.assign({},this),{auth:e,stsTokenManager:this.stsTokenManager._clone()}));return n.metadata._copy(this.metadata),n}_onReload(e){k(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,n=!1){let o=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),o=!0),n&&await Ln(this),await this.auth._persistUserIfCurrent(this),o&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(qe(this.auth.app))return Promise.reject(et(this.auth));const e=await this.getIdToken();return await zt(this,Ku(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return Object.assign(Object.assign({uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>Object.assign({},e)),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId},this.metadata.toJSON()),{apiKey:this.auth.config.apiKey,appName:this.auth.name})}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,n){var o,r,a,l,d,p,w,A;const D=(o=n.displayName)!==null&&o!==void 0?o:void 0,R=(r=n.email)!==null&&r!==void 0?r:void 0,H=(a=n.phoneNumber)!==null&&a!==void 0?a:void 0,N=(l=n.photoURL)!==null&&l!==void 0?l:void 0,V=(d=n.tenantId)!==null&&d!==void 0?d:void 0,M=(p=n._redirectEventId)!==null&&p!==void 0?p:void 0,re=(w=n.createdAt)!==null&&w!==void 0?w:void 0,ee=(A=n.lastLoginAt)!==null&&A!==void 0?A:void 0,{uid:q,emailVerified:z,isAnonymous:ce,providerData:K,stsTokenManager:y}=n;k(q&&y,e,"internal-error");const h=gt.fromJSON(this.name,y);k(typeof q=="string",e,"internal-error"),xe(D,e.name),xe(R,e.name),k(typeof z=="boolean",e,"internal-error"),k(typeof ce=="boolean",e,"internal-error"),xe(H,e.name),xe(N,e.name),xe(V,e.name),xe(M,e.name),xe(re,e.name),xe(ee,e.name);const m=new De({uid:q,auth:e,email:R,emailVerified:z,displayName:D,isAnonymous:ce,photoURL:N,phoneNumber:H,tenantId:V,stsTokenManager:h,createdAt:re,lastLoginAt:ee});return K&&Array.isArray(K)&&(m.providerData=K.map(g=>Object.assign({},g))),M&&(m._redirectEventId=M),m}static async _fromIdTokenResponse(e,n,o=!1){const r=new gt;r.updateFromServerResponse(n);const a=new De({uid:n.localId,auth:e,stsTokenManager:r,isAnonymous:o});return await Ln(a),a}static async _fromGetAccountInfoResponse(e,n,o){const r=n.users[0];k(r.localId!==void 0,"internal-error");const a=r.providerUserInfo!==void 0?Zi(r.providerUserInfo):[],l=!(r.email&&r.passwordHash)&&!(a!=null&&a.length),d=new gt;d.updateFromIdToken(o);const p=new De({uid:r.localId,auth:e,stsTokenManager:d,isAnonymous:l}),w={uid:r.localId,displayName:r.displayName||null,photoURL:r.photoUrl||null,email:r.email||null,emailVerified:r.emailVerified||!1,phoneNumber:r.phoneNumber||null,tenantId:r.tenantId||null,providerData:a,metadata:new xs(r.createdAt,r.lastLoginAt),isAnonymous:!(r.email&&r.passwordHash)&&!(a!=null&&a.length)};return Object.assign(p,w),p}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ur=new Map;function Re(t){Ne(t instanceof Function,"Expected a class definition");let e=Ur.get(t);return e?(Ne(e instanceof t,"Instance stored in cache mismatched with class"),e):(e=new t,Ur.set(t,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ea{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,n){this.storage[e]=n}async _get(e){const n=this.storage[e];return n===void 0?null:n}async _remove(e){delete this.storage[e]}_addListener(e,n){}_removeListener(e,n){}}ea.type="NONE";const Fr=ea;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Sn(t,e,n){return`firebase:${t}:${e}:${n}`}class vt{constructor(e,n,o){this.persistence=e,this.auth=n,this.userKey=o;const{config:r,name:a}=this.auth;this.fullUserKey=Sn(this.userKey,r.apiKey,a),this.fullPersistenceKey=Sn("persistence",r.apiKey,a),this.boundEventHandler=n._onStorageEvent.bind(n),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);return e?De._fromJSON(this.auth,e):null}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const n=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,n)return this.setCurrentUser(n)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,n,o="authUser"){if(!n.length)return new vt(Re(Fr),e,o);const r=(await Promise.all(n.map(async w=>{if(await w._isAvailable())return w}))).filter(w=>w);let a=r[0]||Re(Fr);const l=Sn(o,e.config.apiKey,e.name);let d=null;for(const w of n)try{const A=await w._get(l);if(A){const D=De._fromJSON(e,A);w!==a&&(d=D),a=w;break}}catch{}const p=r.filter(w=>w._shouldAllowMigration);return!a._shouldAllowMigration||!p.length?new vt(a,e,o):(a=p[0],d&&await a._set(l,d.toJSON()),await Promise.all(n.map(async w=>{if(w!==a)try{await w._remove(l)}catch{}})),new vt(a,e,o))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Hr(t){const e=t.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(oa(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(ta(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(ia(e))return"Blackberry";if(aa(e))return"Webos";if(na(e))return"Safari";if((e.includes("chrome/")||sa(e))&&!e.includes("edge/"))return"Chrome";if(ra(e))return"Android";{const n=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,o=t.match(n);if((o==null?void 0:o.length)===2)return o[1]}return"Other"}function ta(t=oe()){return/firefox\//i.test(t)}function na(t=oe()){const e=t.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function sa(t=oe()){return/crios\//i.test(t)}function oa(t=oe()){return/iemobile/i.test(t)}function ra(t=oe()){return/android/i.test(t)}function ia(t=oe()){return/blackberry/i.test(t)}function aa(t=oe()){return/webos/i.test(t)}function oo(t=oe()){return/iphone|ipad|ipod/i.test(t)||/macintosh/i.test(t)&&/mobile/i.test(t)}function nd(t=oe()){var e;return oo(t)&&!!(!((e=window.navigator)===null||e===void 0)&&e.standalone)}function sd(){return sl()&&document.documentMode===10}function ca(t=oe()){return oo(t)||ra(t)||aa(t)||ia(t)||/windows phone/i.test(t)||oa(t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function la(t,e=[]){let n;switch(t){case"Browser":n=Hr(oe());break;case"Worker":n=`${Hr(oe())}-${t}`;break;default:n=t}const o=e.length?e.join(","):"FirebaseCore-web";return`${n}/JsCore/${it}/${o}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class od{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,n){const o=a=>new Promise((l,d)=>{try{const p=e(a);l(p)}catch(p){d(p)}});o.onAbort=n,this.queue.push(o);const r=this.queue.length-1;return()=>{this.queue[r]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const n=[];try{for(const o of this.queue)await o(e),o.onAbort&&n.push(o.onAbort)}catch(o){n.reverse();for(const r of n)try{r()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:o==null?void 0:o.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function rd(t,e={}){return It(t,"GET","/v2/passwordPolicy",no(t,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const id=6;class ad{constructor(e){var n,o,r,a;const l=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=(n=l.minPasswordLength)!==null&&n!==void 0?n:id,l.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=l.maxPasswordLength),l.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=l.containsLowercaseCharacter),l.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=l.containsUppercaseCharacter),l.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=l.containsNumericCharacter),l.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=l.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=(r=(o=e.allowedNonAlphanumericCharacters)===null||o===void 0?void 0:o.join(""))!==null&&r!==void 0?r:"",this.forceUpgradeOnSignin=(a=e.forceUpgradeOnSignin)!==null&&a!==void 0?a:!1,this.schemaVersion=e.schemaVersion}validatePassword(e){var n,o,r,a,l,d;const p={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,p),this.validatePasswordCharacterOptions(e,p),p.isValid&&(p.isValid=(n=p.meetsMinPasswordLength)!==null&&n!==void 0?n:!0),p.isValid&&(p.isValid=(o=p.meetsMaxPasswordLength)!==null&&o!==void 0?o:!0),p.isValid&&(p.isValid=(r=p.containsLowercaseLetter)!==null&&r!==void 0?r:!0),p.isValid&&(p.isValid=(a=p.containsUppercaseLetter)!==null&&a!==void 0?a:!0),p.isValid&&(p.isValid=(l=p.containsNumericCharacter)!==null&&l!==void 0?l:!0),p.isValid&&(p.isValid=(d=p.containsNonAlphanumericCharacter)!==null&&d!==void 0?d:!0),p}validatePasswordLengthOptions(e,n){const o=this.customStrengthOptions.minPasswordLength,r=this.customStrengthOptions.maxPasswordLength;o&&(n.meetsMinPasswordLength=e.length>=o),r&&(n.meetsMaxPasswordLength=e.length<=r)}validatePasswordCharacterOptions(e,n){this.updatePasswordCharacterOptionsStatuses(n,!1,!1,!1,!1);let o;for(let r=0;r<e.length;r++)o=e.charAt(r),this.updatePasswordCharacterOptionsStatuses(n,o>="a"&&o<="z",o>="A"&&o<="Z",o>="0"&&o<="9",this.allowedNonAlphanumericCharacters.includes(o))}updatePasswordCharacterOptionsStatuses(e,n,o,r,a){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=n)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=o)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=r)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=a))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cd{constructor(e,n,o,r){this.app=e,this.heartbeatServiceProvider=n,this.appCheckServiceProvider=o,this.config=r,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new jr(this),this.idTokenSubscription=new jr(this),this.beforeStateQueue=new od(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=Gi,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=r.sdkClientVersion}_initializeWithPersistence(e,n){return n&&(this._popupRedirectResolver=Re(n)),this._initializationPromise=this.queue(async()=>{var o,r;if(!this._deleted&&(this.persistenceManager=await vt.create(this,e),!this._deleted)){if(!((o=this._popupRedirectResolver)===null||o===void 0)&&o._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(n),this.lastNotifiedUid=((r=this.currentUser)===null||r===void 0?void 0:r.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const n=await Qi(this,{idToken:e}),o=await De._fromGetAccountInfoResponse(this,n,e);await this.directlySetCurrentUser(o)}catch(n){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",n),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var n;if(qe(this.app)){const l=this.app.settings.authIdToken;return l?new Promise(d=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(l).then(d,d))}):this.directlySetCurrentUser(null)}const o=await this.assertedPersistence.getCurrentUser();let r=o,a=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const l=(n=this.redirectUser)===null||n===void 0?void 0:n._redirectEventId,d=r==null?void 0:r._redirectEventId,p=await this.tryRedirectSignIn(e);(!l||l===d)&&(p!=null&&p.user)&&(r=p.user,a=!0)}if(!r)return this.directlySetCurrentUser(null);if(!r._redirectEventId){if(a)try{await this.beforeStateQueue.runMiddleware(r)}catch(l){r=o,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(l))}return r?this.reloadAndSetCurrentUserOrClear(r):this.directlySetCurrentUser(null)}return k(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===r._redirectEventId?this.directlySetCurrentUser(r):this.reloadAndSetCurrentUserOrClear(r)}async tryRedirectSignIn(e){let n=null;try{n=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return n}async reloadAndSetCurrentUserOrClear(e){try{await Ln(e)}catch(n){if((n==null?void 0:n.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=Vu()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(qe(this.app))return Promise.reject(et(this));const n=e?rt(e):null;return n&&k(n.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(n&&n._clone(this))}async _updateCurrentUser(e,n=!1){if(!this._deleted)return e&&k(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),n||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return qe(this.app)?Promise.reject(et(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return qe(this.app)?Promise.reject(et(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(Re(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const n=this._getPasswordPolicyInternal();return n.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):n.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await rd(this),n=new ad(e);this.tenantId===null?this._projectPasswordPolicy=n:this._tenantPasswordPolicies[this.tenantId]=n}_getPersistence(){return this.assertedPersistence.persistence.type}_updateErrorMap(e){this._errorFactory=new Gt("auth","Firebase",e())}onAuthStateChanged(e,n,o){return this.registerStateListener(this.authStateSubscription,e,n,o)}beforeAuthStateChanged(e,n){return this.beforeStateQueue.pushCallback(e,n)}onIdTokenChanged(e,n,o){return this.registerStateListener(this.idTokenSubscription,e,n,o)}authStateReady(){return new Promise((e,n)=>{if(this.currentUser)e();else{const o=this.onAuthStateChanged(()=>{o(),e()},n)}})}async revokeAccessToken(e){if(this.currentUser){const n=await this.currentUser.getIdToken(),o={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:n};this.tenantId!=null&&(o.tenantId=this.tenantId),await td(this,o)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)===null||e===void 0?void 0:e.toJSON()}}async _setRedirectUser(e,n){const o=await this.getOrInitRedirectPersistenceManager(n);return e===null?o.removeCurrentUser():o.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const n=e&&Re(e)||this._popupRedirectResolver;k(n,this,"argument-error"),this.redirectPersistenceManager=await vt.create(this,[Re(n._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var n,o;return this._isInitialized&&await this.queue(async()=>{}),((n=this._currentUser)===null||n===void 0?void 0:n._redirectEventId)===e?this._currentUser:((o=this.redirectUser)===null||o===void 0?void 0:o._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var e,n;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const o=(n=(e=this.currentUser)===null||e===void 0?void 0:e.uid)!==null&&n!==void 0?n:null;this.lastNotifiedUid!==o&&(this.lastNotifiedUid=o,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,n,o,r){if(this._deleted)return()=>{};const a=typeof n=="function"?n:n.next.bind(n);let l=!1;const d=this._isInitialized?Promise.resolve():this._initializationPromise;if(k(d,this,"internal-error"),d.then(()=>{l||a(this.currentUser)}),typeof n=="function"){const p=e.addObserver(n,o,r);return()=>{l=!0,p()}}else{const p=e.addObserver(n);return()=>{l=!0,p()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return k(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=la(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var e;const n={"X-Client-Version":this.clientVersion};this.app.options.appId&&(n["X-Firebase-gmpid"]=this.app.options.appId);const o=await((e=this.heartbeatServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getHeartbeatsHeader());o&&(n["X-Firebase-Client"]=o);const r=await this._getAppCheckToken();return r&&(n["X-Firebase-AppCheck"]=r),n}async _getAppCheckToken(){var e;const n=await((e=this.appCheckServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getToken());return n!=null&&n.error&&Fu(`Error while retrieving App Check token: ${n.error}`),n==null?void 0:n.token}}function ro(t){return rt(t)}class jr{constructor(e){this.auth=e,this.observer=null,this.addObserver=ul(n=>this.observer=n)}get next(){return k(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let io={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function ld(t){io=t}function ud(t){return io.loadJS(t)}function dd(){return io.gapiScript}function hd(t){return`__${t}${Math.floor(Math.random()*1e6)}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function fd(t,e){const n=qn(t,"auth");if(n.isInitialized()){const r=n.getImmediate(),a=n.getOptions();if(Pn(a,e??{}))return r;Pe(r,"already-initialized")}return n.initialize({options:e})}function md(t,e){const n=(e==null?void 0:e.persistence)||[],o=(Array.isArray(n)?n:[n]).map(Re);e!=null&&e.errorMap&&t._updateErrorMap(e.errorMap),t._initializeWithPersistence(o,e==null?void 0:e.popupRedirectResolver)}function pd(t,e,n){const o=ro(t);k(o._canInitEmulator,o,"emulator-config-failed"),k(/^https?:\/\//.test(e),o,"invalid-emulator-scheme");const r=!1,a=ua(e),{host:l,port:d}=gd(e),p=d===null?"":`:${d}`;o.config.emulator={url:`${a}//${l}${p}/`},o.settings.appVerificationDisabledForTesting=!0,o.emulatorConfig=Object.freeze({host:l,port:d,protocol:a.replace(":",""),options:Object.freeze({disableWarnings:r})}),vd()}function ua(t){const e=t.indexOf(":");return e<0?"":t.substr(0,e+1)}function gd(t){const e=ua(t),n=/(\/\/)?([^?#/]+)/.exec(t.substr(e.length));if(!n)return{host:"",port:null};const o=n[2].split("@").pop()||"",r=/^(\[[^\]]+\])(:|$)/.exec(o);if(r){const a=r[1];return{host:a,port:Vr(o.substr(a.length+1))}}else{const[a,l]=o.split(":");return{host:a,port:Vr(l)}}}function Vr(t){if(!t)return null;const e=Number(t);return isNaN(e)?null:e}function vd(){function t(){const e=document.createElement("p"),n=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",n.position="fixed",n.width="100%",n.backgroundColor="#ffffff",n.border=".1em solid #000000",n.color="#b50000",n.bottom="0px",n.left="0px",n.margin="0px",n.zIndex="10000",n.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",t):t())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class da{constructor(e,n){this.providerId=e,this.signInMethod=n}toJSON(){return Ce("not implemented")}_getIdTokenResponse(e){return Ce("not implemented")}_linkToIdToken(e,n){return Ce("not implemented")}_getReauthenticationResolver(e){return Ce("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function yt(t,e){return Wu(t,"POST","/v1/accounts:signInWithIdp",no(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yd="http://localhost";class nt extends da{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const n=new nt(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(n.idToken=e.idToken),e.accessToken&&(n.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(n.nonce=e.nonce),e.pendingToken&&(n.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(n.accessToken=e.oauthToken,n.secret=e.oauthTokenSecret):Pe("argument-error"),n}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const n=typeof e=="string"?JSON.parse(e):e,{providerId:o,signInMethod:r}=n,a=Zs(n,["providerId","signInMethod"]);if(!o||!r)return null;const l=new nt(o,r);return l.idToken=a.idToken||void 0,l.accessToken=a.accessToken||void 0,l.secret=a.secret,l.nonce=a.nonce,l.pendingToken=a.pendingToken||null,l}_getIdTokenResponse(e){const n=this.buildRequest();return yt(e,n)}_linkToIdToken(e,n){const o=this.buildRequest();return o.idToken=n,yt(e,o)}_getReauthenticationResolver(e){const n=this.buildRequest();return n.autoCreate=!1,yt(e,n)}buildRequest(){const e={requestUri:yd,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const n={};this.idToken&&(n.id_token=this.idToken),this.accessToken&&(n.access_token=this.accessToken),this.secret&&(n.oauth_token_secret=this.secret),n.providerId=this.providerId,this.nonce&&!this.pendingToken&&(n.nonce=this.nonce),e.postBody=Kt(n)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ha{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yt extends ha{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fe extends Yt{constructor(){super("facebook.com")}static credential(e){return nt._fromParams({providerId:Fe.PROVIDER_ID,signInMethod:Fe.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return Fe.credentialFromTaggedObject(e)}static credentialFromError(e){return Fe.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return Fe.credential(e.oauthAccessToken)}catch{return null}}}Fe.FACEBOOK_SIGN_IN_METHOD="facebook.com";Fe.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class He extends Yt{constructor(){super("google.com"),this.addScope("profile")}static credential(e,n){return nt._fromParams({providerId:He.PROVIDER_ID,signInMethod:He.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:n})}static credentialFromResult(e){return He.credentialFromTaggedObject(e)}static credentialFromError(e){return He.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:n,oauthAccessToken:o}=e;if(!n&&!o)return null;try{return He.credential(n,o)}catch{return null}}}He.GOOGLE_SIGN_IN_METHOD="google.com";He.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class je extends Yt{constructor(){super("github.com")}static credential(e){return nt._fromParams({providerId:je.PROVIDER_ID,signInMethod:je.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return je.credentialFromTaggedObject(e)}static credentialFromError(e){return je.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return je.credential(e.oauthAccessToken)}catch{return null}}}je.GITHUB_SIGN_IN_METHOD="github.com";je.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ve extends Yt{constructor(){super("twitter.com")}static credential(e,n){return nt._fromParams({providerId:Ve.PROVIDER_ID,signInMethod:Ve.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:n})}static credentialFromResult(e){return Ve.credentialFromTaggedObject(e)}static credentialFromError(e){return Ve.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:n,oauthTokenSecret:o}=e;if(!n||!o)return null;try{return Ve.credential(n,o)}catch{return null}}}Ve.TWITTER_SIGN_IN_METHOD="twitter.com";Ve.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Et{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,n,o,r=!1){const a=await De._fromIdTokenResponse(e,o,r),l=qr(o);return new Et({user:a,providerId:l,_tokenResponse:o,operationType:n})}static async _forOperation(e,n,o){await e._updateTokensIfNecessary(o,!0);const r=qr(o);return new Et({user:e,providerId:r,_tokenResponse:o,operationType:n})}}function qr(t){return t.providerId?t.providerId:"phoneNumber"in t?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $n extends Ee{constructor(e,n,o,r){var a;super(n.code,n.message),this.operationType=o,this.user=r,Object.setPrototypeOf(this,$n.prototype),this.customData={appName:e.name,tenantId:(a=e.tenantId)!==null&&a!==void 0?a:void 0,_serverResponse:n.customData._serverResponse,operationType:o}}static _fromErrorAndOperation(e,n,o,r){return new $n(e,n,o,r)}}function fa(t,e,n,o){return(e==="reauthenticate"?n._getReauthenticationResolver(t):n._getIdTokenResponse(t)).catch(a=>{throw a.code==="auth/multi-factor-auth-required"?$n._fromErrorAndOperation(t,a,e,o):a})}async function _d(t,e,n=!1){const o=await zt(t,e._linkToIdToken(t.auth,await t.getIdToken()),n);return Et._forOperation(t,"link",o)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ed(t,e,n=!1){const{auth:o}=t;if(qe(o.app))return Promise.reject(et(o));const r="reauthenticate";try{const a=await zt(t,fa(o,r,e,t),n);k(a.idToken,o,"internal-error");const l=so(a.idToken);k(l,o,"internal-error");const{sub:d}=l;return k(t.uid===d,o,"user-mismatch"),Et._forOperation(t,r,a)}catch(a){throw(a==null?void 0:a.code)==="auth/user-not-found"&&Pe(o,"user-mismatch"),a}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Id(t,e,n=!1){if(qe(t.app))return Promise.reject(et(t));const o="signIn",r=await fa(t,o,e),a=await Et._fromIdTokenResponse(t,o,r);return n||await t._updateCurrentUser(a.user),a}function wd(t,e,n,o){return rt(t).onIdTokenChanged(e,n,o)}function bd(t,e,n){return rt(t).beforeAuthStateChanged(e,n)}const Bn="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ma{constructor(e,n){this.storageRetriever=e,this.type=n}_isAvailable(){try{return this.storage?(this.storage.setItem(Bn,"1"),this.storage.removeItem(Bn),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,n){return this.storage.setItem(e,JSON.stringify(n)),Promise.resolve()}_get(e){const n=this.storage.getItem(e);return Promise.resolve(n?JSON.parse(n):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Td=1e3,Ad=10;class pa extends ma{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,n)=>this.onStorageEvent(e,n),this.listeners={},this.localCache={},this.pollTimer=null,this.fallbackToPolling=ca(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const n of Object.keys(this.listeners)){const o=this.storage.getItem(n),r=this.localCache[n];o!==r&&e(n,r,o)}}onStorageEvent(e,n=!1){if(!e.key){this.forAllChangedKeys((l,d,p)=>{this.notifyListeners(l,p)});return}const o=e.key;n?this.detachListener():this.stopPolling();const r=()=>{const l=this.storage.getItem(o);!n&&this.localCache[o]===l||this.notifyListeners(o,l)},a=this.storage.getItem(o);sd()&&a!==e.newValue&&e.newValue!==e.oldValue?setTimeout(r,Ad):r()}notifyListeners(e,n){this.localCache[e]=n;const o=this.listeners[e];if(o)for(const r of Array.from(o))r(n&&JSON.parse(n))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,n,o)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:n,newValue:o}),!0)})},Td)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,n){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(n)}_removeListener(e,n){this.listeners[e]&&(this.listeners[e].delete(n),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,n){await super._set(e,n),this.localCache[e]=JSON.stringify(n)}async _get(e){const n=await super._get(e);return this.localCache[e]=JSON.stringify(n),n}async _remove(e){await super._remove(e),delete this.localCache[e]}}pa.type="LOCAL";const Sd=pa;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ga extends ma{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,n){}_removeListener(e,n){}}ga.type="SESSION";const va=ga;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Cd(t){return Promise.all(t.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(n){return{fulfilled:!1,reason:n}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zn{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const n=this.receivers.find(r=>r.isListeningto(e));if(n)return n;const o=new zn(e);return this.receivers.push(o),o}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const n=e,{eventId:o,eventType:r,data:a}=n.data,l=this.handlersMap[r];if(!(l!=null&&l.size))return;n.ports[0].postMessage({status:"ack",eventId:o,eventType:r});const d=Array.from(l).map(async w=>w(n.origin,a)),p=await Cd(d);n.ports[0].postMessage({status:"done",eventId:o,eventType:r,response:p})}_subscribe(e,n){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(n)}_unsubscribe(e,n){this.handlersMap[e]&&n&&this.handlersMap[e].delete(n),(!n||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}zn.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ao(t="",e=10){let n="";for(let o=0;o<e;o++)n+=Math.floor(Math.random()*10);return t+n}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dd{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,n,o=50){const r=typeof MessageChannel<"u"?new MessageChannel:null;if(!r)throw new Error("connection_unavailable");let a,l;return new Promise((d,p)=>{const w=ao("",20);r.port1.start();const A=setTimeout(()=>{p(new Error("unsupported_event"))},o);l={messageChannel:r,onMessage(D){const R=D;if(R.data.eventId===w)switch(R.data.status){case"ack":clearTimeout(A),a=setTimeout(()=>{p(new Error("timeout"))},3e3);break;case"done":clearTimeout(a),d(R.data.response);break;default:clearTimeout(A),clearTimeout(a),p(new Error("invalid_response"));break}}},this.handlers.add(l),r.port1.addEventListener("message",l.onMessage),this.target.postMessage({eventType:e,eventId:w,data:n},[r.port2])}).finally(()=>{l&&this.removeMessageHandler(l)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ve(){return window}function Rd(t){ve().location.href=t}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ya(){return typeof ve().WorkerGlobalScope<"u"&&typeof ve().importScripts=="function"}async function kd(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function Pd(){var t;return((t=navigator==null?void 0:navigator.serviceWorker)===null||t===void 0?void 0:t.controller)||null}function Nd(){return ya()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _a="firebaseLocalStorageDb",Md=1,xn="firebaseLocalStorage",Ea="fbase_key";class Qt{constructor(e){this.request=e}toPromise(){return new Promise((e,n)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{n(this.request.error)})})}}function Wn(t,e){return t.transaction([xn],e?"readwrite":"readonly").objectStore(xn)}function Od(){const t=indexedDB.deleteDatabase(_a);return new Qt(t).toPromise()}function Us(){const t=indexedDB.open(_a,Md);return new Promise((e,n)=>{t.addEventListener("error",()=>{n(t.error)}),t.addEventListener("upgradeneeded",()=>{const o=t.result;try{o.createObjectStore(xn,{keyPath:Ea})}catch(r){n(r)}}),t.addEventListener("success",async()=>{const o=t.result;o.objectStoreNames.contains(xn)?e(o):(o.close(),await Od(),e(await Us()))})})}async function zr(t,e,n){const o=Wn(t,!0).put({[Ea]:e,value:n});return new Qt(o).toPromise()}async function Ld(t,e){const n=Wn(t,!1).get(e),o=await new Qt(n).toPromise();return o===void 0?null:o.value}function Wr(t,e){const n=Wn(t,!0).delete(e);return new Qt(n).toPromise()}const $d=800,Bd=3;class Ia{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await Us(),this.db)}async _withRetries(e){let n=0;for(;;)try{const o=await this._openDb();return await e(o)}catch(o){if(n++>Bd)throw o;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return ya()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=zn._getInstance(Nd()),this.receiver._subscribe("keyChanged",async(e,n)=>({keyProcessed:(await this._poll()).includes(n.key)})),this.receiver._subscribe("ping",async(e,n)=>["keyChanged"])}async initializeSender(){var e,n;if(this.activeServiceWorker=await kd(),!this.activeServiceWorker)return;this.sender=new Dd(this.activeServiceWorker);const o=await this.sender._send("ping",{},800);o&&!((e=o[0])===null||e===void 0)&&e.fulfilled&&!((n=o[0])===null||n===void 0)&&n.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||Pd()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await Us();return await zr(e,Bn,"1"),await Wr(e,Bn),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,n){return this._withPendingWrite(async()=>(await this._withRetries(o=>zr(o,e,n)),this.localCache[e]=n,this.notifyServiceWorker(e)))}async _get(e){const n=await this._withRetries(o=>Ld(o,e));return this.localCache[e]=n,n}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(n=>Wr(n,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(r=>{const a=Wn(r,!1).getAll();return new Qt(a).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const n=[],o=new Set;if(e.length!==0)for(const{fbase_key:r,value:a}of e)o.add(r),JSON.stringify(this.localCache[r])!==JSON.stringify(a)&&(this.notifyListeners(r,a),n.push(r));for(const r of Object.keys(this.localCache))this.localCache[r]&&!o.has(r)&&(this.notifyListeners(r,null),n.push(r));return n}notifyListeners(e,n){this.localCache[e]=n;const o=this.listeners[e];if(o)for(const r of Array.from(o))r(n)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),$d)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,n){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(n)}_removeListener(e,n){this.listeners[e]&&(this.listeners[e].delete(n),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}Ia.type="LOCAL";const xd=Ia;new Xt(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ud(t,e){return e?Re(e):(k(t._popupRedirectResolver,t,"argument-error"),t._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class co extends da{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return yt(e,this._buildIdpRequest())}_linkToIdToken(e,n){return yt(e,this._buildIdpRequest(n))}_getReauthenticationResolver(e){return yt(e,this._buildIdpRequest())}_buildIdpRequest(e){const n={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(n.idToken=e),n}}function Fd(t){return Id(t.auth,new co(t),t.bypassAuthState)}function Hd(t){const{auth:e,user:n}=t;return k(n,e,"internal-error"),Ed(n,new co(t),t.bypassAuthState)}async function jd(t){const{auth:e,user:n}=t;return k(n,e,"internal-error"),_d(n,new co(t),t.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wa{constructor(e,n,o,r,a=!1){this.auth=e,this.resolver=o,this.user=r,this.bypassAuthState=a,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(n)?n:[n]}execute(){return new Promise(async(e,n)=>{this.pendingPromise={resolve:e,reject:n};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(o){this.reject(o)}})}async onAuthEvent(e){const{urlResponse:n,sessionId:o,postBody:r,tenantId:a,error:l,type:d}=e;if(l){this.reject(l);return}const p={auth:this.auth,requestUri:n,sessionId:o,tenantId:a||void 0,postBody:r||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(d)(p))}catch(w){this.reject(w)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return Fd;case"linkViaPopup":case"linkViaRedirect":return jd;case"reauthViaPopup":case"reauthViaRedirect":return Hd;default:Pe(this.auth,"internal-error")}}resolve(e){Ne(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){Ne(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vd=new Xt(2e3,1e4);class pt extends wa{constructor(e,n,o,r,a){super(e,n,r,a),this.provider=o,this.authWindow=null,this.pollId=null,pt.currentPopupAction&&pt.currentPopupAction.cancel(),pt.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return k(e,this.auth,"internal-error"),e}async onExecution(){Ne(this.filter.length===1,"Popup operations only handle one event");const e=ao();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(n=>{this.reject(n)}),this.resolver._isIframeWebStorageSupported(this.auth,n=>{n||this.reject(ge(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)===null||e===void 0?void 0:e.associatedEvent)||null}cancel(){this.reject(ge(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,pt.currentPopupAction=null}pollUserCancellation(){const e=()=>{var n,o;if(!((o=(n=this.authWindow)===null||n===void 0?void 0:n.window)===null||o===void 0)&&o.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(ge(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,Vd.get())};e()}}pt.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qd="pendingRedirect",Cn=new Map;class zd extends wa{constructor(e,n,o=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],n,void 0,o),this.eventId=null}async execute(){let e=Cn.get(this.auth._key());if(!e){try{const o=await Wd(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(o)}catch(n){e=()=>Promise.reject(n)}Cn.set(this.auth._key(),e)}return this.bypassAuthState||Cn.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const n=await this.auth._redirectUserForId(e.eventId);if(n)return this.user=n,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function Wd(t,e){const n=Jd(e),o=Kd(t);if(!await o._isAvailable())return!1;const r=await o._get(n)==="true";return await o._remove(n),r}function Gd(t,e){Cn.set(t._key(),e)}function Kd(t){return Re(t._redirectPersistence)}function Jd(t){return Sn(qd,t.config.apiKey,t.name)}async function Xd(t,e,n=!1){if(qe(t.app))return Promise.reject(et(t));const o=ro(t),r=Ud(o,e),l=await new zd(o,r,n).execute();return l&&!n&&(delete l.user._redirectEventId,await o._persistUserIfCurrent(l.user),await o._setRedirectUser(null,e)),l}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Yd=10*60*1e3;class Qd{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let n=!1;return this.consumers.forEach(o=>{this.isEventForConsumer(e,o)&&(n=!0,this.sendToConsumer(e,o),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!Zd(e)||(this.hasHandledPotentialRedirect=!0,n||(this.queuedRedirectEvent=e,n=!0)),n}sendToConsumer(e,n){var o;if(e.error&&!ba(e)){const r=((o=e.error.code)===null||o===void 0?void 0:o.split("auth/")[1])||"internal-error";n.onError(ge(this.auth,r))}else n.onAuthEvent(e)}isEventForConsumer(e,n){const o=n.eventId===null||!!e.eventId&&e.eventId===n.eventId;return n.filter.includes(e.type)&&o}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=Yd&&this.cachedEventUids.clear(),this.cachedEventUids.has(Gr(e))}saveEventToCache(e){this.cachedEventUids.add(Gr(e)),this.lastProcessedEventTime=Date.now()}}function Gr(t){return[t.type,t.eventId,t.sessionId,t.tenantId].filter(e=>e).join("-")}function ba({type:t,error:e}){return t==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function Zd(t){switch(t.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return ba(t);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function eh(t,e={}){return It(t,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const th=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,nh=/^https?/;async function sh(t){if(t.config.emulator)return;const{authorizedDomains:e}=await eh(t);for(const n of e)try{if(oh(n))return}catch{}Pe(t,"unauthorized-domain")}function oh(t){const e=Bs(),{protocol:n,hostname:o}=new URL(e);if(t.startsWith("chrome-extension://")){const l=new URL(t);return l.hostname===""&&o===""?n==="chrome-extension:"&&t.replace("chrome-extension://","")===e.replace("chrome-extension://",""):n==="chrome-extension:"&&l.hostname===o}if(!nh.test(n))return!1;if(th.test(t))return o===t;const r=t.replace(/\./g,"\\.");return new RegExp("^(.+\\."+r+"|"+r+")$","i").test(o)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rh=new Xt(3e4,6e4);function Kr(){const t=ve().___jsl;if(t!=null&&t.H){for(const e of Object.keys(t.H))if(t.H[e].r=t.H[e].r||[],t.H[e].L=t.H[e].L||[],t.H[e].r=[...t.H[e].L],t.CP)for(let n=0;n<t.CP.length;n++)t.CP[n]=null}}function ih(t){return new Promise((e,n)=>{var o,r,a;function l(){Kr(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{Kr(),n(ge(t,"network-request-failed"))},timeout:rh.get()})}if(!((r=(o=ve().gapi)===null||o===void 0?void 0:o.iframes)===null||r===void 0)&&r.Iframe)e(gapi.iframes.getContext());else if(!((a=ve().gapi)===null||a===void 0)&&a.load)l();else{const d=hd("iframefcb");return ve()[d]=()=>{gapi.load?l():n(ge(t,"network-request-failed"))},ud(`${dd()}?onload=${d}`).catch(p=>n(p))}}).catch(e=>{throw Dn=null,e})}let Dn=null;function ah(t){return Dn=Dn||ih(t),Dn}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ch=new Xt(5e3,15e3),lh="__/auth/iframe",uh="emulator/auth/iframe",dh={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},hh=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function fh(t){const e=t.config;k(e.authDomain,t,"auth-domain-config-required");const n=e.emulator?to(e,uh):`https://${t.config.authDomain}/${lh}`,o={apiKey:e.apiKey,appName:t.name,v:it},r=hh.get(t.config.apiHost);r&&(o.eid=r);const a=t._getFrameworks();return a.length&&(o.fw=a.join(",")),`${n}?${Kt(o).slice(1)}`}async function mh(t){const e=await ah(t),n=ve().gapi;return k(n,t,"internal-error"),e.open({where:document.body,url:fh(t),messageHandlersFilter:n.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:dh,dontclear:!0},o=>new Promise(async(r,a)=>{await o.restyle({setHideOnLeave:!1});const l=ge(t,"network-request-failed"),d=ve().setTimeout(()=>{a(l)},ch.get());function p(){ve().clearTimeout(d),r(o)}o.ping(p).then(p,()=>{a(l)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ph={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},gh=500,vh=600,yh="_blank",_h="http://localhost";class Jr{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function Eh(t,e,n,o=gh,r=vh){const a=Math.max((window.screen.availHeight-r)/2,0).toString(),l=Math.max((window.screen.availWidth-o)/2,0).toString();let d="";const p=Object.assign(Object.assign({},ph),{width:o.toString(),height:r.toString(),top:a,left:l}),w=oe().toLowerCase();n&&(d=sa(w)?yh:n),ta(w)&&(e=e||_h,p.scrollbars="yes");const A=Object.entries(p).reduce((R,[H,N])=>`${R}${H}=${N},`,"");if(nd(w)&&d!=="_self")return Ih(e||"",d),new Jr(null);const D=window.open(e||"",d,A);k(D,t,"popup-blocked");try{D.focus()}catch{}return new Jr(D)}function Ih(t,e){const n=document.createElement("a");n.href=t,n.target=e;const o=document.createEvent("MouseEvent");o.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),n.dispatchEvent(o)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wh="__/auth/handler",bh="emulator/auth/handler",Th=encodeURIComponent("fac");async function Xr(t,e,n,o,r,a){k(t.config.authDomain,t,"auth-domain-config-required"),k(t.config.apiKey,t,"invalid-api-key");const l={apiKey:t.config.apiKey,appName:t.name,authType:n,redirectUrl:o,v:it,eventId:r};if(e instanceof ha){e.setDefaultLanguage(t.languageCode),l.providerId=e.providerId||"",ll(e.getCustomParameters())||(l.customParameters=JSON.stringify(e.getCustomParameters()));for(const[A,D]of Object.entries({}))l[A]=D}if(e instanceof Yt){const A=e.getScopes().filter(D=>D!=="");A.length>0&&(l.scopes=A.join(","))}t.tenantId&&(l.tid=t.tenantId);const d=l;for(const A of Object.keys(d))d[A]===void 0&&delete d[A];const p=await t._getAppCheckToken(),w=p?`#${Th}=${encodeURIComponent(p)}`:"";return`${Ah(t)}?${Kt(d).slice(1)}${w}`}function Ah({config:t}){return t.emulator?to(t,bh):`https://${t.authDomain}/${wh}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rs="webStorageSupport";class Sh{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=va,this._completeRedirectFn=Xd,this._overrideRedirectResult=Gd}async _openPopup(e,n,o,r){var a;Ne((a=this.eventManagers[e._key()])===null||a===void 0?void 0:a.manager,"_initialize() not called before _openPopup()");const l=await Xr(e,n,o,Bs(),r);return Eh(e,l,ao())}async _openRedirect(e,n,o,r){await this._originValidation(e);const a=await Xr(e,n,o,Bs(),r);return Rd(a),new Promise(()=>{})}_initialize(e){const n=e._key();if(this.eventManagers[n]){const{manager:r,promise:a}=this.eventManagers[n];return r?Promise.resolve(r):(Ne(a,"If manager is not set, promise should be"),a)}const o=this.initAndGetManager(e);return this.eventManagers[n]={promise:o},o.catch(()=>{delete this.eventManagers[n]}),o}async initAndGetManager(e){const n=await mh(e),o=new Qd(e);return n.register("authEvent",r=>(k(r==null?void 0:r.authEvent,e,"invalid-auth-event"),{status:o.onEvent(r.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:o},this.iframes[e._key()]=n,o}_isIframeWebStorageSupported(e,n){this.iframes[e._key()].send(Rs,{type:Rs},r=>{var a;const l=(a=r==null?void 0:r[0])===null||a===void 0?void 0:a[Rs];l!==void 0&&n(!!l),Pe(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const n=e._key();return this.originValidationPromises[n]||(this.originValidationPromises[n]=sh(e)),this.originValidationPromises[n]}get _shouldInitProactively(){return ca()||na()||oo()}}const Ch=Sh;var Yr="@firebase/auth",Qr="1.7.9";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dh{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)===null||e===void 0?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const n=this.auth.onIdTokenChanged(o=>{e((o==null?void 0:o.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,n),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const n=this.internalListeners.get(e);n&&(this.internalListeners.delete(e),n(),this.updateProactiveRefresh())}assertAuthConfigured(){k(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Rh(t){switch(t){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function kh(t){tt(new Ge("auth",(e,{options:n})=>{const o=e.getProvider("app").getImmediate(),r=e.getProvider("heartbeat"),a=e.getProvider("app-check-internal"),{apiKey:l,authDomain:d}=o.options;k(l&&!l.includes(":"),"invalid-api-key",{appName:o.name});const p={apiKey:l,authDomain:d,clientPlatform:t,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:la(t)},w=new cd(o,r,a,p);return md(w,n),w},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,n,o)=>{e.getProvider("auth-internal").initialize()})),tt(new Ge("auth-internal",e=>{const n=ro(e.getProvider("auth").getImmediate());return(o=>new Dh(o))(n)},"PRIVATE").setInstantiationMode("EXPLICIT")),pe(Yr,Qr,Rh(t)),pe(Yr,Qr,"esm2017")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ph=5*60,Nh=Li("authIdTokenMaxAge")||Ph;let Zr=null;const Mh=t=>async e=>{const n=e&&await e.getIdTokenResult(),o=n&&(new Date().getTime()-Date.parse(n.issuedAtTime))/1e3;if(o&&o>Nh)return;const r=n==null?void 0:n.token;Zr!==r&&(Zr=r,await fetch(t,{method:r?"POST":"DELETE",headers:r?{Authorization:`Bearer ${r}`}:{}}))};function Oh(t=Js()){const e=qn(t,"auth");if(e.isInitialized())return e.getImmediate();const n=fd(t,{popupRedirectResolver:Ch,persistence:[xd,Sd,va]}),o=Li("authTokenSyncURL");if(o&&typeof isSecureContext=="boolean"&&isSecureContext){const a=new URL(o,location.origin);if(location.origin===a.origin){const l=Mh(a.toString());bd(n,l,()=>l(n.currentUser)),wd(n,d=>l(d))}}const r=Ni("auth");return r&&pd(n,`http://${r}`),n}function Lh(){var t,e;return(e=(t=document.getElementsByTagName("head"))===null||t===void 0?void 0:t[0])!==null&&e!==void 0?e:document}ld({loadJS(t){return new Promise((e,n)=>{const o=document.createElement("script");o.setAttribute("src",t),o.onload=e,o.onerror=r=>{const a=ge("internal-error");a.customData=r,n(a)},o.type="text/javascript",o.charset="UTF-8",Lh().appendChild(o)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});kh("Browser");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ta="firebasestorage.googleapis.com",$h="storageBucket",Bh=2*60*1e3,xh=10*60*1e3;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ie extends Ee{constructor(e,n,o=0){super(ks(e),`Firebase Storage: ${n} (${ks(e)})`),this.status_=o,this.customData={serverResponse:null},this._baseMessage=this.message,Object.setPrototypeOf(this,Ie.prototype)}get status(){return this.status_}set status(e){this.status_=e}_codeEquals(e){return ks(e)===this.code}get serverResponse(){return this.customData.serverResponse}set serverResponse(e){this.customData.serverResponse=e,this.customData.serverResponse?this.message=`${this._baseMessage}
${this.customData.serverResponse}`:this.message=this._baseMessage}}var _e;(function(t){t.UNKNOWN="unknown",t.OBJECT_NOT_FOUND="object-not-found",t.BUCKET_NOT_FOUND="bucket-not-found",t.PROJECT_NOT_FOUND="project-not-found",t.QUOTA_EXCEEDED="quota-exceeded",t.UNAUTHENTICATED="unauthenticated",t.UNAUTHORIZED="unauthorized",t.UNAUTHORIZED_APP="unauthorized-app",t.RETRY_LIMIT_EXCEEDED="retry-limit-exceeded",t.INVALID_CHECKSUM="invalid-checksum",t.CANCELED="canceled",t.INVALID_EVENT_NAME="invalid-event-name",t.INVALID_URL="invalid-url",t.INVALID_DEFAULT_BUCKET="invalid-default-bucket",t.NO_DEFAULT_BUCKET="no-default-bucket",t.CANNOT_SLICE_BLOB="cannot-slice-blob",t.SERVER_FILE_WRONG_SIZE="server-file-wrong-size",t.NO_DOWNLOAD_URL="no-download-url",t.INVALID_ARGUMENT="invalid-argument",t.INVALID_ARGUMENT_COUNT="invalid-argument-count",t.APP_DELETED="app-deleted",t.INVALID_ROOT_OPERATION="invalid-root-operation",t.INVALID_FORMAT="invalid-format",t.INTERNAL_ERROR="internal-error",t.UNSUPPORTED_ENVIRONMENT="unsupported-environment"})(_e||(_e={}));function ks(t){return"storage/"+t}function Uh(){const t="An unknown error occurred, please check the error payload for server response.";return new Ie(_e.UNKNOWN,t)}function Fh(){return new Ie(_e.RETRY_LIMIT_EXCEEDED,"Max retry time for operation exceeded, please try again.")}function Hh(){return new Ie(_e.CANCELED,"User canceled the upload/download.")}function jh(t){return new Ie(_e.INVALID_URL,"Invalid URL '"+t+"'.")}function Vh(t){return new Ie(_e.INVALID_DEFAULT_BUCKET,"Invalid default bucket '"+t+"'.")}function ei(t){return new Ie(_e.INVALID_ARGUMENT,t)}function Aa(){return new Ie(_e.APP_DELETED,"The Firebase app was deleted.")}function qh(t){return new Ie(_e.INVALID_ROOT_OPERATION,"The operation '"+t+"' cannot be performed on a root reference, create a non-root reference using child, such as .child('file.png').")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class me{constructor(e,n){this.bucket=e,this.path_=n}get path(){return this.path_}get isRoot(){return this.path.length===0}fullServerUrl(){const e=encodeURIComponent;return"/b/"+e(this.bucket)+"/o/"+e(this.path)}bucketOnlyServerUrl(){return"/b/"+encodeURIComponent(this.bucket)+"/o"}static makeFromBucketSpec(e,n){let o;try{o=me.makeFromUrl(e,n)}catch{return new me(e,"")}if(o.path==="")return o;throw Vh(e)}static makeFromUrl(e,n){let o=null;const r="([A-Za-z0-9.\\-_]+)";function a(z){z.path.charAt(z.path.length-1)==="/"&&(z.path_=z.path_.slice(0,-1))}const l="(/(.*))?$",d=new RegExp("^gs://"+r+l,"i"),p={bucket:1,path:3};function w(z){z.path_=decodeURIComponent(z.path)}const A="v[A-Za-z0-9_]+",D=n.replace(/[.]/g,"\\."),R="(/([^?#]*).*)?$",H=new RegExp(`^https?://${D}/${A}/b/${r}/o${R}`,"i"),N={bucket:1,path:3},V=n===Ta?"(?:storage.googleapis.com|storage.cloud.google.com)":n,M="([^?#]*)",re=new RegExp(`^https?://${V}/${r}/${M}`,"i"),q=[{regex:d,indices:p,postModify:a},{regex:H,indices:N,postModify:w},{regex:re,indices:{bucket:1,path:2},postModify:w}];for(let z=0;z<q.length;z++){const ce=q[z],K=ce.regex.exec(e);if(K){const y=K[ce.indices.bucket];let h=K[ce.indices.path];h||(h=""),o=new me(y,h),ce.postModify(o);break}}if(o==null)throw jh(e);return o}}class zh{constructor(e){this.promise_=Promise.reject(e)}getPromise(){return this.promise_}cancel(e=!1){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wh(t,e,n){let o=1,r=null,a=null,l=!1,d=0;function p(){return d===2}let w=!1;function A(...M){w||(w=!0,e.apply(null,M))}function D(M){r=setTimeout(()=>{r=null,t(H,p())},M)}function R(){a&&clearTimeout(a)}function H(M,...re){if(w){R();return}if(M){R(),A.call(null,M,...re);return}if(p()||l){R(),A.call(null,M,...re);return}o<64&&(o*=2);let q;d===1?(d=2,q=0):q=(o+Math.random())*1e3,D(q)}let N=!1;function V(M){N||(N=!0,R(),!w&&(r!==null?(M||(d=2),clearTimeout(r),D(0)):M||(d=1)))}return D(0),a=setTimeout(()=>{l=!0,V(!0)},n),V}function Gh(t){t(!1)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Kh(t){return t!==void 0}function ti(t,e,n,o){if(o<e)throw ei(`Invalid value for '${t}'. Expected ${e} or greater.`);if(o>n)throw ei(`Invalid value for '${t}'. Expected ${n} or less.`)}function Jh(t){const e=encodeURIComponent;let n="?";for(const o in t)if(t.hasOwnProperty(o)){const r=e(o)+"="+e(t[o]);n=n+r+"&"}return n=n.slice(0,-1),n}var Un;(function(t){t[t.NO_ERROR=0]="NO_ERROR",t[t.NETWORK_ERROR=1]="NETWORK_ERROR",t[t.ABORT=2]="ABORT"})(Un||(Un={}));/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xh(t,e){const n=t>=500&&t<600,r=[408,429].indexOf(t)!==-1,a=e.indexOf(t)!==-1;return n||r||a}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yh{constructor(e,n,o,r,a,l,d,p,w,A,D,R=!0){this.url_=e,this.method_=n,this.headers_=o,this.body_=r,this.successCodes_=a,this.additionalRetryCodes_=l,this.callback_=d,this.errorCallback_=p,this.timeout_=w,this.progressCallback_=A,this.connectionFactory_=D,this.retry=R,this.pendingConnection_=null,this.backoffId_=null,this.canceled_=!1,this.appDelete_=!1,this.promise_=new Promise((H,N)=>{this.resolve_=H,this.reject_=N,this.start_()})}start_(){const e=(o,r)=>{if(r){o(!1,new In(!1,null,!0));return}const a=this.connectionFactory_();this.pendingConnection_=a;const l=d=>{const p=d.loaded,w=d.lengthComputable?d.total:-1;this.progressCallback_!==null&&this.progressCallback_(p,w)};this.progressCallback_!==null&&a.addUploadProgressListener(l),a.send(this.url_,this.method_,this.body_,this.headers_).then(()=>{this.progressCallback_!==null&&a.removeUploadProgressListener(l),this.pendingConnection_=null;const d=a.getErrorCode()===Un.NO_ERROR,p=a.getStatus();if(!d||Xh(p,this.additionalRetryCodes_)&&this.retry){const A=a.getErrorCode()===Un.ABORT;o(!1,new In(!1,null,A));return}const w=this.successCodes_.indexOf(p)!==-1;o(!0,new In(w,a))})},n=(o,r)=>{const a=this.resolve_,l=this.reject_,d=r.connection;if(r.wasSuccessCode)try{const p=this.callback_(d,d.getResponse());Kh(p)?a(p):a()}catch(p){l(p)}else if(d!==null){const p=Uh();p.serverResponse=d.getErrorText(),this.errorCallback_?l(this.errorCallback_(d,p)):l(p)}else if(r.canceled){const p=this.appDelete_?Aa():Hh();l(p)}else{const p=Fh();l(p)}};this.canceled_?n(!1,new In(!1,null,!0)):this.backoffId_=Wh(e,n,this.timeout_)}getPromise(){return this.promise_}cancel(e){this.canceled_=!0,this.appDelete_=e||!1,this.backoffId_!==null&&Gh(this.backoffId_),this.pendingConnection_!==null&&this.pendingConnection_.abort()}}class In{constructor(e,n,o){this.wasSuccessCode=e,this.connection=n,this.canceled=!!o}}function Qh(t,e){e!==null&&e.length>0&&(t.Authorization="Firebase "+e)}function Zh(t,e){t["X-Firebase-Storage-Version"]="webjs/"+(e??"AppManager")}function ef(t,e){e&&(t["X-Firebase-GMPID"]=e)}function tf(t,e){e!==null&&(t["X-Firebase-AppCheck"]=e)}function nf(t,e,n,o,r,a,l=!0){const d=Jh(t.urlParams),p=t.url+d,w=Object.assign({},t.headers);return ef(w,e),Qh(w,n),Zh(w,a),tf(w,o),new Yh(p,t.method,w,t.body,t.successCodes,t.additionalRetryCodes,t.handler,t.errorHandler,t.timeout,t.progressCallback,r,l)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function sf(t){if(t.length===0)return null;const e=t.lastIndexOf("/");return e===-1?"":t.slice(0,e)}function of(t){const e=t.lastIndexOf("/",t.length-2);return e===-1?t:t.slice(e+1)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fn{constructor(e,n){this._service=e,n instanceof me?this._location=n:this._location=me.makeFromUrl(n,e.host)}toString(){return"gs://"+this._location.bucket+"/"+this._location.path}_newRef(e,n){return new Fn(e,n)}get root(){const e=new me(this._location.bucket,"");return this._newRef(this._service,e)}get bucket(){return this._location.bucket}get fullPath(){return this._location.path}get name(){return of(this._location.path)}get storage(){return this._service}get parent(){const e=sf(this._location.path);if(e===null)return null;const n=new me(this._location.bucket,e);return new Fn(this._service,n)}_throwIfRoot(e){if(this._location.path==="")throw qh(e)}}function ni(t,e){const n=e==null?void 0:e[$h];return n==null?null:me.makeFromBucketSpec(n,t)}function rf(t,e,n,o={}){t.host=`${e}:${n}`,t._protocol="http";const{mockUserToken:r}=o;r&&(t._overrideAuthToken=typeof r=="string"?r:$i(r,t.app.options.projectId))}class af{constructor(e,n,o,r,a){this.app=e,this._authProvider=n,this._appCheckProvider=o,this._url=r,this._firebaseVersion=a,this._bucket=null,this._host=Ta,this._protocol="https",this._appId=null,this._deleted=!1,this._maxOperationRetryTime=Bh,this._maxUploadRetryTime=xh,this._requests=new Set,r!=null?this._bucket=me.makeFromBucketSpec(r,this._host):this._bucket=ni(this._host,this.app.options)}get host(){return this._host}set host(e){this._host=e,this._url!=null?this._bucket=me.makeFromBucketSpec(this._url,e):this._bucket=ni(e,this.app.options)}get maxUploadRetryTime(){return this._maxUploadRetryTime}set maxUploadRetryTime(e){ti("time",0,Number.POSITIVE_INFINITY,e),this._maxUploadRetryTime=e}get maxOperationRetryTime(){return this._maxOperationRetryTime}set maxOperationRetryTime(e){ti("time",0,Number.POSITIVE_INFINITY,e),this._maxOperationRetryTime=e}async _getAuthToken(){if(this._overrideAuthToken)return this._overrideAuthToken;const e=this._authProvider.getImmediate({optional:!0});if(e){const n=await e.getToken();if(n!==null)return n.accessToken}return null}async _getAppCheckToken(){const e=this._appCheckProvider.getImmediate({optional:!0});return e?(await e.getToken()).token:null}_delete(){return this._deleted||(this._deleted=!0,this._requests.forEach(e=>e.cancel()),this._requests.clear()),Promise.resolve()}_makeStorageReference(e){return new Fn(this,e)}_makeRequest(e,n,o,r,a=!0){if(this._deleted)return new zh(Aa());{const l=nf(e,this._appId,o,r,n,this._firebaseVersion,a);return this._requests.add(l),l.getPromise().then(()=>this._requests.delete(l),()=>this._requests.delete(l)),l}}async makeRequestWithTokens(e,n){const[o,r]=await Promise.all([this._getAuthToken(),this._getAppCheckToken()]);return this._makeRequest(e,n,o,r).getPromise()}}const si="@firebase/storage",oi="0.13.2";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Sa="storage";function cf(t=Js(),e){t=rt(t);const o=qn(t,Sa).getImmediate({identifier:e}),r=Mi("storage");return r&&lf(o,...r),o}function lf(t,e,n,o={}){rf(t,e,n,o)}function uf(t,{instanceIdentifier:e}){const n=t.getProvider("app").getImmediate(),o=t.getProvider("auth-internal"),r=t.getProvider("app-check-internal");return new af(n,o,r,e,it)}function df(){tt(new Ge(Sa,uf,"PUBLIC").setMultipleInstances(!0)),pe(si,oi,""),pe(si,oi,"esm2017")}df();const hf={apiKey:"AIzaSyAhxVd2GsGeWZQd0t5JHxTiWbV56EiKY1g",authDomain:"hmasp-chat.firebaseapp.com",projectId:"hmasp-chat",storageBucket:"hmasp-chat.firebasestorage.app",messagingSenderId:"823561488808",appId:"1:823561488808:web:27f032daff2566febdf59d"},lo=Ui(hf);Oh(lo);$u(lo);cf(lo);const Zt=`${js.DATABASE_BACKEND||"http://localhost:3000"}/api/database/monitoramento`;console.log("[MonitoramentoLog] Usando backend:",Zt);async function Ca(t){try{const{ultimaVerificacao:e,totalEnviadas:n,totalFalhas:o}=t,a=await(await fetch(`${Zt}/state`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({ativo:!0,ultimaVerificacao:e||new Date().toISOString(),totalEnviadas:n||0,totalFalhas:o||0})})).json();if(!a.success)throw new Error(a.error);console.log("[MonitoramentoLog] Estado salvo no PostgreSQL")}catch(e){throw console.error("[MonitoramentoLog] Erro ao salvar estado:",e),e}}async function uo(){try{const e=await(await fetch(`${Zt}/state`)).json();if(!e.success)throw new Error(e.error);return console.log("[MonitoramentoLog] Estado carregado do PostgreSQL:",e.state),e.state}catch(t){return console.error("[MonitoramentoLog] Erro ao carregar estado:",t),{ativo:!1,ultimaVerificacao:null,totalEnviadas:0,totalFalhas:0}}}async function ri(t,e,n={}){try{const r=await(await fetch(`${Zt}/consulta`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({consultaNumero:t,status:e,detalhes:{paciente:n.paciente||"",telefone:n.telefone||"",messageId:n.messageId||"",queueId:n.queueId||"",erro:n.erro||"",tentativas:n.tentativas||1}})})).json();if(!r.success)throw new Error(r.error);console.log(`[MonitoramentoLog] Consulta ${t} registrada como ${e}`)}catch(o){throw console.error("[MonitoramentoLog] Erro ao registrar consulta:",o),o}}async function ff(t){try{const n=await(await fetch(`${Zt}/consultas/filtrar`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({consultas:t})})).json();if(!n.success)throw new Error(n.error);return console.log(`[MonitoramentoLog] ${n.naoProcessadasCount} consultas não processadas de ${n.total} total`),n.naoProcessadas}catch(e){throw console.error("[MonitoramentoLog] Erro ao obter consultas não processadas:",e),e}}async function mf(t){try{const e=await uo();e.ativo=t,await Ca(e),console.log(`[MonitoramentoLog] Monitoramento ${t?"ativado":"desativado"}`)}catch(e){throw console.error("[MonitoramentoLog] Erro ao alterar status do monitoramento:",e),e}}const ye={MIN_INTERVAL:45*1e3,MAX_INTERVAL:120*1e3,MENSAGENS_ANTES_PAUSA:20,MIN_PAUSA:10*60*1e3,MAX_PAUSA:15*60*1e3,MIN_TYPING_TIME:3*1e3,MAX_TYPING_TIME:5*1e3},G={queue:[],processing:!1,messagesSent:0,lastMessageTime:null,stats:{totalEnviadas:0,totalFalhas:0,pausasRealizadas:0}},ii=["Olá","Oi","Bom dia","Boa tarde","Boa noite"];async function Da(t){const{chatId:e,texto:n,botoes:o,metadata:r}=t;if(!e||!n)throw new Error("chatId e texto são obrigatórios");const a={id:`msg_${Date.now()}_${Math.random().toString(36).substr(2,9)}`,chatId:e,texto:pf(n),botoes:o||null,metadata:r||{},status:"pending",tentativas:0,adicionadoEm:new Date().toISOString(),erro:null};return G.queue.push(a),console.log(`[WhatsAppQueue] Mensagem adicionada à fila: ${a.id} (${G.queue.length} na fila)`),G.processing||gf(),a.id}function pf(t){const e=[/^Olá,/i,/^Oi,/i,/^Tudo bem\?/i,/^Bom dia,/i,/^Boa tarde,/i,/^Boa noite,/i],n=ii[Math.floor(Math.random()*ii.length)];for(const o of e)if(o.test(t))return t.replace(o,`${n},`);return t}async function gf(){if(G.processing){console.log("[WhatsAppQueue] Fila já está sendo processada");return}for(G.processing=!0,console.log("[WhatsAppQueue] Iniciando processamento da fila");G.queue.length>0;){const t=G.queue[0];try{G.messagesSent>0&&G.messagesSent%ye.MENSAGENS_ANTES_PAUSA===0&&await yf(),G.lastMessageTime&&await vf(),await _f(t.chatId);const e=await Ef(t);if(e.success)t.status="sent",t.messageId=e.messageId,t.enviadoEm=new Date().toISOString(),G.messagesSent++,G.lastMessageTime=Date.now(),G.stats.totalEnviadas++,console.log(`[WhatsAppQueue] Mensagem enviada: ${t.id}`);else throw new Error(e.error)}catch(e){if(console.error(`[WhatsAppQueue] Erro ao enviar mensagem ${t.id}:`,e),t.tentativas++,t.erro=e.message,t.tentativas<3){t.status="retry",console.log(`[WhatsAppQueue] Tentativa ${t.tentativas} falhou, tentando novamente...`),G.queue.push(G.queue.shift());continue}else t.status="failed",G.stats.totalFalhas++,console.log(`[WhatsAppQueue] Mensagem ${t.id} falhou após ${t.tentativas} tentativas`)}G.queue.shift()}G.processing=!1,console.log("[WhatsAppQueue] Fila processada completamente")}async function vf(){const t=Math.floor(Math.random()*(ye.MAX_INTERVAL-ye.MIN_INTERVAL)+ye.MIN_INTERVAL),e=(t/1e3).toFixed(0);return console.log(`[WhatsAppQueue] Aguardando ${e}s antes da próxima mensagem...`),new Promise(n=>setTimeout(n,t))}async function yf(){const t=Math.floor(Math.random()*(ye.MAX_PAUSA-ye.MIN_PAUSA)+ye.MIN_PAUSA),e=(t/6e4).toFixed(1);return console.log(`[WhatsAppQueue] 🛑 PAUSA DE RESFRIAMENTO: ${e} minutos (${G.messagesSent} mensagens enviadas)`),G.stats.pausasRealizadas++,new Promise(n=>setTimeout(n,t))}async function _f(t){const e=Math.floor(Math.random()*(ye.MAX_TYPING_TIME-ye.MIN_TYPING_TIME)+ye.MIN_TYPING_TIME);console.log(`[WhatsAppQueue] 💬 Simulando digitação por ${(e/1e3).toFixed(1)}s...`);try{await Lc(t,"composing"),await new Promise(n=>setTimeout(n,e))}catch(n){console.error("[WhatsAppQueue] Erro ao simular digitação:",n)}}async function Ef(t){try{const e=await Ai(t.chatId,t.texto,t.botoes);return{success:!0,messageId:e.messageId,timestamp:e.timestamp}}catch(e){return{success:!1,error:e.message}}}let ai=null,Fs=null;const st=new Map;async function If(t,e=3e4){if(ai){console.log("[Confirmação] Monitoramento já está ativo");return}console.log("[Confirmação] Iniciando monitoramento de consultas marcadas...");const n=await uo();console.log("[Confirmação] Estado anterior carregado:",n),await mf(!0),Fs=new Date,await ci(t),ai=setInterval(async()=>{await ci(t)},e)}async function ci(t){try{const e=await xc(60);if(e.length>0){const n=await ff(e);if(n.length>0){console.log(`[Confirmação] ${n.length} novas consultas encontradas`);const o=[];for(const r of n)try{(!r.telefones||r.telefones.length===0)&&console.warn(`[Confirmação] ⚠️ Consulta ${r.consultaNumero} - Paciente sem telefones cadastrados no AGHUse`);const a=Ra(r,"MARCACAO");o.push(a)}catch(a){console.error(`[Confirmação] Erro ao processar consulta ${r.consultaNumero}:`,a)}t&&o.length>0&&t(o)}}Fs=new Date,await Ca({ultimaVerificacao:Fs.toISOString()})}catch(e){console.error("[Confirmação] Erro ao verificar consultas:",e)}}function Ra(t,e="MARCACAO"){const n=t.dataMarcacao?t.dataMarcacao instanceof Date?t.dataMarcacao.getTime():new Date(t.dataMarcacao).getTime():Date.now(),o=`${e}_${t.consultaNumero}_${n}`;let r=[];t.telefones&&t.telefones.length>0?r=t.telefones.map((d,p)=>{const A=qc(e==="MARCACAO"?"marcacao_confirmacao":"lembrete_72h",{nomePaciente:t.nomeCompleto,especialidade:t.especialidade,dataHora:t.dataHoraFormatada,medico:t.profissional,local:t.local}),D=Di(d.normalized);return{telefone:d.normalized,telefoneFormatado:ue.formatForDisplay(d.normalized),telefoneType:d.type,telefoneOrigem:d.original,chatId:D,mensagem:A,status:Ps.PENDING,prioridade:p+1,tentativas:0,logs:[]}}):r=[{telefone:null,telefoneFormatado:"⚠️ SEM TELEFONE CADASTRADO",telefoneType:"none",telefoneOrigem:null,chatId:null,mensagem:null,status:"no_phone",prioridade:1,tentativas:0,logs:[{timestamp:new Date().toISOString(),status:"no_phone",mensagem:"Paciente sem telefone cadastrado no AGHUse"}]}];let a="pending";r.length>0&&r[0].status==="no_phone"&&(a="no_phone");const l={id:o,tipo:e,consultaNumero:t.consultaNumero,pacCodigo:t.pacCodigo,prontuario:t.prontuario,nomePaciente:t.nomeCompleto,nomeExibicao:t.nomeExibicao,especialidade:t.especialidade,dataConsulta:t.dataConsulta,dataHoraFormatada:t.dataHoraFormatada,dataMarcacao:t.dataMarcacao,profissional:t.profissional,local:t.local,mensagens:r,statusGeral:a,criadoEm:new Date,atualizadoEm:new Date};return st.set(o,l),l}async function ho(t,e=0){const n=t.mensagens[e];if(!n)throw new Error("Telefone não encontrado");if(n.status==="no_phone")throw new Error("Paciente não possui telefone cadastrado. Verifique o cadastro no AGHUse.");try{const o=await Da({chatId:n.chatId,texto:n.mensagem.texto,botoes:n.mensagem.botoes,metadata:{confirmationId:t.id,consultaNumero:t.consultaNumero,paciente:t.nomePaciente,telefone:n.telefone}});return console.log(`[Confirmação] Mensagem adicionada à fila: ${o}`),n.status="queued",n.queueId=o,n.tentativas++,n.logs.push(yr({consultaNumero:t.consultaNumero,pacCodigo:t.pacCodigo,telefone:n.telefone,telefoneType:n.telefoneType,templateId:n.mensagem.templateId,status:"queued",queueId:o,tentativa:n.tentativas})),t.atualizadoEm=new Date,st.set(t.id,t),await ri(t.consultaNumero,"enviado",{paciente:t.nomePaciente,telefone:n.telefone,queueId:o}),{success:!0,queueId:o,timestamp:new Date().toISOString()}}catch(o){throw console.error("[Confirmação] Erro ao enviar mensagem:",o),n.status=Ps.FAILED,n.logs.push(yr({consultaNumero:t.consultaNumero,pacCodigo:t.pacCodigo,telefone:n.telefone,telefoneType:n.telefoneType,templateId:n.mensagem.templateId,status:Ps.FAILED,tentativa:n.tentativas,erro:o.message})),t.atualizadoEm=new Date,st.set(t.id,t),await ri(t.consultaNumero,"falha",{paciente:t.nomePaciente,telefone:n.telefone,erro:o.message}),o}}function fo(t){return st.get(t)||null}function wf(){let t=0;return st.forEach(e=>{e.arquivada||(e.arquivada=!0,e.dataArquivamento=new Date,t++)}),console.log(`[Confirmação] ${t} confirmações arquivadas manualmente`),t}function bf(t){let e=0;return st.forEach(n=>{!n.arquivada&&n.statusGeral===t&&(n.arquivada=!0,n.dataArquivamento=new Date,e++)}),console.log(`[Confirmação] ${e} confirmações com status '${t}' arquivadas`),e}function ka(){return Array.from(st.values()).filter(t=>!t.arquivada)}let li=null,Pa=null;const ui=new Set;async function Tf(t,e=36e5){if(li){console.log("[Lembrete 72h] Monitoramento já está ativo");return}console.log("[Lembrete 72h] Iniciando monitoramento de lembretes 72h..."),Pa=new Date,await di(t),li=setInterval(async()=>{await di(t)},e)}async function di(t){try{const e=await jc();if(e.length>0){console.log(`[Lembrete 72h] ${e.length} consultas encontradas para lembrete`);const n=e.filter(o=>{const r=`${o.consultaNumero}_72h`;return!ui.has(r)});if(n.length>0){console.log(`[Lembrete 72h] ${n.length} novas consultas para processar`);const o=[];for(const r of n)try{const a=Ra(r);a.tipoEnvio="lembrete_72h",a.dataEnvio=new Date,o.push(a);const l=`${r.consultaNumero}_72h`;ui.add(l),console.log(`[Lembrete 72h] Consulta ${r.consultaNumero} preparada para lembrete`)}catch(a){console.error(`[Lembrete 72h] Erro ao processar consulta ${r.consultaNumero}:`,a)}t&&o.length>0&&t(o),console.log(`[Lembrete 72h] ✅ ${o.length} lembretes preparados`)}}Pa=new Date}catch(e){console.error("[Lembrete 72h] Erro ao verificar consultas 72h:",e)}}const Ze={active:!1,callbacks:new Set};async function Af(){console.log("[MonitoramentoGlobal] Inicializando...");try{const t=await uo();console.log("[MonitoramentoGlobal] Estado anterior:",t.ativo?"ATIVO":"INATIVO"),console.log("[MonitoramentoGlobal] ✅ INICIANDO monitoramento automático (política: sempre ativo)"),await Na()}catch(t){console.error("[MonitoramentoGlobal] Erro ao inicializar:",t)}}async function Na(){if(Ze.active){console.log("[MonitoramentoGlobal] Monitoramento já está ativo");return}console.log("[MonitoramentoGlobal] Iniciando monitoramento..."),Ze.active=!0,await If(Cf,3e4),console.log("[MonitoramentoGlobal] ✓ Monitoramento iniciado")}function Sf(t){return Ze.callbacks.add(t),console.log("[MonitoramentoGlobal] Callback registrado. Total:",Ze.callbacks.size),()=>{Ze.callbacks.delete(t),console.log("[MonitoramentoGlobal] Callback removido. Total:",Ze.callbacks.size)}}function Cf(t){console.log("[MonitoramentoGlobal] Novas confirmações:",t.length),Ze.callbacks.forEach(e=>{try{e(t)}catch(n){console.error("[MonitoramentoGlobal] Erro ao executar callback:",n)}})}function Df(){console.log("[HeaderClone] Iniciando sincronização de headers..."),hi(),setInterval(hi,500)}function hi(){const t=document.querySelector("#confirmacao-tab .confirmacao-header");if(!t)return;const e=document.querySelector("#desmarcacao-tab .confirmacao-header"),n=document.querySelector("#notificacao-tab .confirmacao-header");e&&fi(t,e),n&&fi(t,n)}function fi(t,e,n){const o=t.querySelector(".header-status"),r=e.querySelector(".header-status");if(o&&r){const a=o.querySelector(".status-item-inline:nth-child(1)"),l=o.querySelector(".status-item-inline:nth-child(2)"),d=r.querySelector(".status-item-inline:nth-child(1)"),p=r.querySelector(".status-item-inline:nth-child(2)");a&&d&&(d.innerHTML=a.innerHTML),l&&p&&(p.innerHTML=l.innerHTML)}}const Gn=`tab_${Date.now()}_${Math.random().toString(36).substr(2,9)}`,Kn="hmasp_tab_master_lock",Rf=5e3,kf=1e4;let Ue=!1,Se=null;function Pf(t){console.log(`[TabMaster] 🆔 Tab ID: ${Gn}`),Se=t,Hs(),setInterval(()=>{Hs()},Rf),window.addEventListener("storage",Mf),window.addEventListener("beforeunload",Nf),console.log("[TabMaster] ✅ Sistema iniciado")}function Hs(){const t=Ma(),e=Date.now();!t||e-t.timestamp>kf?(mi(),Ue||(Ue=!0,console.log("[TabMaster] 👑 Esta aba se tornou MASTER"),Se&&Se(!0))):t.tabId===Gn?(mi(),Ue||(Ue=!0,console.log("[TabMaster] 👑 Esta aba continua como MASTER"),Se&&Se(!0))):Ue&&(Ue=!1,console.log("[TabMaster] 🔄 Outra aba é MASTER agora"),Se&&Se(!1))}function mi(){const t={tabId:Gn,timestamp:Date.now()};try{localStorage.setItem(Kn,JSON.stringify(t))}catch(e){console.error("[TabMaster] ❌ Erro ao adquirir lock:",e)}}function Nf(){const t=Ma();if(t&&t.tabId===Gn)try{localStorage.removeItem(Kn),console.log("[TabMaster] 🔓 Lock liberado")}catch(e){console.error("[TabMaster] ❌ Erro ao liberar lock:",e)}Ue&&(Ue=!1,Se&&Se(!1))}function Ma(){try{const t=localStorage.getItem(Kn);return t?JSON.parse(t):null}catch(t){return console.error("[TabMaster] ❌ Erro ao ler lock:",t),null}}function Mf(t){t.key===Kn&&Hs()}let mt=null;function Of(){mt||(mt=document.createElement("div"),mt.id="toast-container",mt.style.cssText=`
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        display: flex;
        flex-direction: column;
        gap: 12px;
        pointer-events: none;
    `,document.body.appendChild(mt))}function wn({type:t="info",title:e,message:n,duration:o=4e3}){Of();const r=document.createElement("div");r.className=`toast toast-${t}`;let a,l,d;switch(t){case"success":a="✓",l="#10b981",d="#059669";break;case"error":a="✕",l="#ef4444",d="#dc2626";break;case"warning":a="⚠",l="#f59e0b",d="#d97706";break;case"info":default:a="ℹ",l="#0cb7f2",d="#0891b2";break}r.innerHTML=`
        <div class="toast-icon" style="
            background: ${l};
            color: white;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 700;
            flex-shrink: 0;
        ">${a}</div>
        <div class="toast-content" style="
            flex: 1;
            min-width: 0;
        ">
            <div class="toast-title" style="
                font-weight: 600;
                font-size: 14px;
                color: #1e293b;
                margin-bottom: 2px;
            ">${e}</div>
            ${n?`
                <div class="toast-message" style="
                    font-size: 13px;
                    color: #64748b;
                    line-height: 1.4;
                ">${n}</div>
            `:""}
        </div>
        <button class="toast-close" style="
            background: none;
            border: none;
            color: #94a3b8;
            cursor: pointer;
            padding: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 4px;
            transition: all 0.2s;
            flex-shrink: 0;
        ">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
        </button>
    `,r.style.cssText=`
        background: white;
        border-left: 4px solid ${d};
        border-radius: 12px;
        padding: 16px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15), 0 4px 6px rgba(0, 0, 0, 0.1);
        display: flex;
        align-items: flex-start;
        gap: 12px;
        min-width: 320px;
        max-width: 420px;
        pointer-events: auto;
        transform: translateX(450px);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        opacity: 0;
    `;const p=r.querySelector(".toast-close");return p.addEventListener("mouseenter",()=>{p.style.background="#f1f5f9",p.style.color="#475569"}),p.addEventListener("mouseleave",()=>{p.style.background="none",p.style.color="#94a3b8"}),p.addEventListener("click",()=>{pi(r)}),mt.appendChild(r),requestAnimationFrame(()=>{r.style.transform="translateX(0)",r.style.opacity="1"}),o>0&&setTimeout(()=>{pi(r)},o),r}function pi(t){t.style.transform="translateX(450px)",t.style.opacity="0",setTimeout(()=>{t.parentNode&&t.parentNode.removeChild(t)},300)}const U={success:(t,e,n)=>wn({type:"success",title:t,message:e,duration:n}),error:(t,e,n)=>wn({type:"error",title:t,message:e,duration:n}),warning:(t,e,n)=>wn({type:"warning",title:t,message:e,duration:n}),info:(t,e,n)=>wn({type:"info",title:t,message:e,duration:n})};function Hn(t){return t&&t.replace(/\*([^*]+)\*/g,"<strong>$1</strong>")}const P={monitoringActive:!1,confirmations:[],filtroStatus:"all",unregisterCallback:null,autoSendEnabled:!0,isMasterTab:!1},S={clearConfirmationsBtn:null,archiveConfirmedBtn:null,archiveDeclinedBtn:null,archivePendingBtn:null,archiveNotScheduledBtn:null,aghuseIndicator:null,monitoringIndicator:null,statTotalConfirmacoes:null,statPendentes:null,statConfirmadas:null,statDeclinadas:null,statNaoAgendou:null,confirmacoesList:null,filterStatus:null,autoSendToggle:null,tabMasterIndicator:null};async function Lf(){var o,r,a,l,d,p,w;console.log("[Confirmação] Inicializando componente..."),S.clearConfirmationsBtn=document.getElementById("clear-confirmations-btn"),S.archiveConfirmedBtn=document.getElementById("archive-confirmed-btn"),S.archiveDeclinedBtn=document.getElementById("archive-declined-btn"),S.archivePendingBtn=document.getElementById("archive-pending-btn"),S.archiveNotScheduledBtn=document.getElementById("archive-not-scheduled-btn"),S.aghuseIndicator=document.getElementById("aghuse-indicator"),S.monitoringIndicator=document.getElementById("monitoring-indicator"),S.statTotalConfirmacoes=document.getElementById("stat-total-confirmacoes"),S.statPendentes=document.getElementById("stat-pendentes"),S.statConfirmadas=document.getElementById("stat-confirmadas"),S.statDeclinadas=document.getElementById("stat-declinadas"),S.statNaoAgendou=document.getElementById("stat-nao-agendou"),S.confirmacoesList=document.getElementById("confirmacoes-list"),S.filterStatus=document.getElementById("filter-status"),S.autoSendToggle=document.getElementById("auto-send-toggle-confirmacao"),S.tabMasterIndicator=document.getElementById("tab-master-indicator");const t=localStorage.getItem("hmasp_auto_send_confirmacao");t!==null&&(P.autoSendEnabled=t==="true",S.autoSendToggle&&(S.autoSendToggle.checked=P.autoSendEnabled)),(o=S.clearConfirmationsBtn)==null||o.addEventListener("click",Vf),(r=S.archiveConfirmedBtn)==null||r.addEventListener("click",()=>bn("confirmed")),(a=S.archiveDeclinedBtn)==null||a.addEventListener("click",()=>bn("declined")),(l=S.archivePendingBtn)==null||l.addEventListener("click",()=>bn("pending")),(d=S.archiveNotScheduledBtn)==null||d.addEventListener("click",()=>bn("not_scheduled")),(p=S.filterStatus)==null||p.addEventListener("change",Qf),(w=S.autoSendToggle)==null||w.addEventListener("change",Hf);const e=document.querySelectorAll(".stat-card[data-filter]");if(console.log("[Confirmação] 🔍 Cards com filtro encontrados:",e.length),e.forEach(A=>{A.addEventListener("click",D=>{D.stopPropagation();const R=A.getAttribute("data-filter");if(console.log("[Confirmação] 🎯 Card clicado! Filtro:",R),S.filterStatus){S.filterStatus.value=R;const H=new Event("change",{bubbles:!0});S.filterStatus.dispatchEvent(H),console.log("[Confirmação] ✅ Filtro aplicado:",R)}else console.error("[Confirmação] ❌ Dropdown não encontrado!")})}),qf(),localStorage.getItem("hmasp_needs_reprocess")!=="done_v6"){console.log("[Confirmação] 🧹 Limpando dados antigos para reprocessar com dataMarcacao..."),localStorage.removeItem("hmasp_confirmations"),localStorage.setItem("hmasp_needs_reprocess","done_v6");try{await fetch(`${CONFIG.DATABASE_BACKEND}/api/database/monitoramento/clear`),console.log("[Confirmação] ✅ Banco limpo")}catch(A){console.warn("[Confirmação] Erro ao limpar banco:",A)}console.log("[Confirmação] 🔄 Recarregando para buscar consultas atualizadas..."),setTimeout(()=>window.location.reload(),500);return}jf(),Bf(),Pf($f),await xf(),await Uf(),Wf(),window.addEventListener("confirmacao-toggle-changed",A=>{P.autoSendEnabled=A.detail.enabled,P.autoSendEnabled?(console.log("[Confirmação] ✅ Envio automático HABILITADO"),U.success("Envio Automático","Mensagens serão enviadas automaticamente",3e3)):(console.log("[Confirmação] ⏸️ Envio automático DESABILITADO"),U.info("Envio Automático","Mensagens aguardam envio manual",3e3))}),console.log("[Confirmação] Componente inicializado")}function $f(t){P.isMasterTab=t,S.tabMasterIndicator&&(t?(S.tabMasterIndicator.classList.remove("secondary"),S.tabMasterIndicator.querySelector(".tab-master-icon").textContent="👑",S.tabMasterIndicator.querySelector(".tab-master-text").textContent="ABA MASTER",S.tabMasterIndicator.style.display="flex",console.log("[Confirmação] 👑 Esta aba é MASTER - Pode enviar mensagens automáticas"),U.info("Tab Master","Esta aba é responsável pelo envio automático",3e3)):(S.tabMasterIndicator.classList.add("secondary"),S.tabMasterIndicator.querySelector(".tab-master-icon").textContent="🔄",S.tabMasterIndicator.querySelector(".tab-master-text").textContent="ABA SECUNDÁRIA",S.tabMasterIndicator.style.display="flex",console.log("[Confirmação] 🔄 Esta aba NÃO é master - Envio automático desabilitado")))}function Bf(){Df(),console.log("[Confirmação] Sincronização de headers iniciada - todas as abas mostram o mesmo componente")}async function xf(){try{console.log("[Confirmação] 🚀 Iniciando monitoramento automático..."),P.unregisterCallback=Sf(zf);try{(await Ci()).success?(S.aghuseIndicator.innerHTML="🟢 Conectado",S.aghuseIndicator.style.color="#10b981",console.log("[Confirmação] ✅ AGHUse conectado")):(S.aghuseIndicator.innerHTML="🔴 Erro",S.aghuseIndicator.style.color="#ef4444",console.error("[Confirmação] ❌ Erro ao conectar AGHUse"))}catch(t){S.aghuseIndicator.innerHTML="🔴 Erro",S.aghuseIndicator.style.color="#ef4444",console.error("[Confirmação] ❌ Erro ao testar AGHUse:",t)}await Na(),P.monitoringActive=!0,S.monitoringIndicator.innerHTML="🟢 Ativo",S.monitoringIndicator.style.color="#10b981",console.log("[Confirmação] ✅ Monitoramento iniciado automaticamente")}catch(t){console.error("[Confirmação] ❌ Erro ao iniciar monitoramento automático:",t),S.monitoringIndicator.innerHTML="🔴 Erro",S.monitoringIndicator.style.color="#ef4444"}}async function Uf(){try{console.log("[Lembrete 72h] 🚀 Iniciando monitoramento de lembretes 72h..."),await Tf(Ff,36e5),console.log("[Lembrete 72h] ✅ Monitoramento de lembretes 72h iniciado")}catch(t){console.error("[Lembrete 72h] ❌ Erro ao iniciar monitoramento de lembretes 72h:",t)}}function Ff(t){console.log("[Lembrete 72h] 📩 Novos lembretes 72h:",t.length);const e=new Set(P.confirmations.map(r=>r.id)),n=t.filter(r=>!e.has(r.id)&&!r.arquivada);if(n.length===0){console.log("[Lembrete 72h] Nenhum lembrete novo (duplicatas ignoradas)");return}P.confirmations=[...n,...P.confirmations],en(),we(),Me();const o=`${n.length} lembrete(s) 72h adicionado(s)`;console.log(`[Lembrete 72h] ${o}`),P.autoSendEnabled&&P.isMasterTab?(console.log("[Lembrete 72h] 👑🤖 Esta aba é MASTER e envio automático habilitado - enviando lembretes..."),Oa(n)):P.autoSendEnabled&&!P.isMasterTab?console.log("[Lembrete 72h] 🔄 Envio automático habilitado mas esta aba NÃO é master - aguardando master enviar"):(console.log("[Lembrete 72h] ⏸️ Envio automático desabilitado - aguardando envio manual"),U.info("Lembretes 72h",`${o}. Envie manualmente as mensagens.`,5e3))}function Hf(t){P.autoSendEnabled=t.target.checked,P.autoSendEnabled?(console.log("[Confirmação] ✅ Envio automático HABILITADO"),U.success("Envio Automático","Mensagens serão enviadas automaticamente",3e3)):(console.log("[Confirmação] ⏸️ Envio automático DESABILITADO"),U.info("Envio Automático","Mensagens aguardam envio manual",3e3)),localStorage.setItem("hmasp_auto_send_confirmacao",P.autoSendEnabled)}function en(){try{const t=P.confirmations.filter(e=>!e.arquivada);localStorage.setItem("hmasp_confirmations",JSON.stringify(t)),console.log(`[Confirmação] ${t.length} confirmações salvas no localStorage`)}catch(t){console.error("[Confirmação] Erro ao salvar no localStorage:",t)}}function jf(){try{const t=localStorage.getItem("hmasp_confirmations");if(t){const e=JSON.parse(t);P.confirmations=e,console.log(`[Confirmação] ${e.length} confirmações restauradas do localStorage`),we(),Me()}else console.log("[Confirmação] Nenhuma confirmação salva no localStorage")}catch(t){console.error("[Confirmação] Erro ao carregar do localStorage:",t)}}function Vf(){if(!confirm(`Deseja arquivar todas as confirmações visíveis?

Elas não serão deletadas, apenas arquivadas.`))return;const e=wf();P.confirmations=ka(),en(),we(),Me(),U.success("Arquivadas!",`${e} confirmações arquivadas com sucesso`,3e3)}function bn(t){const e={confirmed:"confirmadas",declined:"declinadas (Não poderão ir)",pending:"pendentes (Aguardando)",not_scheduled:"não agendadas"};if(!confirm(`Deseja arquivar todas as confirmações ${e[t]}?

Elas não serão deletadas, apenas arquivadas.`))return;const o=bf(t);if(o===0){U.info("Nenhuma arquivada",`Não há confirmações ${e[t]} para arquivar`,3e3);return}P.confirmations=ka(),en(),we(),Me(),U.success("Arquivadas!",`${o} confirmações ${e[t]} arquivadas`,3e3)}function qf(){const t=Vs();if(console.log("[Confirmação] 🔍 DEBUG - Session:",t),!t||!t.user){console.warn("[Confirmação] Sessão não encontrada");return}const e=t.user.role;console.log("[Confirmação] Configurando permissões para perfil:",e),console.log("[Confirmação] 🔍 DEBUG - Elemento archiveNotScheduledBtn:",S.archiveNotScheduledBtn),e==="admin"?(console.log("[Confirmação] 🔍 DEBUG - Usuário é ADMIN, mostrando botões..."),S.archiveConfirmedBtn.style.display="inline-flex",S.archiveDeclinedBtn.style.display="inline-flex",S.archivePendingBtn.style.display="inline-flex",S.archiveNotScheduledBtn?(S.archiveNotScheduledBtn.style.display="inline-flex",console.log('[Confirmação] ✅ Botão "Arquivar não agendou" EXIBIDO para admin')):console.error("[Confirmação] ❌ Elemento archiveNotScheduledBtn NÃO ENCONTRADO no DOM!")):e==="operator"?(S.archiveConfirmedBtn.style.display="inline-flex",S.archiveDeclinedBtn.style.display="none",S.archivePendingBtn.style.display="inline-flex",S.archiveNotScheduledBtn.style.display="none"):e==="viewer"&&(S.archiveConfirmedBtn.style.display="none",S.archiveDeclinedBtn.style.display="none",S.archivePendingBtn.style.display="none",S.archiveNotScheduledBtn.style.display="none")}function zf(t){console.log("[Confirmação] Novas confirmações:",t.length);const e=new Set(P.confirmations.map(r=>r.id)),n=t.filter(r=>!e.has(r.id)&&!r.arquivada);if(n.length===0){console.log("[Confirmação] Nenhuma confirmação nova (duplicatas ignoradas)");return}P.confirmations=[...n,...P.confirmations],en(),we(),Me();const o=n.length===1?"1 nova consulta marcada":`${n.length} novas consultas marcadas`;console.log(`[Confirmação] ${o}`),P.autoSendEnabled&&P.isMasterTab?(console.log("[Confirmação] 👑🤖 Esta aba é MASTER e envio automático habilitado - enviando mensagens..."),Oa(n)):P.autoSendEnabled&&!P.isMasterTab?console.log("[Confirmação] 🔄 Envio automático habilitado mas esta aba NÃO é master - aguardando master enviar"):(console.log("[Confirmação] ⏸️ Envio automático desabilitado - aguardando envio manual"),U.info("Novas consultas",`${o}. Envie manualmente as mensagens.`,5e3))}async function Oa(t){let e=0,n=0;for(const o of t)try{const r=o.telefones[0];if(!(r!=null&&r.telefone)){console.log(`[Confirmação] ⚠️ Consulta ${o.consultaNumero} sem telefone - pulando envio automático`);continue}await ho(o,0),e++,console.log(`[Confirmação] ✅ Mensagem enviada automaticamente para ${o.nomePaciente}`)}catch(r){n++,console.error("[Confirmação] ❌ Erro ao enviar mensagem automática:",r)}we(),Me(),e>0&&U.success("Envio automático",`${e} mensagem(ns) enviada(s) automaticamente`,5e3),n>0&&U.error("Erro no envio",`${n} mensagem(ns) falharam`,4e3)}function Wf(){console.log("[Confirmação] 📱 Iniciando polling de respostas WhatsApp..."),gi(),setInterval(gi,5e3)}async function gi(){try{const e=await(await fetch("http://localhost:3000/api/responses")).json();if(!e.success){console.error("[Confirmação] Erro ao buscar respostas:",e.error);return}if(!e.responses||e.responses.length===0)return;console.log(`[Confirmação] 📱 ${e.responses.length} respostas do WhatsApp recebidas`);for(const n of e.responses)Gf(n)}catch(t){console.error("[Confirmação] Erro ao consultar respostas WhatsApp:",t)}}function Gf(t){const{telefone:e,status:n,timestamp:o}=t;if(!e||!n){console.warn("[Confirmação] Resposta inválida:",t);return}console.log(`[Confirmação] Processando resposta: ${e} -> ${n}`);const r=e.replace(/\D/g,""),a=P.confirmations.find(w=>w.mensagens.some(A=>(A.telefone||"").replace(/\D/g,"")===r));if(!a){console.warn(`[Confirmação] Confirmação não encontrada para telefone: ${e}`);return}const l=a.statusGeral;a.statusGeral=n,a.dataResposta=o;const d=a.mensagens.find(w=>(w.telefone||"").replace(/\D/g,"")===r);d&&(d.status=n),console.log(`[Confirmação] ✅ Status atualizado: ${a.nomePaciente} - ${l} → ${n}`),en(),we(),Me();const p=mo(n);U.info("Resposta recebida!",`${a.nomePaciente}: ${p}`,4e3)}function Me(){const t=P.confirmations.length,e=P.confirmations.filter(a=>a.statusGeral==="pending").length,n=P.confirmations.filter(a=>a.statusGeral==="confirmed").length,o=P.confirmations.filter(a=>a.statusGeral==="declined").length,r=P.confirmations.filter(a=>a.statusGeral==="not_scheduled").length;S.statTotalConfirmacoes.textContent=t,S.statPendentes.textContent=e,S.statConfirmadas.textContent=n,S.statDeclinadas.textContent=o,S.statNaoAgendou.textContent=r}function we(){if(!S.confirmacoesList)return;const t=Yf();if(t.length===0){S.confirmacoesList.innerHTML=`
            <div class="empty-state">
                <div class="empty-icon">📋</div>
                <h3>Nenhuma confirmação encontrada</h3>
                <p>Aguardando novas consultas marcadas...</p>
            </div>
        `;return}const e=t.map(n=>Kf(n)).join("");S.confirmacoesList.innerHTML=e,Zf()}function Kf(t){Jf(t.statusGeral),mo(t.statusGeral),Xf(t.statusGeral);const e=t.mensagens[0],n=e!=null&&e.telefone?ue.formatForDisplay(e.telefone):"SEM TELEFONE",r=!(e!=null&&e.telefone)?'<span style="color: #ef4444; font-weight: 700;">⚠️ </span>':"";let a="";if(t.dataMarcacao){const l=new Date(t.dataMarcacao),d=String(l.getDate()).padStart(2,"0"),p=String(l.getMonth()+1).padStart(2,"0"),w=l.getFullYear(),A=String(l.getHours()).padStart(2,"0"),D=String(l.getMinutes()).padStart(2,"0");a=`${d}/${p}/${w} ${A}:${D}`}return`
        <div class="confirmation-card-compact" data-id="${t.id}">
            <div class="patient-info">
                <strong>${t.nomePaciente}</strong>
            </div>

            <div class="appointment-details">
                <span>📅 ${Hn(t.dataHoraFormatada)}</span>
                <span>🏥 ${Hn(t.especialidade)}</span>
                <span>${r}📞 ${n}</span>
                ${a?`<span>🕐 Marcada: ${a}</span>`:""}
            </div>

            <button class="btn-details-compact" onclick="window.showConfirmationDetails('${t.id}')">
                Ver Detalhes
            </button>
        </div>
    `}function Jf(t){switch(t){case"pending":return"status-pending";case"sent":return"status-sent";case"delivered":return"status-delivered";case"confirmed":return"status-confirmed";case"declined":return"status-declined";case"no_phone":return"status-warning";default:return"status-other"}}function mo(t){switch(t){case"pending":return"Aguardando";case"sent":return"Enviado";case"delivered":return"Entregue";case"confirmed":return"Confirmado";case"declined":return"Declinado";case"not_scheduled":return"Não Agendou";case"no_phone":return"Sem Telefone";default:return"Outro"}}function Xf(t){switch(t){case"pending":return"⏳";case"sent":return"📤";case"delivered":return"✅";case"confirmed":return"👍";case"declined":return"❌";case"no_phone":return"⚠️";default:return"⚪"}}function Yf(){return P.filtroStatus==="all"?P.confirmations:P.confirmations.filter(t=>t.statusGeral===P.filtroStatus)}function Qf(t){P.filtroStatus=t.target.value,we()}window.handleSendMessage=async function(t){var r;const e=P.confirmations.find(a=>a.id===t);if(!e){U.error("Erro","Confirmação não encontrada",3e3);return}const n=e.mensagens[0];if(!(n!=null&&n.telefone)){U.error("Sem telefone","Paciente não possui telefone cadastrado",4e3);return}if(confirm(`Enviar mensagem de confirmação?

Paciente: ${e.nomePaciente}
Telefone: ${ue.formatForDisplay(n.telefone)}
Consulta: ${e.dataHoraFormatada}`)){(r=document.querySelector(".modal-overlay"))==null||r.remove(),U.info("Enviando...","Adicionando mensagem à fila de envio",3e3);try{const a=await ho(e,0);U.success("Mensagem enviada!",`Adicionada à fila de envio. ID: ${a.queueId}`,5e3),we(),Me()}catch(a){console.error("[Confirmação] Erro ao enviar:",a),U.error("Erro ao enviar",a.message,6e3)}}};window.showConfirmationDetails=function(t){const e=P.confirmations.find(l=>l.id===t);if(!e){console.error("[Confirmação] Não encontrada:",t);return}const n=e.mensagens[0],o=e.mensagens.filter(l=>l.telefone).map(l=>`${ue.formatForDisplay(l.telefone)} (${l.telefoneType})`).join(", ")||"Nenhum telefone cadastrado";let r="Não informada";if(e.dataMarcacao){const l=new Date(e.dataMarcacao),d=String(l.getDate()).padStart(2,"0"),p=String(l.getMonth()+1).padStart(2,"0"),w=l.getFullYear(),A=String(l.getHours()).padStart(2,"0"),D=String(l.getMinutes()).padStart(2,"0");r=`${d}/${p}/${w} às ${A}:${D}`}const a=`
        <div class="modal-overlay" onclick="this.remove()">
            <div class="modal-content" onclick="event.stopPropagation()">
                <div class="modal-header">
                    <h3>Detalhes da Confirmação</h3>
                    <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="detail-row">
                        <span class="detail-label">Paciente:</span>
                        <span class="detail-value">${e.nomePaciente}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Prontuário:</span>
                        <span class="detail-value">${e.prontuario}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Nr Consulta:</span>
                        <span class="detail-value">${e.consultaNumero}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Especialidade:</span>
                        <span class="detail-value">${Hn(e.especialidade)}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Data/Hora:</span>
                        <span class="detail-value">${Hn(e.dataHoraFormatada)}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Profissional:</span>
                        <span class="detail-value">${e.profissional||"Não informado"}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Local:</span>
                        <span class="detail-value">${e.local||"Não informado"}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Telefones:</span>
                        <span class="detail-value">${o}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Marcada em:</span>
                        <span class="detail-value">${r}</span>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn-secondary" onclick="this.closest('.modal-overlay').remove()">Fechar</button>
                    ${n!=null&&n.telefone?`
                        <button class="btn-primary" onclick="window.handleSendMessage('${e.id}')">
                            📤 Enviar Mensagem
                        </button>
                    `:""}
                </div>
            </div>
        </div>
    `;document.body.insertAdjacentHTML("beforeend",a)};function Zf(){document.querySelectorAll(".btn-detail").forEach(t=>{t.addEventListener("click",em)}),document.querySelectorAll(".btn-send-test").forEach(t=>{t.addEventListener("click",tm)}),document.querySelectorAll(".btn-fix-phone").forEach(t=>{t.addEventListener("click",nm)})}function em(t){const e=t.target.dataset.id,n=fo(e);if(!n){alert("Confirmação não encontrada");return}let o=`DETALHES DA CONFIRMAÇÃO

`;o+=`Paciente: ${n.nomeCompleto}
`,o+=`Prontuário: ${n.prontuario}
`,o+=`Consulta: ${n.especialidade}
`,o+=`Data/Hora: ${n.dataHoraFormatada}
`,o+=`Profissional: ${n.profissional}
`,o+=`Local: ${n.local}

`,o+=`TELEFONES:
`,n.mensagens.forEach((r,a)=>{o+=`${a+1}. ${r.telefoneFormatado} (${r.telefoneType}) - ${mo(r.status)}
`}),alert(o)}async function tm(t){const e=t.target.dataset.id,n=fo(e);if(!n){alert("Confirmação não encontrada");return}if(confirm(`Simular envio de mensagem?

MODO DESENVOLVIMENTO: Não enviará WhatsApp real.`)){t.target.disabled=!0,t.target.textContent="📤 Enviando...";try{const o=await ho(n,0);alert(`Mensagem simulada com sucesso!

Message ID: ${o.messageId}`),we(),Me()}catch(o){alert(`Erro ao simular envio:

${o.message}`)}finally{t.target.disabled=!1,t.target.textContent="📤 Simular Envio (DEV)"}}}function nm(t){const e=t.target.dataset.id,n=fo(e);if(!n){alert("Confirmação não encontrada");return}const o=`ATENÇÃO: Paciente sem telefone cadastrado!

Paciente: ${n.nomePaciente}
Prontuário: ${n.prontuario||"N/A"}
CPF/Código: ${n.pacCodigo}

Consulta marcada para: ${n.dataHoraFormatada}
Especialidade: ${n.especialidade}

⚠️ Para enviar a confirmação por WhatsApp, é necessário:
1. Acessar o sistema AGHUse
2. Localizar o cadastro do paciente
3. Adicionar um telefone celular válido
4. Aguardar o próximo ciclo de monitoramento

Você será notificado quando o paciente for reprocessado.`;alert(o)}let vi=null,La=null;const Ke=new Map;async function sm(t,e=3e4){if(vi){console.log("[Desmarcação] Monitoramento já está ativo");return}console.log("[Desmarcação] Iniciando monitoramento de consultas desmarcadas..."),La=new Date,await yi(t),vi=setInterval(async()=>{await yi(t)},e)}async function yi(t){try{const e=await Hc(60);if(e.length>0){console.log(`[Desmarcação] ${e.length} consultas desmarcadas encontradas`);const n=[];for(const o of e)try{const r=o.dataDesmarcacao?o.dataDesmarcacao instanceof Date?o.dataDesmarcacao.getTime():new Date(o.dataDesmarcacao).getTime():Date.now(),a=`DESMARCACAO_${o.consultaNumero}_${r}`;if(Ke.has(a)){console.log(`[Desmarcação] Consulta ${o.consultaNumero} já existe no store, pulando...`);continue}const l=om(o);n.push(l)}catch(r){console.error(`[Desmarcação] Erro ao processar consulta ${o.consultaNumero}:`,r)}t&&n.length>0&&t(n)}La=new Date}catch(e){console.error("[Desmarcação] Erro ao verificar consultas desmarcadas:",e)}}function om(t){const e=t.dataDesmarcacao?t.dataDesmarcacao instanceof Date?t.dataDesmarcacao.getTime():new Date(t.dataDesmarcacao).getTime():Date.now(),n=`DESMARCACAO_${t.consultaNumero}_${e}`;let o=[];t.telefones&&t.telefones.length>0?o=t.telefones.map((l,d)=>{const p=Di(l.normalized);return{telefone:l.normalized,telefoneFormatado:ue.formatForDisplay(l.normalized),telefoneType:l.type,telefoneOrigem:l.original,chatId:p,prioridade:d+1}}):o=[{telefone:null,telefoneFormatado:"⚠️ SEM TELEFONE CADASTRADO",telefoneType:"none",telefoneOrigem:null,chatId:null,prioridade:1}];let r="Não informada";if(t.dataDesmarcacao){const l=new Date(t.dataDesmarcacao),d=String(l.getDate()).padStart(2,"0"),p=String(l.getMonth()+1).padStart(2,"0"),w=l.getFullYear(),A=String(l.getHours()).padStart(2,"0"),D=String(l.getMinutes()).padStart(2,"0");r=`${d}/${p}/${w} ${A}:${D}`}const a={id:n,consultaNumero:t.consultaNumero,pacCodigo:t.pacCodigo,prontuario:t.prontuario,nomePaciente:t.nomeCompleto,nomeExibicao:t.nomeExibicao,especialidade:t.especialidade,dataConsulta:t.dataConsulta,dataHoraFormatada:t.dataHoraFormatada,dataMarcacao:t.dataMarcacao,dataDesmarcacao:t.dataDesmarcacao,dataDesmarcacaoFormatada:r,profissional:t.profissional,local:t.local,telefones:o,status:null,criadoEm:new Date,atualizadoEm:new Date};return Ke.set(n,a),a}async function rm(t,e=0){const n=t.telefones[e];if(!n)throw new Error("Telefone não encontrado");if(!n.telefone)throw new Error("Paciente não possui telefone cadastrado. Verifique o cadastro no AGHUse.");try{const o=`Olá, *${t.nomeExibicao}*. Aqui é a Central de Marcação de Consultas do HMASP.

Informamos que a sua consulta de *${t.especialidade}*, prevista para *${t.dataHoraFormatada}* com o(a) *Dr(a) ${t.profissional}*, *foi desmarcada* em nosso sistema, por indisponibilidade do profissional ou por solicitação do paciente.

Por favor, nos informe a situação para darmos o encaminhamento correto:`,r=[{id:"1",texto:"1. Solicito reagendamento, pois preciso da consulta."},{id:"2",texto:"2. Fui eu (paciente) quem solicitei a desmarcação."},{id:"3",texto:"3. Não é necessário reagendar."}],a=await Da({chatId:n.chatId,texto:o,botoes:r,metadata:{desmarcacaoId:t.id,consultaNumero:t.consultaNumero,paciente:t.nomePaciente,telefone:n.telefone}});return console.log(`[Desmarcação] Mensagem adicionada à fila: ${a}`),t.atualizadoEm=new Date,Ke.set(t.id,t),{success:!0,queueId:a,timestamp:new Date().toISOString()}}catch(o){throw console.error("[Desmarcação] Erro ao enviar mensagem:",o),o}}function im(){let t=0;return Ke.forEach(e=>{e.arquivada||(e.arquivada=!0,e.dataArquivamento=new Date,t++)}),console.log(`[Desmarcação] ${t} desmarcações arquivadas manualmente`),t}function am(t){let e=0;return Ke.forEach(n=>{!n.arquivada&&n.status===t&&(n.arquivada=!0,n.dataArquivamento=new Date,e++)}),console.log(`[Desmarcação] ${e} desmarcações com status '${t}' arquivadas`),e}function $a(){return Array.from(Ke.values()).filter(t=>!t.arquivada)}function cm(t,e){const n=Ke.get(t);if(!n)throw new Error("Desmarcação não encontrada");const r={1:"reagendamento",2:"paciente_solicitou",3:"sem_reagendamento"}[e];if(!r)throw new Error(`Botão inválido: ${e}`);return n.status=r,n.respostaEm=new Date,n.atualizadoEm=new Date,Ke.set(t,n),console.log(`[Desmarcação] Resposta registrada: ${e} (${r}) para consulta ${n.consultaNumero}`),n}function jn(t){return t&&t.replace(/\*([^*]+)\*/g,"<strong>$1</strong>")}const $={monitoringActive:!1,desmarcacoes:[],filtroStatus:"all",responsePollingInterval:null,autoSendEnabled:!0},C={clearDesmarcacoesBtn:null,archiveReagendamentoBtn:null,archiveSemReagendamentoBtn:null,archivePacienteSolicitouBtn:null,archiveAguardandoConfirmacaoDesmBtn:null,filterStatus:null,aghuseIndicator:null,monitoringIndicator:null,statTotalDesmarcacoes:null,statReagendamento:null,statSemReagendamento:null,statPacienteSolicitou:null,statAguardandoConfirmacaoDesm:null,desmarcacoesList:null,autoSendToggle:null};async function lm(){var n,o,r,a,l,d,p;console.log("[Desmarcação] Inicializando componente..."),C.clearDesmarcacoesBtn=document.getElementById("clear-desmarcacoes-btn"),C.archiveReagendamentoBtn=document.getElementById("archive-reagendamento-btn"),C.archiveSemReagendamentoBtn=document.getElementById("archive-sem-reagendamento-btn"),C.archivePacienteSolicitouBtn=document.getElementById("archive-paciente-solicitou-btn"),C.archiveAguardandoConfirmacaoDesmBtn=document.getElementById("archive-aguardando-confirmacao-desm-btn"),C.filterStatus=document.getElementById("filter-status-desmarcacao"),C.aghuseIndicator=document.getElementById("aghuse-indicator-desmarcacao"),C.monitoringIndicator=document.getElementById("monitoring-indicator-desmarcacao"),C.statTotalDesmarcacoes=document.getElementById("stat-total-desmarcacoes"),C.statReagendamento=document.getElementById("stat-reagendamento"),C.statSemReagendamento=document.getElementById("stat-sem-reagendamento"),C.statPacienteSolicitou=document.getElementById("stat-paciente-solicitou"),C.statAguardandoConfirmacaoDesm=document.getElementById("stat-aguardando-confirmacao-desm"),C.desmarcacoesList=document.getElementById("desmarcacoes-list"),C.autoSendToggle=document.getElementById("auto-send-toggle-desmarcacao");const t=localStorage.getItem("hmasp_auto_send_desmarcacao");t!==null&&($.autoSendEnabled=t==="true",C.autoSendToggle&&(C.autoSendToggle.checked=$.autoSendEnabled)),(n=C.clearDesmarcacoesBtn)==null||n.addEventListener("click",mm),(o=C.archiveReagendamentoBtn)==null||o.addEventListener("click",()=>Tn("reagendamento")),(r=C.archiveSemReagendamentoBtn)==null||r.addEventListener("click",()=>Tn("sem_reagendamento")),(a=C.archivePacienteSolicitouBtn)==null||a.addEventListener("click",()=>Tn("paciente_solicitou")),(l=C.archiveAguardandoConfirmacaoDesmBtn)==null||l.addEventListener("click",()=>Tn(null)),(d=C.filterStatus)==null||d.addEventListener("change",pm),(p=C.autoSendToggle)==null||p.addEventListener("change",gm),document.querySelectorAll("[data-filter-desm]").forEach(w=>{w.addEventListener("click",A=>{const D=w.getAttribute("data-filter-desm");C.filterStatus&&(C.filterStatus.value=D,C.filterStatus.dispatchEvent(new Event("change",{bubbles:!0})))})}),vm(),fm(),await um(),dm(),window.addEventListener("desmarcacao-toggle-changed",w=>{$.autoSendEnabled=w.detail.enabled,$.autoSendEnabled?(console.log("[Desmarcação] ✅ Envio automático HABILITADO"),U.success("Envio Automático","Mensagens serão enviadas automaticamente",3e3)):(console.log("[Desmarcação] ⏸️ Envio automático DESABILITADO"),U.info("Envio Automático","Mensagens aguardam envio manual",3e3))}),console.log("[Desmarcação] Componente inicializado")}async function um(){try{console.log("[Desmarcação] 🚀 Iniciando monitoramento automático...");try{(await Ci()).success?(C.aghuseIndicator&&(C.aghuseIndicator.innerHTML="🟢 Conectado",C.aghuseIndicator.style.color="#10b981"),console.log("[Desmarcação] ✅ AGHUse conectado")):(C.aghuseIndicator&&(C.aghuseIndicator.innerHTML="🔴 Erro",C.aghuseIndicator.style.color="#ef4444"),console.error("[Desmarcação] ❌ Erro ao conectar AGHUse"))}catch(t){C.aghuseIndicator&&(C.aghuseIndicator.innerHTML="🔴 Erro",C.aghuseIndicator.style.color="#ef4444"),console.error("[Desmarcação] ❌ Erro ao testar AGHUse:",t)}await sm(ym,3e4),$.monitoringActive=!0,C.monitoringIndicator&&(C.monitoringIndicator.innerHTML="🟢 Ativo",C.monitoringIndicator.style.color="#10b981"),console.log("[Desmarcação] ✅ Monitoramento iniciado automaticamente")}catch(t){console.error("[Desmarcação] ❌ Erro ao iniciar monitoramento automático:",t),C.monitoringIndicator&&(C.monitoringIndicator.innerHTML="🔴 Erro",C.monitoringIndicator.style.color="#ef4444")}}function dm(){$.responsePollingInterval&&clearInterval($.responsePollingInterval),console.log("[Desmarcação] 🔄 Iniciando polling de respostas do WhatsApp..."),_i(),$.responsePollingInterval=setInterval(()=>{_i()},5e3)}async function _i(){try{const e=await(await fetch("http://localhost:3000/api/whatsapp/responses")).json();e.success&&e.responses&&e.responses.length>0&&(console.log(`[Desmarcação] 📩 ${e.responses.length} novas respostas recebidas`),await hm(e.responses))}catch(t){console.error("[Desmarcação] ❌ Erro ao verificar respostas do WhatsApp:",t)}}async function hm(t){let e=0;for(const n of t){if(n.contexto!=="desmarcacao"||!n.tipoDesmarcacao)continue;const o=ue.normalize(n.telefone),r=$.desmarcacoes.find(a=>a.telefones.some(l=>l.telefone===o));if(r){const l={reagendamento:"reagendamento",sem_reagendamento:"sem_reagendamento",paciente_solicitou:"paciente_solicitou"}[n.tipoDesmarcacao];if(l&&r.status!==l){console.log(`[Desmarcação] 📝 Atualizando status: ${r.consultaNumero} → ${l}`);try{const p={reagendamento:"1",paciente_solicitou:"2",sem_reagendamento:"3"}[l];cm(r.id,p),r.status=l,r.respostaEm=new Date,r.atualizadoEm=new Date,e++,console.log(`[Desmarcação] ✅ Status atualizado para consulta ${r.consultaNumero}`)}catch(d){console.error("[Desmarcação] ❌ Erro ao atualizar status:",d)}}}else console.log(`[Desmarcação] ⚠️ Desmarcação não encontrada para telefone ${o}`)}e>0&&(console.log(`[Desmarcação] ✅ ${e} desmarcações atualizadas`),tn(),at(),wt(),U.success("Status atualizado!",`${e} resposta(s) processada(s)`,3e3))}function tn(){try{const t=$.desmarcacoes.filter(e=>!e.arquivada);localStorage.setItem("hmasp_desmarcacoes",JSON.stringify(t)),console.log(`[Desmarcação] ${t.length} desmarcações salvas no localStorage`)}catch(t){console.error("[Desmarcação] Erro ao salvar no localStorage:",t)}}function fm(){try{const t=localStorage.getItem("hmasp_desmarcacoes");if(t){const e=JSON.parse(t),n=[],o=new Set;for(const a of e)o.has(a.id)||(o.add(a.id),n.push(a));const r=e.length-n.length;r>0&&console.log(`[Desmarcação] ⚠️ ${r} duplicatas removidas ao carregar do localStorage`),$.desmarcacoes=n,console.log(`[Desmarcação] ${n.length} desmarcações restauradas do localStorage`),at(),wt(),r>0&&tn()}else console.log("[Desmarcação] Nenhuma desmarcação salva no localStorage")}catch(t){console.error("[Desmarcação] Erro ao carregar do localStorage:",t)}}function mm(){if(!confirm(`Deseja arquivar todas as desmarcações visíveis?

Elas não serão deletadas, apenas arquivadas.`))return;const e=im();$.desmarcacoes=$a(),tn(),at(),wt(),U.success("Arquivadas!",`${e} desmarcações arquivadas com sucesso`,3e3)}function Tn(t){const n={reagendamento:"reagendamento",sem_reagendamento:"sem reagendamento",paciente_solicitou:"paciente solicitou",null:"aguardando confirmação"}[t];if(!confirm(`Deseja arquivar todas as desmarcações com status "${n}"?

Elas não serão deletadas, apenas arquivadas.`))return;const r=am(t);$.desmarcacoes=$a(),tn(),at(),wt(),U.success("Arquivadas!",`${r} desmarcações com status "${n}" arquivadas`,3e3)}function pm(t){$.filtroStatus=t.target.value,console.log("[Desmarcação] Filtro alterado para:",$.filtroStatus),at()}function gm(t){$.autoSendEnabled=t.target.checked,$.autoSendEnabled?(console.log("[Desmarcação] ✅ Envio automático HABILITADO"),U.success("Envio Automático","Mensagens serão enviadas automaticamente",3e3)):(console.log("[Desmarcação] ⏸️ Envio automático DESABILITADO"),U.info("Envio Automático","Mensagens aguardam envio manual",3e3)),localStorage.setItem("hmasp_auto_send_desmarcacao",$.autoSendEnabled)}function vm(){const t=Vs();if(console.log("[Desmarcação] 🔍 DEBUG - Session:",t),!t||!t.user){console.warn("[Desmarcação] Sessão não encontrada");return}const e=t.user.role;console.log("[Desmarcação] Configurando permissões para perfil:",e),e==="admin"?C.clearDesmarcacoesBtn&&(C.clearDesmarcacoesBtn.style.display="inline-flex"):C.clearDesmarcacoesBtn&&(C.clearDesmarcacoesBtn.style.display="none"),C.archiveReagendamentoBtn&&(C.archiveReagendamentoBtn.style.display="inline-flex"),C.archiveSemReagendamentoBtn&&(C.archiveSemReagendamentoBtn.style.display="inline-flex"),C.archivePacienteSolicitouBtn&&(C.archivePacienteSolicitouBtn.style.display="inline-flex"),C.archiveAguardandoConfirmacaoDesmBtn&&(C.archiveAguardandoConfirmacaoDesmBtn.style.display="inline-flex")}function ym(t){console.log("[Desmarcação] Novas desmarcações:",t.length);const e=new Set($.desmarcacoes.map(r=>r.id)),n=t.filter(r=>!e.has(r.id)&&!r.arquivada);if(n.length===0){console.log("[Desmarcação] Nenhuma desmarcação nova (duplicatas ignoradas)");return}$.desmarcacoes=[...n,...$.desmarcacoes],tn(),at(),wt();const o=n.length===1?"1 nova consulta desmarcada":`${n.length} novas consultas desmarcadas`;console.log(`[Desmarcação] ${o}`)}function wt(){const t=$.desmarcacoes.length,e=$.desmarcacoes.filter(a=>a.status==="reagendamento").length,n=$.desmarcacoes.filter(a=>a.status==="sem_reagendamento").length,o=$.desmarcacoes.filter(a=>a.status==="paciente_solicitou").length,r=$.desmarcacoes.filter(a=>a.status===null||a.status===void 0).length;C.statTotalDesmarcacoes&&(C.statTotalDesmarcacoes.textContent=t),C.statReagendamento&&(C.statReagendamento.textContent=e),C.statSemReagendamento&&(C.statSemReagendamento.textContent=n),C.statPacienteSolicitou&&(C.statPacienteSolicitou.textContent=o),C.statAguardandoConfirmacaoDesm&&(C.statAguardandoConfirmacaoDesm.textContent=r)}function at(){if(!C.desmarcacoesList)return;let t=$.desmarcacoes;if($.filtroStatus!=="all"){const o={reagendamento:"reagendamento",sem_reagendamento:"sem_reagendamento",paciente_solicitou:"paciente_solicitou",pending:null}[$.filtroStatus];o===null?t=$.desmarcacoes.filter(r=>r.status===null||r.status===void 0):t=$.desmarcacoes.filter(r=>r.status===o)}if(t.length===0){const n=$.filtroStatus==="all"?"Aguardando consultas desmarcadas...":"Nenhuma desmarcação com esse status";C.desmarcacoesList.innerHTML=`
            <div class="empty-state">
                <div class="empty-icon">📋</div>
                <h3>Nenhuma desmarcação encontrada</h3>
                <p>${n}</p>
            </div>
        `;return}const e=t.map(n=>_m(n)).join("");C.desmarcacoesList.innerHTML=e}function _m(t){const e=t.telefones[0],n=e!=null&&e.telefone?ue.formatForDisplay(e.telefone):"SEM TELEFONE",r=!(e!=null&&e.telefone)?'<span style="color: #ef4444; font-weight: 700;">⚠️ </span>':"";return`
        <div class="confirmation-card-compact" data-id="${t.id}">
            <div class="patient-info">
                <strong>${t.nomePaciente}</strong>
            </div>

            <div class="appointment-details">
                <span>📅 ${jn(t.dataHoraFormatada)}</span>
                <span>🏥 ${jn(t.especialidade)}</span>
                <span>${r}📞 ${n}</span>
            </div>

            <button class="btn-details-compact" onclick="window.showDesmarcacaoDetails('${t.id}')">
                Ver Detalhes
            </button>
        </div>
    `}window.handleSendDesmarcacaoMessage=async function(t){var r;const e=$.desmarcacoes.find(a=>a.id===t);if(!e){U.error("Erro","Desmarcação não encontrada",3e3);return}const n=e.telefones[0];if(!(n!=null&&n.telefone)){U.error("Sem telefone","Paciente não possui telefone cadastrado",4e3);return}if(confirm(`Enviar mensagem sobre desmarcação?

Paciente: ${e.nomePaciente}
Telefone: ${ue.formatForDisplay(n.telefone)}
Consulta: ${e.dataHoraFormatada}`)){(r=document.querySelector(".modal-overlay"))==null||r.remove(),U.info("Enviando...","Adicionando mensagem à fila de envio",3e3);try{const a=await rm(e,0);U.success("Mensagem enviada!",`Adicionada à fila de envio. ID: ${a.queueId}`,5e3),at(),wt()}catch(a){console.error("[Desmarcação] Erro ao enviar:",a),U.error("Erro ao enviar",a.message,6e3)}}};window.showDesmarcacaoDetails=function(t){const e=$.desmarcacoes.find(a=>a.id===t);if(!e){console.error("[Desmarcação] Não encontrada:",t);return}const n=e.telefones[0],o=e.telefones.filter(a=>a.telefone).map(a=>`${ue.formatForDisplay(a.telefone)} (${a.telefoneType})`).join(", ")||"Nenhum telefone cadastrado",r=`
        <div class="modal-overlay" onclick="this.remove()">
            <div class="modal-content" onclick="event.stopPropagation()">
                <div class="modal-header">
                    <h3>Detalhes da Desmarcação</h3>
                    <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="detail-row">
                        <span class="detail-label">Paciente:</span>
                        <span class="detail-value">${e.nomePaciente}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Prontuário:</span>
                        <span class="detail-value">${e.prontuario}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Nr Consulta:</span>
                        <span class="detail-value">${e.consultaNumero}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Especialidade:</span>
                        <span class="detail-value">${jn(e.especialidade)}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Data/Hora:</span>
                        <span class="detail-value">${jn(e.dataHoraFormatada)}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Profissional:</span>
                        <span class="detail-value">${e.profissional||"Não informado"}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Telefones:</span>
                        <span class="detail-value">${o}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Desmarcada em:</span>
                        <span class="detail-value">${e.dataDesmarcacaoFormatada}</span>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn-secondary" onclick="this.closest('.modal-overlay').remove()">Fechar</button>
                    ${n!=null&&n.telefone?`
                        <button class="btn-primary" onclick="window.handleSendDesmarcacaoMessage('${e.id}')">
                            📤 Enviar Mensagem
                        </button>
                    `:""}
                </div>
            </div>
        </div>
    `;document.body.insertAdjacentHTML("beforeend",r)};const O={whatsappReady:!1,currentChat:null,conversations:new Map,messages:new Map,messagesCache:new Map,currentUser:null,userData:null,usuariosUnsubscribe:null,pollingActive:!1,loadMessagesTimeout:null},T={loginScreen:document.getElementById("login-screen"),waitingScreen:document.getElementById("waiting-screen"),app:document.getElementById("app"),loginForm:document.getElementById("login-form"),loginUsername:document.getElementById("login-username"),loginPassword:document.getElementById("login-password"),logoutWaitingBtn:document.getElementById("logout-waiting-btn"),waitingUserInfo:document.getElementById("waiting-user-info"),tabButtons:document.querySelectorAll(".tab-button, .nav-item"),tabContents:document.querySelectorAll(".tab-content"),whatsappStatus:document.getElementById("whatsapp-status"),qrCode:document.getElementById("qr-code"),reconnectBtn:document.getElementById("reconnect-btn"),chatInterface:document.getElementById("chat-interface"),noChatSelected:document.getElementById("no-chat-selected"),chatActive:document.getElementById("chat-active"),conversationsList:document.getElementById("conversations-list"),messagesList:document.getElementById("messages-list"),messageInput:document.getElementById("message-input"),sendBtn:document.getElementById("send-btn"),contactName:document.getElementById("contact-name"),contactStatus:document.getElementById("contact-status"),contactAvatar:document.getElementById("contact-avatar"),newChatBtn:document.getElementById("new-chat-btn"),searchChatsBtn:document.getElementById("search-chats-btn"),chatInfoBtn:document.getElementById("chat-info-btn"),logoutBtn:document.getElementById("logout-btn"),searchBox:document.getElementById("search-box"),searchInput:document.getElementById("search-input"),newChatModal:document.getElementById("new-chat-modal"),newChatNumber:document.getElementById("new-chat-number"),closeNewChat:document.getElementById("close-new-chat"),cancelNewChat:document.getElementById("cancel-new-chat"),confirmNewChat:document.getElementById("confirm-new-chat"),usersList:document.getElementById("users-list"),userManagementSection:document.getElementById("user-management-section"),configTabBtns:document.querySelectorAll(".config-tab-btn"),configContents:document.querySelectorAll(".config-content"),totalUsers:document.getElementById("total-users"),activeUsers:document.getElementById("active-users"),adminUsers:document.getElementById("admin-users"),refreshUsersBtn:document.getElementById("refresh-users-btn"),createUserBtn:document.getElementById("create-user-btn"),createUserModal:document.getElementById("create-user-modal"),createUserForm:document.getElementById("create-user-form"),closeCreateUserBtn:document.getElementById("close-create-user"),cancelCreateUserBtn:document.getElementById("cancel-create-user"),confirmCreateUserBtn:document.getElementById("confirm-create-user"),currentUserEmail:document.getElementById("current-user-email"),systemLogoutBtn:document.getElementById("system-logout-btn"),logoutAccountBtn:document.getElementById("logout-account-btn"),navLogoutBtn:document.getElementById("nav-logout-btn"),clearCacheBtn:document.getElementById("clear-cache-btn"),exportDataBtn:document.getElementById("export-data-btn"),aboutBtn:document.getElementById("about-btn")};async function Ei(){console.log("[App] Iniciando aplicação HMASP Chat..."),Pm(),console.log("[App] Aplicação iniciada com sucesso")}function Em(){T.tabButtons.forEach(t=>{t.addEventListener("click",()=>{const e=t.dataset.tab;Ba(e)})})}function Ba(t){T.tabButtons.forEach(o=>o.classList.remove("active")),T.tabContents.forEach(o=>o.classList.remove("active"));const e=document.querySelector(`[data-tab="${t}"]`),n=document.getElementById(`${t}-tab`);if(e&&n&&(e.classList.add("active"),n.classList.add("active")),localStorage.setItem("activeTab",t),t==="confirmacao"&&Lf(),t==="desmarcacao"&&lm(),t==="config"){const o=document.querySelector('.config-tab-btn[data-config-tab="usuarios"]');o&&!o.classList.contains("active")&&o.click()}}function Im(){if(!T.configTabBtns||T.configTabBtns.length===0)return;T.configTabBtns.forEach(n=>{n.addEventListener("click",()=>{const o=n.dataset.configTab;T.configTabBtns.forEach(a=>a.classList.remove("active")),T.configContents.forEach(a=>a.classList.remove("active")),n.classList.add("active");const r=document.getElementById(`${o}-content`);r&&r.classList.add("active"),localStorage.setItem("activeConfigTab",o)})});const t=localStorage.getItem("activeTab"),e=localStorage.getItem("activeConfigTab");if(t==="config"&&e){const n=document.querySelector(`.config-tab-btn[data-config-tab="${e}"]`);n&&n.click()}}function wm(){T.clearCacheBtn&&T.clearCacheBtn.addEventListener("click",()=>{confirm("Deseja limpar o cache do navegador? Isso pode melhorar o desempenho.")&&(localStorage.clear(),sessionStorage.clear(),alert("Cache limpo com sucesso! A página será recarregada."),window.location.reload())}),T.exportDataBtn&&T.exportDataBtn.addEventListener("click",()=>{alert("Funcionalidade de exportação de dados será implementada em breve.")}),T.aboutBtn&&T.aboutBtn.addEventListener("click",()=>{alert(`HMASP Chat v1.0.0

Sistema de Marcação de Consultas
Hospital Militar de Área de São Paulo

Arquitetura:
- Frontend: Vite + JavaScript
- Backend WhatsApp: Node.js + whatsapp-web.js
- Backend AGHUse: Node.js + PostgreSQL
- Banco de Dados: PostgreSQL (HMASP)`)})}async function Vn(){console.log("[WhatsApp] Verificando status...");try{const t=await qs();t.isReady?(console.log("[WhatsApp] Já conectado"),O.whatsappReady=!0,go(),vo(),po()):t.hasQr?(console.log("[WhatsApp] Aguardando autenticação via QR Code"),await xa(),bm()):(console.log("[WhatsApp] Aguardando QR Code..."),T.qrCode.innerHTML="<p>Aguardando QR Code...</p>",setTimeout(Vn,2e3))}catch(t){console.error("[WhatsApp] Erro ao conectar:",t),Sm()}}async function xa(){try{const t=await Nc();t.connected?(O.whatsappReady=!0,go(),vo(),po()):t.qr&&Tm(t.qr)}catch(t){console.error("[WhatsApp] Erro ao obter QR Code:",t),Am(t.message)}}async function bm(){const t=setInterval(async()=>{try{const e=await qs();e.isReady?(clearInterval(t),O.whatsappReady=!0,go(),vo(),po()):e.hasQr&&await xa()}catch(e){console.error("[WhatsApp] Erro ao verificar status:",e)}},3e3)}function po(){O.pollingActive||(console.log("[Polling] Iniciando polling de atualizações"),O.pollingActive=!0,Bc(async t=>{Ua(t),O.currentChat&&(O.messagesCache.delete(O.currentChat),await ja(O.currentChat))},5e3))}function Tm(t){T.qrCode.innerHTML=`
        <img src="${t}" alt="QR Code WhatsApp" style="width: 256px; height: 256px;">
        <p style="margin-top: 1rem; color: #666;">Escaneie com seu WhatsApp</p>
    `}function go(){T.whatsappStatus.style.display="none",T.chatInterface.style.display="flex"}function Am(t){T.qrCode.innerHTML=`
        <p style="color: #d32f2f;">Erro de autenticação</p>
        <p style="color: #666; font-size: 0.9rem;">${t}</p>
    `,T.reconnectBtn.style.display="block"}function Sm(){T.qrCode.innerHTML=`
        <p style="color: #d32f2f;">Erro ao conectar ao servidor</p>
        <p style="color: #666; font-size: 0.9rem;">Verifique se o servidor está rodando</p>
    `}async function vo(){try{const t=await Ti();console.log("[Chat] Conversas carregadas:",t.length),Ua(t)}catch(t){console.error("[Chat] Erro ao carregar conversas:",t)}}function Ua(t){if(T.conversationsList.innerHTML="",t.length===0){T.conversationsList.innerHTML=`
            <div style="padding: 2rem; text-align: center; color: #666;">
                <p>Nenhuma conversa encontrada</p>
                <p style="font-size: 0.85rem; margin-top: 0.5rem;">Inicie uma nova conversa</p>
            </div>
        `;return}t.forEach(e=>{const n=typeof e.id=="object"?e.id._serialized:e.id;e.chatId=n,O.conversations.set(n,e);const o=Fa(e);T.conversationsList.appendChild(o)})}function Fa(t){const e=document.createElement("div");e.className="conversation-item";const n=t.chatId||(typeof t.id=="object"?t.id._serialized:t.id);e.dataset.chatId=n;const o=yo(t.name),r=_o(o),a=t.lastMessage?t.lastMessage.body:"Sem mensagens",l=t.lastMessage?Rn.formatRelative(new Date(t.lastMessage.timestamp*1e3)):"";return e.innerHTML=`
        <div class="conversation-avatar">${r}</div>
        <div class="conversation-info">
            <div class="conversation-header">
                <span class="conversation-name">${o}</span>
                <span class="conversation-time">${l}</span>
            </div>
            <div class="conversation-preview">${a}</div>
        </div>
        ${t.unreadCount>0?`<div class="unread-badge">${t.unreadCount}</div>`:""}
    `,e.addEventListener("click",()=>Ha(n)),e}function yo(t){if(!t)return"Desconhecido";const e=t.trim().split(" ").filter(n=>n.length>0);return e.length===1?e[0]:e.length===2?`${e[0]} ${e[1]}`:`${e[0]} ${e[e.length-1]}`}function _o(t){const e=t.split(" ").filter(n=>n.length>0);return e.length===0?"?":e.length===1?e[0].charAt(0).toUpperCase():(e[0].charAt(0)+e[e.length-1].charAt(0)).toUpperCase()}function Ha(t){console.log("[Chat] Abrindo conversa:",t),O.currentChat=t,document.querySelectorAll(".conversation-item").forEach(o=>{o.classList.remove("active")});const e=document.querySelector(`[data-chat-id="${t}"]`);e&&e.classList.add("active"),ja(t),Dm(t),T.noChatSelected.style.display="none",T.chatActive.style.display="flex";const n=O.conversations.get(t);if(n){const o=yo(n.name),r=_o(o);T.contactName.textContent=o,T.contactAvatar.textContent=r,T.contactStatus.textContent="online"}}function Cm(){var A;if(!O.currentChat){alert("Selecione uma conversa primeiro");return}const t=O.conversations.get(O.currentChat);if(!t){alert("Conversa não encontrada");return}const e=document.getElementById("contact-info-panel"),n=document.getElementById("info-contact-photo"),o=document.getElementById("info-contact-name"),r=document.getElementById("info-contact-subtitle"),a=document.getElementById("info-contact-phone"),l=yo(t.name),d=_o(l);n.textContent=d,o.textContent=l,t.pushname&&t.pushname!==t.name?r.textContent=`~${t.pushname}`:r.textContent="";const w=(((A=t.id)==null?void 0:A._serialized)||t.id||"").replace(/(\d{2})(\d{2})(\d{5})(\d{4}).*/,"+$1 $2 $3-$4");a.textContent=w,e.classList.add("open")}async function ja(t){O.loadMessagesTimeout&&clearTimeout(O.loadMessagesTimeout),O.loadMessagesTimeout=setTimeout(async()=>{try{if(O.messagesCache.has(t)){console.log("[Chat] Mensagens do cache:",O.messagesCache.get(t).length),Ii(O.messagesCache.get(t));return}const e=await Mc(t,20);console.log("[Chat] Mensagens carregadas:",e.length),O.messagesCache.set(t,e),Ii(e)}catch(e){console.error("[Chat] Erro ao carregar mensagens:",e)}},300)}function Ii(t){const e=document.querySelector(".messages-container"),n=e&&e.scrollHeight-e.scrollTop-e.clientHeight<100;if(T.messagesList.innerHTML="",!t||t.length===0){T.messagesList.innerHTML=`
            <div style="text-align: center; padding: 2rem; color: rgba(0,0,0,0.45);">
                <p style="margin-bottom: 0.5rem;">Nenhuma mensagem ainda</p>
                <p style="font-size: 0.85rem;">Digite uma mensagem abaixo para começar a conversa</p>
            </div>
        `;return}t.forEach(o=>{const r=Va(o);T.messagesList.appendChild(r)}),n&&qa()}function Va(t){const e=document.createElement("div");e.className=`message ${t.fromMe?"sent":"received"}`;const n=Rn.formatTime(new Date(t.timestamp*1e3));let o="";if(t.fromMe)switch(t.ack){case 1:o="✓";break;case 2:o="✓✓";break;case 3:o='<span style="color: #0cb7f2;">✓✓</span>';break;default:o="⏱"}let r="";if(t.hasMedia){const a=t.id._serialized||t.id.id||t.id,d=`/api/media/${O.currentChat}/${a}`;switch(t.type){case"image":r=`
                    <div class="media-message">
                        <div style="padding: 8px; background: #f0f0f0; border-radius: 8px; color: #666; font-size: 0.9em;">
                            📷 Imagem (mídia ignorada)
                        </div>
                        ${t.body?`<div class="media-caption">${ft(t.body)}</div>`:""}
                    </div>
                `;break;case"video":r=`
                    <div class="media-message">
                        <div style="padding: 8px; background: #f0f0f0; border-radius: 8px; color: #666; font-size: 0.9em;">
                            🎬 Vídeo (mídia ignorada)
                        </div>
                        ${t.body?`<div class="media-caption">${ft(t.body)}</div>`:""}
                    </div>
                `;break;case"audio":case"ptt":r=`
                    <div class="media-message">
                        <div style="padding: 8px; background: #f0f0f0; border-radius: 8px; color: #666; font-size: 0.9em;">
                            🎵 Áudio (mídia ignorada)
                        </div>
                        ${t.body?`<div class="media-caption">${ft(t.body)}</div>`:""}
                    </div>
                `;break;case"document":const p=t.body||"Documento";r=`
                    <div class="media-message">
                        <a href="${d}" download="${p}" style="display: flex; align-items: center; gap: 10px; color: inherit; text-decoration: none; padding: 10px; background: rgba(0,0,0,0.05); border-radius: 8px;">
                            📄 <span>${ft(p)}</span>
                        </a>
                    </div>
                `;break;case"sticker":r=`
                    <div class="media-message">
                        <img src="${d}" alt="Sticker"
                             style="max-width: 150px; max-height: 150px; background: transparent;"
                             onerror="this.onerror=null; this.parentElement.innerHTML='<div style=\\'padding: 20px; text-align: center; background: rgba(0,0,0,0.05); border-radius: 8px;\\'><div style=\\'font-size: 40px;\\'>🎭</div><div style=\\'font-size: 12px; color: #999; margin-top: 5px;\\'>Sticker</div></div>';">
                    </div>
                `;break;default:r=`
                    <div class="media-message">
                        <a href="${d}" download style="display: flex; align-items: center; gap: 10px;">
                            📎 <span>Baixar mídia (${t.type})</span>
                        </a>
                        ${t.body?`<div class="media-caption">${ft(t.body)}</div>`:""}
                    </div>
                `}}else r=`<div class="message-text">${ft(t.body)}</div>`;return e.innerHTML=`
        <div class="message-bubble">
            ${r}
            <div class="message-time">
                ${n}
                ${t.fromMe?`<span class="message-status">${o}</span>`:""}
            </div>
        </div>
    `,e}function ft(t){const e=document.createElement("div");return e.textContent=t,e.innerHTML}async function Dm(t){try{await Oc(t)}catch(e){console.error("[Chat] Erro ao marcar como lido:",e)}}async function wi(){const t=T.messageInput.value.trim();if(!(!t||!O.currentChat)){if(!O.whatsappReady){alert("WhatsApp não está conectado");return}console.log("[Chat] Enviando mensagem:",t);try{const e=await Ai(O.currentChat,t);console.log("[Chat] Mensagem enviada com sucesso");const n={id:e.messageId,body:t,timestamp:e.timestamp,fromMe:!0,type:"chat",hasMedia:!1,ack:1},o=Va(n);T.messagesList.appendChild(o),qa();const r=O.conversations.get(O.currentChat);r&&(r.lastMessage={body:t,timestamp:e.timestamp,fromMe:!0},r.timestamp=e.timestamp,Rm(r)),O.messagesCache.delete(O.currentChat),T.messageInput.value="",T.messageInput.style.height="auto"}catch(e){console.error("[Chat] Erro ao enviar mensagem:",e),alert("Erro ao enviar mensagem: "+e.message)}}}function Rm(t){const e=document.querySelector(`[data-chat-id="${t.id}"]`);e&&e.remove();const n=Fa(t),o=T.conversationsList.firstChild;o?T.conversationsList.insertBefore(n,o):T.conversationsList.appendChild(n)}function qa(){const t=document.querySelector(".messages-container");t&&(t.scrollTop=t.scrollHeight)}function bi(t){const e=t.toLowerCase().trim();document.querySelectorAll(".conversation-item").forEach(o=>{var l,d;const r=((l=o.querySelector(".conversation-name"))==null?void 0:l.textContent.toLowerCase())||"",a=((d=o.querySelector(".conversation-preview"))==null?void 0:d.textContent.toLowerCase())||"";r.includes(e)||a.includes(e)?o.style.display="flex":o.style.display="none"})}function km(){T.sendBtn.addEventListener("click",wi),T.messageInput.addEventListener("keydown",n=>{n.key==="Enter"&&!n.shiftKey&&(n.preventDefault(),wi())}),T.messageInput.addEventListener("input",n=>{n.target.style.height="auto",n.target.style.height=n.target.scrollHeight+"px"}),T.reconnectBtn.addEventListener("click",()=>{console.log("[WhatsApp] Reconectando..."),T.reconnectBtn.style.display="none",T.qrCode.innerHTML="<p>Reconectando...</p>",Vn()}),T.newChatBtn.addEventListener("click",()=>{T.newChatModal.style.display="flex",T.newChatNumber.value="",T.newChatNumber.focus()}),T.closeNewChat.addEventListener("click",()=>{T.newChatModal.style.display="none"}),T.cancelNewChat.addEventListener("click",()=>{T.newChatModal.style.display="none"}),T.confirmNewChat.addEventListener("click",()=>{const n=T.newChatNumber.value.trim();if(!n){alert("Digite um número válido");return}const o=n.replace(/\D/g,"");if(o.length<10||o.length>11){alert("Número inválido. Digite DDD + número (ex: 11999887766)");return}const a=`${`55${o}`}@c.us`;T.newChatModal.style.display="none",Ha(a)}),T.newChatModal.addEventListener("click",n=>{n.target===T.newChatModal&&(T.newChatModal.style.display="none")}),T.newChatNumber.addEventListener("keypress",n=>{n.key==="Enter"&&T.confirmNewChat.click()}),T.searchChatsBtn.addEventListener("click",()=>{const n=T.searchBox.style.display!=="none";T.searchBox.style.display=n?"none":"block",n?(T.searchInput.value="",bi("")):T.searchInput.focus()}),T.searchInput.addEventListener("input",n=>{bi(n.target.value)}),T.chatInfoBtn.addEventListener("click",()=>{Cm()});const t=document.getElementById("close-info-btn"),e=document.getElementById("contact-info-panel");t&&t.addEventListener("click",()=>{e.classList.remove("open")}),document.addEventListener("click",n=>{if(e.classList.contains("open")){const o=e.contains(n.target),r=T.chatInfoBtn.contains(n.target);!o&&!r&&e.classList.remove("open")}}),T.logoutBtn.addEventListener("click",async()=>{const n=Pc();if(!n||n.role!=="admin"){alert(`Acesso negado!

Apenas administradores podem deslogar do WhatsApp.`);return}if(confirm(`Deseja realmente deslogar do WhatsApp?

Você precisará escanear o QR Code novamente para reconectar.`)){console.log("[WhatsApp] Iniciando logout...");try{await $c(),console.log("[WhatsApp] Logout realizado com sucesso"),Si(),O.pollingActive=!1,O.whatsappReady=!1,O.currentChat=null,O.conversations.clear(),O.messages.clear(),T.chatInterface.style.display="none",T.whatsappStatus.style.display="flex",T.qrCode.innerHTML="<p>Aguardando novo QR Code...</p>",setTimeout(Vn,2e3)}catch(r){console.error("[WhatsApp] Erro ao fazer logout:",r),alert("Erro ao fazer logout: "+r.message)}}})}function Pm(){console.log("[UI] Iniciando aplicação diretamente (sem login)"),T.loginScreen&&(T.loginScreen.style.display="none"),T.waitingScreen&&(T.waitingScreen.style.display="none"),T.app&&(T.app.style.display="flex"),O.currentUser={username:"admin",name:"Administrador",role:"admin"},Em();const t=localStorage.getItem("activeTab");t&&t!=="chat"&&Ba(t),Im(),wm(),Vn(),km(),Af(),T.currentUserEmail&&(T.currentUserEmail.textContent="Administrador (Acesso Direto)")}window.addEventListener("error",t=>{if(t.target&&(t.target.tagName==="IMG"||t.target.tagName==="VIDEO"||t.target.tagName==="AUDIO")){const e=t.target.src||"";if(e.includes("/api/media/"))return t.preventDefault(),t.stopPropagation(),console.debug("[Media] Mídia não disponível (expirada):",e.split("/").pop()),!1}},!0);document.readyState==="loading"?document.addEventListener("DOMContentLoaded",Ei):Ei();
