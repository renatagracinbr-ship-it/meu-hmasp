#!/bin/bash

echo "=========================================="
echo "  ATUALIZAÇÃO RÁPIDA - HMASP Chat"
echo "=========================================="
echo ""

# Ir para pasta do projeto
cd ~/hmasp-chat

# Baixar arquivos atualizados do Google Drive
echo "1. Copie os arquivos atualizados para ~/Downloads/"
echo "   - dist/ (pasta completa)"
echo "   - server/aghuse-server.js"
echo ""
read -p "Pressione ENTER quando os arquivos estiverem prontos..."

# Backup do server atual
echo "2. Fazendo backup do server atual..."
cp server/aghuse-server.js server/aghuse-server.js.bak

# Copiar arquivos novos
echo "3. Copiando arquivos atualizados..."
rm -rf dist
cp -r ~/Downloads/dist .
cp ~/Downloads/aghuse-server.js server/

# Reiniciar servidor
echo "4. Reiniciando servidor..."
sudo pkill -9 node
sleep 2
node server.js

echo ""
echo "=========================================="
echo "  ATUALIZAÇÃO CONCLUÍDA!"
echo "=========================================="
