/**
 * Servidor AGHUse - Backend
 * Integração com PostgreSQL (só funciona no Node.js, não no navegador)
 */

const { Pool } = require('pg');

// Configuração do banco AGHUse
const DB_CONFIG = {
    host: '10.12.40.219',
    port: 5432,
    database: 'dbaghu',
    user: 'birm_read',
    password: 'birm@read',
    max: 10,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 10000
};

let pool = null;

/**
 * Obtém ou cria o pool de conexões
 */
function getPool() {
    if (!pool) {
        pool = new Pool(DB_CONFIG);
        pool.on('error', (err) => {
            console.error('[AGHUse] Erro no pool de conexões:', err);
        });
        console.log('[AGHUse] Pool de conexões criado');
    }
    return pool;
}

/**
 * Testa conexão com o banco AGHUse
 */
async function testConnection() {
    try {
        const client = getPool();
        const result = await client.query('SELECT NOW() as current_time, version() as version');

        console.log('[AGHUse] Conexão OK:', result.rows[0]);

        return {
            success: true,
            timestamp: result.rows[0].current_time,
            version: result.rows[0].version
        };
    } catch (error) {
        console.error('[AGHUse] Erro ao conectar:', error);
        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Busca consultas marcadas recentemente
 */
async function fetchRecentlyScheduledAppointments(minutes = 5, options = {}) {
    try {
        const client = getPool();
        const limit = options.limit || 100;
        const offset = options.offset || 0;

        const query = `
            WITH marcadas AS (
                SELECT DISTINCT ON (jn1.numero)
                    jn1.numero,
                    jn1.grd_seq,
                    jn1.dt_consulta,
                    jn1.pac_codigo,
                    jn1.jn_date_time as data_hora_marcacao,
                    jn1.jn_user as usuario_marcacao
                FROM agh.aac_consultas_jn jn1
                WHERE jn1.jn_operation = 'UPD'
                    AND jn1.jn_date_time >= NOW() - INTERVAL '${minutes} minutes'
                    AND jn1.stc_situacao = 'M'
                    AND jn1.pac_codigo IS NOT NULL
                ORDER BY jn1.numero, jn1.jn_date_time DESC
            )
            SELECT
                m.numero as consulta_numero,
                m.dt_consulta as data_hora_consulta,
                m.data_hora_marcacao as data_hora_marcacao,
                m.pac_codigo,
                p.prontuario::text as prontuario,
                p.nome as nome_paciente,
                p.cpf::text as cpf_paciente,
                -- Telefones com DDD concatenado
                CASE
                    WHEN p.fone_residencial IS NOT NULL AND p.ddd_fone_residencial IS NOT NULL
                    THEN CONCAT(p.ddd_fone_residencial::text, p.fone_residencial::text)
                    WHEN p.fone_residencial IS NOT NULL
                    THEN p.fone_residencial::text
                    ELSE NULL
                END as telefone_fixo,
                CASE
                    WHEN p.fone_celular IS NOT NULL AND p.ddd_fone_celular IS NOT NULL
                    THEN CONCAT(p.ddd_fone_celular::text, p.fone_celular::text)
                    WHEN p.fone_celular IS NOT NULL
                    THEN p.fone_celular::text
                    ELSE NULL
                END as telefone_celular,
                CASE
                    WHEN p.fone_recado IS NOT NULL AND p.ddd_fone_recado IS NOT NULL
                    THEN CONCAT(p.ddd_fone_recado::text, p.fone_recado::text)
                    WHEN p.fone_recado IS NOT NULL
                    THEN p.fone_recado::text
                    ELSE NULL
                END as telefone_adicional,
                c.stc_situacao as situacao_codigo,
                sit.descricao as situacao_descricao,
                g.esp_seq,
                e.nome_especialidade as especialidade,
                COALESCE(c.ser_matricula_atendido, g.pre_ser_matricula, g.ser_matricula) as ser_matricula,
                COALESCE(c.ser_vin_codigo_atendido, g.pre_ser_vin_codigo, g.ser_vin_codigo) as ser_vin_codigo,
                COALESCE(pf_atendido.nome, pf_pre.nome, pf_grade.nome) as profissional_nome,
                u.descricao as local_descricao
            FROM marcadas m
            LEFT JOIN agh.aac_consultas c ON c.numero = m.numero
            LEFT JOIN agh.aip_pacientes p ON p.codigo = m.pac_codigo
            LEFT JOIN agh.aac_grade_agendamen_consultas g ON g.seq = m.grd_seq
            LEFT JOIN agh.agh_especialidades e ON e.seq = g.esp_seq
            LEFT JOIN agh.aac_situacao_consultas sit ON sit.situacao = c.stc_situacao
            LEFT JOIN agh.rap_servidores s_grade ON s_grade.matricula = g.ser_matricula AND s_grade.vin_codigo = g.ser_vin_codigo
            LEFT JOIN agh.rap_pessoas_fisicas pf_grade ON pf_grade.codigo = s_grade.pes_codigo
            LEFT JOIN agh.rap_servidores s_pre ON s_pre.matricula = g.pre_ser_matricula AND s_pre.vin_codigo = g.pre_ser_vin_codigo
            LEFT JOIN agh.rap_pessoas_fisicas pf_pre ON pf_pre.codigo = s_pre.pes_codigo
            LEFT JOIN agh.rap_servidores s_atendido ON s_atendido.matricula = c.ser_matricula_atendido AND s_atendido.vin_codigo = c.ser_vin_codigo_atendido
            LEFT JOIN agh.rap_pessoas_fisicas pf_atendido ON pf_atendido.codigo = s_atendido.pes_codigo
            LEFT JOIN agh.agh_unidades_funcionais u ON u.seq = g.usl_unf_seq
            WHERE c.stc_situacao = 'M'
            ORDER BY m.data_hora_marcacao DESC
            LIMIT ${limit} OFFSET ${offset};
        `;

        const result = await client.query(query);
        console.log(`[AGHUse] ${result.rows.length} consultas marcadas (offset: ${offset}, limit: ${limit})`);

        return result.rows;

    } catch (error) {
        console.error('[AGHUse] Erro ao buscar consultas recentes:', error);
        throw error;
    }
}

/**
 * Busca consultas desmarcadas recentemente
 *
 * IMPORTANTE: No AGHUse, não existe campo dthr_desmarcacao.
 * Quando uma consulta é desmarcada, a situação muda de 'M' para 'L' na tabela de histórico.
 * Buscamos na tabela aac_consultas_jn (histórico) consultas que mudaram de M para L.
 */
async function fetchRecentlyCancelledAppointments(minutes = 60, options = {}) {
    try {
        const client = getPool();
        const limit = options.limit || 100;
        const offset = options.offset || 0;

        const query = `
            WITH desmarcadas AS (
                SELECT DISTINCT ON (jn1.numero)
                    jn1.numero,
                    jn1.grd_seq,
                    jn1.dt_consulta,
                    jn1.pac_codigo as pac_codigo_journal,
                    jn1.jn_date_time as data_hora_desmarcacao,
                    jn1.jn_user as usuario_desmarcacao,
                    (
                        SELECT jn2.jn_date_time
                        FROM agh.aac_consultas_jn jn2
                        WHERE jn2.numero = jn1.numero
                            AND jn2.jn_date_time < jn1.jn_date_time
                            AND jn2.stc_situacao = 'M'
                            AND jn2.jn_operation != 'DEL'
                        ORDER BY jn2.jn_date_time DESC
                        LIMIT 1
                    ) as data_hora_marcacao_original,
                    (
                        SELECT jn2.pac_codigo
                        FROM agh.aac_consultas_jn jn2
                        WHERE jn2.numero = jn1.numero
                            AND jn2.jn_date_time < jn1.jn_date_time
                            AND jn2.stc_situacao = 'M'
                            AND jn2.jn_operation != 'DEL'
                            AND jn2.pac_codigo IS NOT NULL
                        ORDER BY jn2.jn_date_time DESC
                        LIMIT 1
                    ) as pac_codigo_marcacao_anterior
                FROM agh.aac_consultas_jn jn1
                WHERE jn1.jn_operation = 'UPD'
                    AND jn1.jn_date_time >= NOW() - INTERVAL '${minutes} minutes'
                    AND jn1.stc_situacao = 'L'
                    AND EXISTS (
                        SELECT 1
                        FROM agh.aac_consultas_jn jn_prev
                        WHERE jn_prev.numero = jn1.numero
                            AND jn_prev.jn_date_time < jn1.jn_date_time
                            AND jn_prev.stc_situacao = 'M'
                            AND jn_prev.jn_operation != 'DEL'
                    )
                ORDER BY jn1.numero, jn1.jn_date_time DESC
            )
            SELECT
                d.numero as consulta_numero,
                d.dt_consulta as data_hora_consulta,
                d.data_hora_marcacao_original as data_hora_marcacao,
                d.data_hora_desmarcacao,
                d.usuario_desmarcacao,
                COALESCE(d.pac_codigo_marcacao_anterior, d.pac_codigo_journal, c.pac_codigo) as pac_codigo,
                COALESCE(c.stc_situacao, 'L') as situacao_codigo,
                CASE
                    WHEN c.stc_situacao = 'M' THEN 'MARCADA'
                    WHEN c.stc_situacao = 'L' THEN 'LIVRE'
                    WHEN c.stc_situacao = 'G' THEN 'GERADA'
                    ELSE c.stc_situacao
                END as situacao_descricao,
                p.prontuario::text as prontuario,
                p.nome as nome_paciente,
                p.cpf::text as cpf_paciente,
                -- Telefones com DDD concatenado
                CASE
                    WHEN p.fone_residencial IS NOT NULL AND p.ddd_fone_residencial IS NOT NULL
                    THEN CONCAT(p.ddd_fone_residencial::text, p.fone_residencial::text)
                    WHEN p.fone_residencial IS NOT NULL
                    THEN p.fone_residencial::text
                    ELSE NULL
                END as telefone_fixo,
                CASE
                    WHEN p.fone_celular IS NOT NULL AND p.ddd_fone_celular IS NOT NULL
                    THEN CONCAT(p.ddd_fone_celular::text, p.fone_celular::text)
                    WHEN p.fone_celular IS NOT NULL
                    THEN p.fone_celular::text
                    ELSE NULL
                END as telefone_celular,
                CASE
                    WHEN p.fone_recado IS NOT NULL AND p.ddd_fone_recado IS NOT NULL
                    THEN CONCAT(p.ddd_fone_recado::text, p.fone_recado::text)
                    WHEN p.fone_recado IS NOT NULL
                    THEN p.fone_recado::text
                    ELSE NULL
                END as telefone_adicional,
                g.esp_seq,
                e.nome_especialidade as especialidade,
                COALESCE(c.ser_matricula_atendido, g.pre_ser_matricula, g.ser_matricula) as ser_matricula,
                COALESCE(c.ser_vin_codigo_atendido, g.pre_ser_vin_codigo, g.ser_vin_codigo) as ser_vin_codigo,
                COALESCE(pf_atendido.nome, pf_pre.nome, pf_grade.nome) as profissional_nome,
                u.descricao as local_descricao
            FROM desmarcadas d
            LEFT JOIN agh.aac_consultas c ON c.numero = d.numero
            LEFT JOIN agh.aip_pacientes p ON p.codigo = COALESCE(d.pac_codigo_marcacao_anterior, d.pac_codigo_journal, c.pac_codigo)
            LEFT JOIN agh.aac_grade_agendamen_consultas g ON g.seq = d.grd_seq
            LEFT JOIN agh.agh_especialidades e ON e.seq = g.esp_seq
            LEFT JOIN agh.rap_servidores s_grade ON s_grade.matricula = g.ser_matricula AND s_grade.vin_codigo = g.ser_vin_codigo
            LEFT JOIN agh.rap_pessoas_fisicas pf_grade ON pf_grade.codigo = s_grade.pes_codigo
            LEFT JOIN agh.rap_servidores s_pre ON s_pre.matricula = g.pre_ser_matricula AND s_pre.vin_codigo = g.pre_ser_vin_codigo
            LEFT JOIN agh.rap_pessoas_fisicas pf_pre ON pf_pre.codigo = s_pre.pes_codigo
            LEFT JOIN agh.rap_servidores s_atendido ON s_atendido.matricula = c.ser_matricula_atendido AND s_atendido.vin_codigo = c.ser_vin_codigo_atendido
            LEFT JOIN agh.rap_pessoas_fisicas pf_atendido ON pf_atendido.codigo = s_atendido.pes_codigo
            LEFT JOIN agh.agh_unidades_funcionais u ON u.seq = g.usl_unf_seq
            WHERE COALESCE(d.pac_codigo_marcacao_anterior, d.pac_codigo_journal, c.pac_codigo) IS NOT NULL
            ORDER BY d.data_hora_desmarcacao DESC
            LIMIT ${limit} OFFSET ${offset};
        `;

        const result = await client.query(query);
        console.log(`[AGHUse] ${result.rows.length} consultas desmarcadas (offset: ${offset}, limit: ${limit})`);

        return result.rows;

    } catch (error) {
        console.error('[AGHUse] Erro ao buscar consultas desmarcadas:', error);
        throw error;
    }
}

/**
 * Busca consultas que acontecerão em 72 horas (para envio de lembrete)
 * Retorna consultas marcadas cuja data/hora está entre 71h e 73h no futuro
 */
async function fetchAppointmentsIn72Hours() {
    try {
        const client = getPool();

        const query = `
            SELECT
                c.numero as consulta_numero,
                c.dt_consulta as data_hora_consulta,
                c.dthr_marcacao as data_hora_marcacao,
                c.pac_codigo,
                c.stc_situacao as situacao_codigo,
                CASE
                    WHEN c.stc_situacao = 'M' THEN 'MARCADA'
                    WHEN c.stc_situacao = 'L' THEN 'LIVRE'
                    WHEN c.stc_situacao = 'G' THEN 'GERADA'
                    ELSE c.stc_situacao
                END as situacao_descricao,
                p.prontuario::text as prontuario,
                p.nome as nome_paciente,
                p.cpf::text as cpf_paciente,
                -- Telefones com DDD concatenado
                CASE
                    WHEN p.fone_residencial IS NOT NULL AND p.ddd_fone_residencial IS NOT NULL
                    THEN CONCAT(p.ddd_fone_residencial::text, p.fone_residencial::text)
                    WHEN p.fone_residencial IS NOT NULL
                    THEN p.fone_residencial::text
                    ELSE NULL
                END as telefone_fixo,
                CASE
                    WHEN p.fone_celular IS NOT NULL AND p.ddd_fone_celular IS NOT NULL
                    THEN CONCAT(p.ddd_fone_celular::text, p.fone_celular::text)
                    WHEN p.fone_celular IS NOT NULL
                    THEN p.fone_celular::text
                    ELSE NULL
                END as telefone_celular,
                CASE
                    WHEN p.fone_recado IS NOT NULL AND p.ddd_fone_recado IS NOT NULL
                    THEN CONCAT(p.ddd_fone_recado::text, p.fone_recado::text)
                    WHEN p.fone_recado IS NOT NULL
                    THEN p.fone_recado::text
                    ELSE NULL
                END as telefone_adicional,
                g.esp_seq,
                e.nome_especialidade as especialidade,
                COALESCE(c.ser_matricula_atendido, g.pre_ser_matricula, g.ser_matricula) as ser_matricula,
                COALESCE(c.ser_vin_codigo_atendido, g.pre_ser_vin_codigo, g.ser_vin_codigo) as ser_vin_codigo,
                COALESCE(pf_atendido.nome, pf_pre.nome, pf_grade.nome) as profissional_nome,
                u.descricao as local_descricao
            FROM agh.aac_consultas c
            LEFT JOIN agh.aip_pacientes p ON p.codigo = c.pac_codigo
            LEFT JOIN agh.aac_grade_agendamen_consultas g ON g.seq = c.grd_seq
            LEFT JOIN agh.agh_especialidades e ON e.seq = g.esp_seq
            LEFT JOIN agh.rap_servidores s_grade ON s_grade.matricula = g.ser_matricula AND s_grade.vin_codigo = g.ser_vin_codigo
            LEFT JOIN agh.rap_pessoas_fisicas pf_grade ON pf_grade.codigo = s_grade.pes_codigo
            LEFT JOIN agh.rap_servidores s_pre ON s_pre.matricula = g.pre_ser_matricula AND s_pre.vin_codigo = g.pre_ser_vin_codigo
            LEFT JOIN agh.rap_pessoas_fisicas pf_pre ON pf_pre.codigo = s_pre.pes_codigo
            LEFT JOIN agh.rap_servidores s_atendido ON s_atendido.matricula = c.ser_matricula_atendido AND s_atendido.vin_codigo = c.ser_vin_codigo_atendido
            LEFT JOIN agh.rap_pessoas_fisicas pf_atendido ON pf_atendido.codigo = s_atendido.pes_codigo
            LEFT JOIN agh.agh_unidades_funcionais u ON u.seq = g.usl_unf_seq
            WHERE c.stc_situacao = 'M'
                AND c.pac_codigo IS NOT NULL
                AND c.dt_consulta >= NOW() + INTERVAL '71 hours'
                AND c.dt_consulta <= NOW() + INTERVAL '73 hours'
            ORDER BY c.dt_consulta ASC
            LIMIT 200;
        `;

        const result = await client.query(query);
        console.log(`[AGHUse] ${result.rows.length} consultas para lembrete em 72h encontradas`);

        return result.rows;

    } catch (error) {
        console.error('[AGHUse] Erro ao buscar consultas para lembrete 72h:', error);
        throw error;
    }
}

/**
 * Fecha o pool de conexões
 */
async function closeConnection() {
    if (pool) {
        await pool.end();
        pool = null;
        console.log('[AGHUse] Pool de conexões fechado');
    }
}

module.exports = {
    testConnection,
    fetchRecentlyScheduledAppointments,
    fetchRecentlyCancelledAppointments,
    fetchAppointmentsIn72Hours,
    closeConnection
};
