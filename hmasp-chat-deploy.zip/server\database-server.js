/**
 * Servidor de Banco de Dados - HMASP Chat
 * Gerencia logs e monitoramento em arquivo JSON (local) ou PostgreSQL (produção)
 *
 * AMBIENTE LOCAL: JSON em disco
 * PRODUÇÃO HMASP: PostgreSQL
 */

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3002;

// Middleware
app.use(cors());
app.use(express.json());

// ============================================
// CONFIGURAÇÃO DO BANCO DE DADOS
// ============================================

// Detecta ambiente
const IS_LOCAL = !fs.existsSync('/etc/hmasp'); // Se não existe /etc/hmasp, é local

let db = null;

if (IS_LOCAL) {
    // DESENVOLVIMENTO LOCAL: Arquivo JSON
    const dbPath = path.join(__dirname, '../database/monitoramento.json');

    console.log('[Database] Modo LOCAL - Usando JSON:', dbPath);

    // Cria diretório se não existir
    const dbDir = path.dirname(dbPath);
    if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
    }

    // Carrega ou cria arquivo JSON
    if (!fs.existsSync(dbPath)) {
        const initialData = {
            config: {
                ativo: false,
                ultimaVerificacao: null,
                totalEnviadas: 0,
                totalFalhas: 0,
                atualizadoEm: new Date().toISOString()
            },
            consultasProcessadas: {}
        };
        fs.writeFileSync(dbPath, JSON.stringify(initialData, null, 2));
    }

    db = {
        path: dbPath,
        load: function() {
            return JSON.parse(fs.readFileSync(this.path, 'utf8'));
        },
        save: function(data) {
            fs.writeFileSync(this.path, JSON.stringify(data, null, 2));
        }
    };

    console.log('[Database] JSON inicializado');

} else {
    // PRODUÇÃO HMASP: PostgreSQL
    console.log('[Database] Modo PRODUÇÃO - Usando PostgreSQL');

    const { Pool } = require('pg');

    const pool = new Pool({
        host: 'localhost',
        port: 5432,
        database: 'hmasp_chat',
        user: process.env.DB_USER || 'hmasp_user',
        password: process.env.DB_PASSWORD || 'hmasp_pass',
        max: 10,
        idleTimeoutMillis: 30000,
        connectionTimeoutMillis: 10000
    });

    pool.on('error', (err) => {
        console.error('[Database] Erro no pool PostgreSQL:', err);
    });

    db = pool;
    console.log('[Database] PostgreSQL pool criado');
}

// ============================================
// API: ESTADO DO MONITORAMENTO
// ============================================

/**
 * GET /api/database/monitoramento/state
 * Carrega estado do monitoramento
 */
app.get('/api/database/monitoramento/state', async (req, res) => {
    try {
        if (IS_LOCAL) {
            // JSON
            const data = db.load();

            res.json({
                success: true,
                state: data.config
            });

        } else {
            // PostgreSQL
            const result = await db.query(`
                SELECT * FROM monitoramento_config WHERE id = 1
            `);

            const config = result.rows[0];

            res.json({
                success: true,
                state: config || {
                    ativo: false,
                    ultimaVerificacao: null,
                    totalEnviadas: 0,
                    totalFalhas: 0
                }
            });
        }

    } catch (error) {
        console.error('[Database] Erro ao carregar estado:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * POST /api/database/monitoramento/state
 * Salva estado do monitoramento
 */
app.post('/api/database/monitoramento/state', async (req, res) => {
    try {
        const { ativo, ultimaVerificacao, totalEnviadas, totalFalhas } = req.body;

        if (IS_LOCAL) {
            // JSON
            const data = db.load();
            data.config = {
                ativo: Boolean(ativo),
                ultimaVerificacao: ultimaVerificacao || null,
                totalEnviadas: totalEnviadas || 0,
                totalFalhas: totalFalhas || 0,
                atualizadoEm: new Date().toISOString()
            };
            db.save(data);

        } else {
            // PostgreSQL
            await db.query(`
                INSERT INTO monitoramento_config (id, ativo, ultima_verificacao, total_enviadas, total_falhas)
                VALUES (1, $1, $2, $3, $4)
                ON CONFLICT (id) DO UPDATE SET
                    ativo = $1,
                    ultima_verificacao = $2,
                    total_enviadas = $3,
                    total_falhas = $4,
                    atualizado_em = NOW()
            `, [ativo, ultimaVerificacao, totalEnviadas, totalFalhas]);
        }

        res.json({ success: true });

    } catch (error) {
        console.error('[Database] Erro ao salvar estado:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ============================================
// API: CONSULTAS PROCESSADAS
// ============================================

/**
 * POST /api/database/monitoramento/consulta
 * Registra consulta como processada
 */
app.post('/api/database/monitoramento/consulta', async (req, res) => {
    try {
        const { consultaNumero, status, detalhes } = req.body;

        if (!consultaNumero || !status) {
            return res.status(400).json({
                success: false,
                error: 'consultaNumero e status são obrigatórios'
            });
        }

        const {
            paciente = '',
            telefone = '',
            messageId = '',
            queueId = '',
            erro = '',
            tentativas = 1
        } = detalhes || {};

        if (IS_LOCAL) {
            // JSON
            const data = db.load();
            data.consultasProcessadas[consultaNumero] = {
                consultaNumero,
                status,
                paciente,
                telefone,
                messageId,
                queueId,
                erro,
                tentativas,
                processadoEm: new Date().toISOString()
            };
            db.save(data);

        } else {
            // PostgreSQL
            await db.query(`
                INSERT INTO consultas_processadas
                (consulta_numero, status, paciente, telefone, message_id, queue_id, erro, tentativas)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                ON CONFLICT (consulta_numero) DO UPDATE SET
                    status = $2,
                    paciente = $3,
                    telefone = $4,
                    message_id = $5,
                    queue_id = $6,
                    erro = $7,
                    tentativas = $8,
                    processado_em = NOW()
            `, [consultaNumero, status, paciente, telefone, messageId, queueId, erro, tentativas]);
        }

        res.json({ success: true });

    } catch (error) {
        console.error('[Database] Erro ao registrar consulta:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * GET /api/database/monitoramento/consulta/:numero
 * Verifica se consulta já foi processada
 */
app.get('/api/database/monitoramento/consulta/:numero', async (req, res) => {
    try {
        const { numero } = req.params;

        let jaProcessada = false;

        if (IS_LOCAL) {
            // JSON
            const data = db.load();
            jaProcessada = !!data.consultasProcessadas[numero];

        } else {
            // PostgreSQL
            const result = await db.query(
                'SELECT 1 FROM consultas_processadas WHERE consulta_numero = $1',
                [numero]
            );
            jaProcessada = result.rows.length > 0;
        }

        res.json({
            success: true,
            processada: jaProcessada
        });

    } catch (error) {
        console.error('[Database] Erro ao verificar consulta:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * POST /api/database/monitoramento/consultas/filtrar
 * Filtra consultas não processadas
 */
app.post('/api/database/monitoramento/consultas/filtrar', async (req, res) => {
    try {
        const { consultas } = req.body;

        if (!Array.isArray(consultas)) {
            return res.status(400).json({
                success: false,
                error: 'consultas deve ser um array'
            });
        }

        const naoProcessadas = [];

        for (const consulta of consultas) {
            const numero = consulta.consultaNumero;
            let processada = false;

            if (IS_LOCAL) {
                // JSON
                const data = db.load();
                processada = !!data.consultasProcessadas[numero];

            } else {
                // PostgreSQL
                const result = await db.query(
                    'SELECT 1 FROM consultas_processadas WHERE consulta_numero = $1',
                    [numero]
                );
                processada = result.rows.length > 0;
            }

            if (!processada) {
                naoProcessadas.push(consulta);
            }
        }

        res.json({
            success: true,
            naoProcessadas,
            total: consultas.length,
            naoProcessadasCount: naoProcessadas.length
        });

    } catch (error) {
        console.error('[Database] Erro ao filtrar consultas:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ============================================
// API: ESTATÍSTICAS
// ============================================

/**
 * GET /api/database/monitoramento/stats
 * Obtém estatísticas do monitoramento
 */
app.get('/api/database/monitoramento/stats', async (req, res) => {
    try {
        let stats;

        if (IS_LOCAL) {
            // JSON
            const data = db.load();
            const consultas = Object.values(data.consultasProcessadas);

            const totalProcessadas = consultas.length;
            const totalEnviadas = consultas.filter(c => c.status === 'enviado').length;
            const totalFalhas = consultas.filter(c => c.status === 'falha').length;

            stats = {
                ativo: data.config.ativo,
                ultimaVerificacao: data.config.ultimaVerificacao,
                totalProcessadas,
                totalEnviadas,
                totalFalhas,
                taxaSucesso: totalEnviadas > 0
                    ? ((totalEnviadas / (totalEnviadas + totalFalhas)) * 100).toFixed(2) + '%'
                    : '0%'
            };

        } else {
            // PostgreSQL
            const config = await db.query('SELECT * FROM monitoramento_config WHERE id = 1');
            const totalProcessadas = await db.query('SELECT COUNT(*) as total FROM consultas_processadas');
            const totalEnviadas = await db.query("SELECT COUNT(*) as total FROM consultas_processadas WHERE status = 'enviado'");
            const totalFalhas = await db.query("SELECT COUNT(*) as total FROM consultas_processadas WHERE status = 'falha'");

            stats = {
                ativo: config.rows[0]?.ativo,
                ultimaVerificacao: config.rows[0]?.ultima_verificacao,
                totalProcessadas: parseInt(totalProcessadas.rows[0].total),
                totalEnviadas: parseInt(totalEnviadas.rows[0].total),
                totalFalhas: parseInt(totalFalhas.rows[0].total),
                taxaSucesso: totalEnviadas.rows[0].total > 0
                    ? ((totalEnviadas.rows[0].total / (totalEnviadas.rows[0].total + totalFalhas.rows[0].total)) * 100).toFixed(2) + '%'
                    : '0%'
            };
        }

        res.json({
            success: true,
            stats
        });

    } catch (error) {
        console.error('[Database] Erro ao obter estatísticas:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * DELETE /api/database/monitoramento/reset
 * Reseta estado do monitoramento
 */
app.delete('/api/database/monitoramento/reset', async (req, res) => {
    try {
        if (IS_LOCAL) {
            // JSON
            const data = db.load();
            data.config = {
                ativo: false,
                ultimaVerificacao: null,
                totalEnviadas: 0,
                totalFalhas: 0,
                atualizadoEm: new Date().toISOString()
            };
            db.save(data);

        } else {
            // PostgreSQL
            await db.query(`
                UPDATE monitoramento_config
                SET ativo = false,
                    ultima_verificacao = NULL,
                    total_enviadas = 0,
                    total_falhas = 0,
                    atualizado_em = NOW()
                WHERE id = 1
            `);
        }

        res.json({ success: true });

    } catch (error) {
        console.error('[Database] Erro ao resetar monitoramento:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ============================================
// INICIALIZAÇÃO
// ============================================

app.listen(PORT, () => {
    console.log(`[Database Server] Rodando na porta ${PORT}`);
    console.log(`[Database Server] Ambiente: ${IS_LOCAL ? 'LOCAL (JSON)' : 'PRODUÇÃO (PostgreSQL)'}`);
});

// Tratamento de erros
process.on('unhandledRejection', (error) => {
    console.error('[Database] Erro não tratado:', error);
});

process.on('SIGTERM', () => {
    console.log('[Database] Encerrando servidor...');
    if (!IS_LOCAL && db) {
        db.end();
    }
    process.exit(0);
});
