# ⚡ Comandos Rápidos - HMASP Chat Ubuntu

## 🚀 Instalação Inicial (apenas uma vez)

```bash
# 1. Instalar Node.js 20 LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# 2. Extrair projeto
cd ~
unzip hmasp-chat-deploy.zip -d hmasp-chat
cd hmasp-chat

# 3. Instalar dependências
npm install

# 4. Testar manualmente
node server.js
# Ctrl+C para parar

# 5. Criar serviço systemd
sudo nano /etc/systemd/system/hmasp-chat.service
# Colar conteúdo do serviço (ver INSTALACAO-UBUNTU.md)
# Ctrl+O, Enter, Ctrl+X

# 6. Ativar serviço
sudo systemctl daemon-reload
sudo systemctl enable hmasp-chat
sudo systemctl start hmasp-chat

# 7. Configurar firewall
sudo ufw allow 3000/tcp
sudo ufw enable
```

---

## 🔧 Gerenciamento do Serviço

```bash
# Iniciar serviço
sudo systemctl start hmasp-chat

# Parar serviço
sudo systemctl stop hmasp-chat

# Reiniciar serviço
sudo systemctl restart hmasp-chat

# Ver status
sudo systemctl status hmasp-chat

# Habilitar início automático (boot)
sudo systemctl enable hmasp-chat

# Desabilitar início automático
sudo systemctl disable hmasp-chat
```

---

## 📋 Logs e Monitoramento

```bash
# Ver logs em tempo real
sudo journalctl -u hmasp-chat -f

# Últimas 50 linhas
sudo journalctl -u hmasp-chat -n 50

# Últimas 100 linhas
sudo journalctl -u hmasp-chat -n 100

# Logs de hoje
sudo journalctl -u hmasp-chat --since today

# Logs de ontem
sudo journalctl -u hmasp-chat --since yesterday

# Logs de erros apenas
sudo journalctl -u hmasp-chat -p err

# Limpar logs antigos (liberar espaço)
sudo journalctl --vacuum-time=7d
```

---

## 🔍 Diagnóstico e Troubleshooting

```bash
# Ver processos Node.js
ps aux | grep node

# Ver o que está usando a porta 3000
sudo lsof -i :3000

# Matar processo na porta 3000
sudo kill -9 $(sudo lsof -t -i:3000)

# Ver uso de CPU e RAM
top
# Pressione 'q' para sair

# Ver uso de CPU e RAM (mais amigável)
htop
# Pressione F10 para sair

# Ver espaço em disco
df -h

# Ver IP da máquina
hostname -I
# ou
ip addr show

# Testar conectividade
ping google.com
ping 8.8.8.8

# Testar porta aberta (de outro computador)
telnet IP_DA_VM 3000
```

---

## 🗄️ PostgreSQL (AGHUse)

```bash
# Ver status do PostgreSQL
sudo systemctl status postgresql

# Iniciar PostgreSQL
sudo systemctl start postgresql

# Parar PostgreSQL
sudo systemctl stop postgresql

# Reiniciar PostgreSQL
sudo systemctl restart postgresql

# Conectar ao PostgreSQL
sudo -u postgres psql

# Conectar a banco específico
psql -h IP -p 5432 -U usuario -d banco_de_dados

# Dentro do psql:
\l              # Listar bancos
\dt             # Listar tabelas
\q              # Sair
```

---

## 📦 Atualização do App

```bash
# 1. Parar serviço
sudo systemctl stop hmasp-chat

# 2. Fazer backup
cd ~
cp -r hmasp-chat hmasp-chat-backup-$(date +%Y%m%d-%H%M%S)

# 3. Extrair nova versão
unzip hmasp-chat-deploy-NOVO.zip -d hmasp-chat-temp/

# 4. Sobrescrever arquivos (mantém .wwebjs_auth)
cp -r hmasp-chat-temp/dist hmasp-chat/
cp hmasp-chat-temp/server.js hmasp-chat/
cp hmasp-chat-temp/package.json hmasp-chat/
cp -r hmasp-chat-temp/server hmasp-chat/

# 5. Reinstalar dependências (se package.json mudou)
cd hmasp-chat
npm install

# 6. Reiniciar serviço
sudo systemctl start hmasp-chat

# 7. Verificar
sudo systemctl status hmasp-chat
sudo journalctl -u hmasp-chat -n 20
```

---

## 🔄 Resetar Sessão WhatsApp

```bash
# 1. Parar serviço
sudo systemctl stop hmasp-chat

# 2. Deletar sessão
cd ~/hmasp-chat
rm -rf server/.wwebjs_auth

# 3. Reiniciar serviço
sudo systemctl start hmasp-chat

# 4. Acessar app e escanear QR Code
# http://IP_DA_VM:3000
```

---

## 🛠️ Manutenção do Sistema

```bash
# Atualizar sistema Ubuntu
sudo apt update
sudo apt upgrade -y

# Limpar pacotes não utilizados
sudo apt autoremove -y
sudo apt autoclean

# Ver versão do Node.js
node --version

# Ver versão do npm
npm --version

# Atualizar npm globalmente
sudo npm install -g npm@latest

# Verificar integridade do sistema de arquivos
sudo fsck -f /dev/sda1  # Ajustar device conforme necessário
```

---

## 🔥 Firewall (UFW)

```bash
# Ver status do firewall
sudo ufw status verbose

# Habilitar firewall
sudo ufw enable

# Desabilitar firewall
sudo ufw disable

# Permitir porta 3000 (HMASP Chat)
sudo ufw allow 3000/tcp

# Permitir SSH
sudo ufw allow 22/tcp

# Permitir PostgreSQL
sudo ufw allow 5432/tcp

# Negar porta
sudo ufw deny 8080/tcp

# Deletar regra
sudo ufw delete allow 8080/tcp

# Resetar firewall (CUIDADO!)
sudo ufw reset

# Recarregar firewall
sudo ufw reload
```

---

## 💾 Backup e Restore

```bash
# Backup completo do app
cd ~
tar -czf hmasp-chat-backup-$(date +%Y%m%d-%H%M%S).tar.gz hmasp-chat/

# Backup apenas da sessão WhatsApp
cd ~/hmasp-chat
tar -czf wwebjs-backup-$(date +%Y%m%d-%H%M%S).tar.gz server/.wwebjs_auth/

# Restaurar backup
cd ~
tar -xzf hmasp-chat-backup-YYYYMMDD-HHMMSS.tar.gz

# Restaurar apenas sessão WhatsApp
cd ~/hmasp-chat/server
tar -xzf wwebjs-backup-YYYYMMDD-HHMMSS.tar.gz
```

---

## 🌐 Rede e Conectividade

```bash
# Ver todas as interfaces de rede
ip addr show

# Ver rotas
ip route show

# Ver conexões ativas
ss -tulpn

# Ver portas abertas
sudo netstat -tulpn | grep LISTEN

# Testar DNS
nslookup google.com
dig google.com

# Testar conexão HTTP
curl http://localhost:3000
curl http://IP_DA_VM:3000

# Download de arquivo
wget URL_DO_ARQUIVO

# Transferir arquivo via SCP (de outro computador)
scp arquivo.zip usuario@IP_DA_VM:/home/usuario/
```

---

## 📝 Edição de Arquivos

```bash
# Editar com nano (mais fácil)
nano arquivo.txt
# Ctrl+O = Salvar
# Ctrl+X = Sair

# Editar com vi/vim
vi arquivo.txt
# i = modo inserção
# Esc = sair do modo inserção
# :wq = salvar e sair
# :q! = sair sem salvar

# Ver arquivo
cat arquivo.txt
less arquivo.txt  # Navegar com setas, 'q' para sair
head -n 20 arquivo.txt  # Primeiras 20 linhas
tail -n 20 arquivo.txt  # Últimas 20 linhas
tail -f arquivo.log     # Monitorar arquivo em tempo real
```

---

## 🔐 Permissões

```bash
# Ver permissões
ls -la

# Mudar dono de arquivo/pasta
sudo chown usuario:usuario arquivo.txt
sudo chown -R usuario:usuario pasta/

# Mudar permissões (rwx = 7, rw- = 6, r-- = 4)
chmod 755 arquivo.sh    # rwxr-xr-x
chmod 644 arquivo.txt   # rw-r--r--
chmod -R 755 pasta/

# Tornar script executável
chmod +x script.sh
```

---

## 🚨 Emergência

```bash
# Reiniciar servidor (CUIDADO!)
sudo reboot

# Desligar servidor
sudo shutdown now

# Desligar em 5 minutos
sudo shutdown +5

# Cancelar shutdown agendado
sudo shutdown -c

# Forçar parada do HMASP Chat
sudo pkill -9 node

# Ver últimas reinicializações
last reboot
```

---

## 📊 Performance

```bash
# Ver uso de recursos
htop

# Ver uso de disco por pasta
du -sh ~/hmasp-chat/*

# Ver arquivos grandes
du -ah ~/hmasp-chat | sort -rh | head -n 20

# Limpar cache do npm
npm cache clean --force

# Limpar node_modules e reinstalar
cd ~/hmasp-chat
rm -rf node_modules
npm install
```

---

## ✅ Verificação Rápida

```bash
# Script de verificação completa
echo "=== HMASP Chat - Status ==="
echo ""
echo "1. Serviço:"
sudo systemctl status hmasp-chat | grep Active
echo ""
echo "2. Porta 3000:"
sudo lsof -i :3000
echo ""
echo "3. Últimos logs:"
sudo journalctl -u hmasp-chat -n 5 --no-pager
echo ""
echo "4. Uso de recursos:"
ps aux | grep node | grep -v grep
echo ""
echo "5. IP da máquina:"
hostname -I
```

---

## 🆘 Ajuda Rápida

```bash
# Ajuda de comando
comando --help
man comando

# Ver histórico de comandos
history

# Buscar no histórico
history | grep palavra

# Limpar tela
clear
# ou Ctrl+L
```

---

**Dica:** Salve este arquivo em um local acessível para consulta rápida!

**Atalhos úteis no terminal:**
- `Ctrl+C` = Parar comando atual
- `Ctrl+Z` = Suspender comando
- `Ctrl+D` = Sair do terminal
- `Ctrl+L` = Limpar tela
- `Ctrl+R` = Buscar no histórico
- `Tab` = Auto-completar
- `↑` / `↓` = Navegar histórico
