/**
 * Servidor Backend para integração WhatsApp Web
 * Utiliza whatsapp-web.js para conexão via QR Code
 */

const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

// Middlewares
app.use(cors());
app.use(express.json());

// Estado do WhatsApp
let whatsappClient = null;
let isReady = false;
let qrCodeData = null;

// Inicializa o cliente WhatsApp
function initializeWhatsApp() {
    // Evita inicializar se já existe um cliente ativo
    if (whatsappClient) {
        console.log('[WhatsApp] Cliente já existe, pulando inicialização');
        return;
    }

    console.log('[WhatsApp] Inicializando novo cliente...');

    whatsappClient = new Client({
        authStrategy: new LocalAuth({
            dataPath: path.join(__dirname, '.wwebjs_auth')
        }),
        puppeteer: {
            headless: true,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--no-first-run',
                '--no-zygote',
                '--disable-gpu'
            ]
        }
    });

    // Evento: QR Code gerado
    whatsappClient.on('qr', async (qr) => {
        console.log('[WhatsApp] QR Code recebido');
        qrCodeData = qr;

        // Gera imagem do QR Code
        try {
            const qrImage = await qrcode.toDataURL(qr);
            io.emit('qr', { qr: qrImage, raw: qr });
        } catch (err) {
            console.error('[WhatsApp] Erro ao gerar QR Code:', err);
        }
    });

    // Evento: Autenticação
    whatsappClient.on('authenticated', () => {
        console.log('[WhatsApp] Autenticado com sucesso');
        io.emit('authenticated');
    });

    // Evento: Pronto para uso
    whatsappClient.on('ready', () => {
        console.log('[WhatsApp] Cliente pronto!');
        isReady = true;
        qrCodeData = null;
        io.emit('ready', {
            status: 'connected',
            info: whatsappClient.info
        });
    });

    // Evento: Mensagem recebida
    whatsappClient.on('message', async (message) => {
        console.log('[WhatsApp] Mensagem recebida:', message.from);

        const contact = await message.getContact();
        const chat = await message.getChat();

        const messageData = {
            id: message.id._serialized,
            from: message.from,
            to: message.to,
            body: message.body,
            timestamp: message.timestamp,
            type: message.type,
            isForwarded: message.isForwarded,
            hasMedia: message.hasMedia,
            contact: {
                id: contact.id._serialized,
                name: contact.name || contact.pushname || contact.number,
                number: contact.number,
                isMyContact: contact.isMyContact
            },
            chat: {
                id: chat.id._serialized,
                name: chat.name,
                isGroup: chat.isGroup,
                unreadCount: chat.unreadCount
            }
        };

        io.emit('message', messageData);
    });

    // Evento: Desconectado
    whatsappClient.on('disconnected', (reason) => {
        console.log('[WhatsApp] Desconectado:', reason);
        isReady = false;
        io.emit('disconnected', { reason });
    });

    // Evento: Erro
    whatsappClient.on('auth_failure', (error) => {
        console.error('[WhatsApp] Falha na autenticação:', error);
        io.emit('auth_failure', { error: error.message });
    });

    // Inicializa o cliente
    whatsappClient.initialize();
}

// WebSocket - Conexão do cliente
io.on('connection', (socket) => {
    console.log('[Socket.IO] Cliente conectado:', socket.id);

    // Envia status atual
    socket.emit('status', {
        isReady,
        qr: qrCodeData
    });

    // Evento: Enviar mensagem
    socket.on('send_message', async (data, callback) => {
        try {
            if (!isReady) {
                throw new Error('WhatsApp não está conectado');
            }

            const { to, message, mediaUrl } = data;

            let sentMessage;

            if (mediaUrl) {
                // Enviar com mídia
                const media = await MessageMedia.fromUrl(mediaUrl);
                sentMessage = await whatsappClient.sendMessage(to, media, { caption: message });
            } else {
                // Enviar apenas texto
                sentMessage = await whatsappClient.sendMessage(to, message);
            }

            const response = {
                success: true,
                messageId: sentMessage.id._serialized,
                timestamp: sentMessage.timestamp
            };

            callback(response);
        } catch (error) {
            console.error('[WhatsApp] Erro ao enviar mensagem:', error);
            callback({
                success: false,
                error: error.message
            });
        }
    });

    // Evento: Obter conversas
    socket.on('get_chats', async (callback) => {
        try {
            if (!isReady) {
                throw new Error('WhatsApp não está conectado');
            }

            const chats = await whatsappClient.getChats();
            const chatsData = [];

            for (const chat of chats) {
                const lastMessage = chat.lastMessage;

                chatsData.push({
                    id: chat.id._serialized,
                    name: chat.name,
                    isGroup: chat.isGroup,
                    unreadCount: chat.unreadCount,
                    timestamp: chat.timestamp,
                    lastMessage: lastMessage ? {
                        body: lastMessage.body,
                        timestamp: lastMessage.timestamp,
                        fromMe: lastMessage.fromMe
                    } : null
                });
            }

            // Ordena por timestamp decrescente
            chatsData.sort((a, b) => b.timestamp - a.timestamp);

            callback({
                success: true,
                chats: chatsData
            });
        } catch (error) {
            console.error('[WhatsApp] Erro ao obter conversas:', error);
            callback({
                success: false,
                error: error.message
            });
        }
    });

    // Evento: Obter mensagens de uma conversa
    socket.on('get_messages', async (data, callback) => {
        try {
            if (!isReady) {
                throw new Error('WhatsApp não está conectado');
            }

            const { chatId, limit = 50 } = data;
            const chat = await whatsappClient.getChatById(chatId);
            const messages = await chat.fetchMessages({ limit });

            const messagesData = [];

            for (const msg of messages) {
                // Evita chamar getContact() que usa API depreciada
                // Usa informações básicas disponíveis diretamente na mensagem
                const contactName = msg._data.notifyName || msg._data.from || 'Desconhecido';

                messagesData.push({
                    id: msg.id._serialized,
                    body: msg.body,
                    timestamp: msg.timestamp,
                    fromMe: msg.fromMe,
                    type: msg.type,
                    hasMedia: msg.hasMedia,
                    ack: msg.ack, // Status de entrega
                    contact: {
                        name: contactName,
                        number: msg.from
                    }
                });
            }

            callback({
                success: true,
                messages: messagesData
            });
        } catch (error) {
            console.error('[Chat] Erro ao carregar mensagens:', error);
            callback({
                success: false,
                error: error.message
            });
        }
    });

    // Evento: Marcar como lido
    socket.on('mark_as_read', async (data, callback) => {
        try {
            if (!isReady) {
                throw new Error('WhatsApp não está conectado');
            }

            const { chatId } = data;
            const chat = await whatsappClient.getChatById(chatId);
            await chat.sendSeen();

            callback({ success: true });
        } catch (error) {
            console.error('[WhatsApp] Erro ao marcar como lido:', error);
            callback({
                success: false,
                error: error.message
            });
        }
    });

    // Evento: Reconectar
    socket.on('reconnect_whatsapp', () => {
        console.log('[WhatsApp] Tentando reconectar...');
        if (whatsappClient) {
            whatsappClient.destroy();
        }
        initializeWhatsApp();
    });

    // Evento: Logout (deslogar do WhatsApp)
    socket.on('logout_whatsapp', async (callback) => {
        try {
            if (!whatsappClient) {
                throw new Error('Cliente WhatsApp não inicializado');
            }

            console.log('[WhatsApp] Deslogando...');

            // Faz logout do WhatsApp Web
            await whatsappClient.logout();

            // Destrói o cliente
            await whatsappClient.destroy();

            // Reseta as variáveis de estado
            isReady = false;
            qrCodeData = null;
            whatsappClient = null;

            console.log('[WhatsApp] Logout realizado com sucesso');

            // Notifica todos os clientes conectados
            io.emit('logged_out');

            // Reinicializa o cliente para permitir novo login após aguardar destruição completa
            setTimeout(() => {
                console.log('[WhatsApp] Reinicializando cliente após logout...');
                initializeWhatsApp();
            }, 2000);

            callback({ success: true });
        } catch (error) {
            console.error('[WhatsApp] Erro ao fazer logout:', error);

            // Mesmo com erro, tenta reinicializar
            isReady = false;
            qrCodeData = null;
            whatsappClient = null;

            setTimeout(() => {
                initializeWhatsApp();
            }, 2000);

            callback({
                success: false,
                error: error.message
            });
        }
    });

    socket.on('disconnect', () => {
        console.log('[Socket.IO] Cliente desconectado:', socket.id);
    });
});

// API REST Endpoints

// Status do servidor
app.get('/api/status', (req, res) => {
    res.json({
        server: 'online',
        whatsapp: isReady ? 'connected' : 'disconnected',
        timestamp: new Date().toISOString()
    });
});

// Informações do WhatsApp
app.get('/api/whatsapp/info', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({
                success: false,
                error: 'WhatsApp não está conectado'
            });
        }

        const info = whatsappClient.info;
        res.json({
            success: true,
            info: {
                wid: info.wid._serialized,
                pushname: info.pushname,
                platform: info.platform
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Enviar mensagem via API REST
app.post('/api/whatsapp/send', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({
                success: false,
                error: 'WhatsApp não está conectado'
            });
        }

        const { to, message, mediaUrl } = req.body;

        if (!to || !message) {
            return res.status(400).json({
                success: false,
                error: 'Campos "to" e "message" são obrigatórios'
            });
        }

        let sentMessage;

        if (mediaUrl) {
            const media = await MessageMedia.fromUrl(mediaUrl);
            sentMessage = await whatsappClient.sendMessage(to, media, { caption: message });
        } else {
            sentMessage = await whatsappClient.sendMessage(to, message);
        }

        res.json({
            success: true,
            messageId: sentMessage.id._serialized,
            timestamp: sentMessage.timestamp
        });
    } catch (error) {
        console.error('[API] Erro ao enviar mensagem:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Inicializa o servidor
const PORT = process.env.PORT || 3000;

server.listen(PORT, () => {
    console.log(`[Servidor] Rodando na porta ${PORT}`);
    console.log(`[Servidor] API REST: http://localhost:${PORT}/api`);
    console.log(`[Servidor] WebSocket: http://localhost:${PORT}`);

    // Inicializa WhatsApp
    initializeWhatsApp();
});

// Tratamento de erros não capturados
process.on('unhandledRejection', (error) => {
    console.error('[Erro não tratado]:', error);
});

process.on('SIGINT', async () => {
    console.log('\n[Servidor] Encerrando...');
    if (whatsappClient) {
        await whatsappClient.destroy();
    }
    process.exit(0);
});
