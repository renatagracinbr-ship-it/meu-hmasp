/**
 * Servidor Backend MINIMALISTA para WhatsApp
 * APENAS autenticação e envio de mensagens
 * Sem WebSocket - apenas API REST
 * Otimizado para custos mínimos no Google Cloud Run
 */

const express = require('express');
const cors = require('cors');
const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode');
const path = require('path');
const cron = require('node-cron');
const GoogleDriveBackup = require('./google-drive-backup');

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Estado do WhatsApp
let whatsappClient = null;
let isReady = false;
let qrCodeData = null;
let lastQrUpdate = null;

// Backup Google Drive
const backupService = new GoogleDriveBackup();

// Inicializa o cliente WhatsApp
function initializeWhatsApp() {
    if (whatsappClient) {
        console.log('[WhatsApp] Cliente já existe');
        return;
    }

    console.log('[WhatsApp] Inicializando cliente...');

    whatsappClient = new Client({
        authStrategy: new LocalAuth({
            dataPath: path.join(__dirname, '..', '.wwebjs_auth')
        }),
        puppeteer: {
            headless: true,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--no-first-run',
                '--no-zygote',
                '--single-process',
                '--disable-gpu',
                '--disable-extensions',
                '--disable-software-rasterizer',
                '--disable-background-timer-throttling',
                '--disable-backgrounding-occluded-windows',
                '--disable-renderer-backgrounding'
            ]
        }
    });

    // Evento: QR Code
    whatsappClient.on('qr', async (qr) => {
        console.log('[WhatsApp] QR Code recebido');
        try {
            qrCodeData = await qrcode.toDataURL(qr);
            lastQrUpdate = Date.now();
        } catch (err) {
            console.error('[WhatsApp] Erro ao gerar QR Code:', err);
        }
    });

    // Evento: Autenticado
    whatsappClient.on('authenticated', () => {
        console.log('[WhatsApp] Autenticado');
        qrCodeData = null;
    });

    // Evento: Pronto
    whatsappClient.on('ready', () => {
        console.log('[WhatsApp] Cliente pronto!');
        isReady = true;
        qrCodeData = null;
    });

    // Evento: Desconectado
    whatsappClient.on('disconnected', (reason) => {
        console.log('[WhatsApp] Desconectado:', reason);
        isReady = false;
    });

    // Evento: Erro de autenticação
    whatsappClient.on('auth_failure', (error) => {
        console.error('[WhatsApp] Falha na autenticação:', error);
        qrCodeData = null;
    });

    // Inicializa
    whatsappClient.initialize();
}

// ============================================================================
// API REST - ENDPOINTS MÍNIMOS
// ============================================================================

// Health check
app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Status do WhatsApp
app.get('/api/status', (req, res) => {
    res.json({
        isReady,
        hasQr: !!qrCodeData,
        qrAge: qrCodeData && lastQrUpdate ? Date.now() - lastQrUpdate : null
    });
});

// Obter QR Code
app.get('/api/qr', (req, res) => {
    if (isReady) {
        return res.json({
            success: true,
            connected: true,
            message: 'WhatsApp já está conectado'
        });
    }

    if (!qrCodeData) {
        return res.status(404).json({
            success: false,
            error: 'QR Code não disponível ainda. Aguarde...'
        });
    }

    res.json({
        success: true,
        qr: qrCodeData,
        expiresIn: 60000 // 60 segundos
    });
});

// Enviar mensagem
app.post('/api/send', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({
                success: false,
                error: 'WhatsApp não conectado'
            });
        }

        const { to, message } = req.body;

        if (!to || !message) {
            return res.status(400).json({
                success: false,
                error: 'Campos "to" e "message" obrigatórios'
            });
        }

        const sentMessage = await whatsappClient.sendMessage(to, message);

        res.json({
            success: true,
            messageId: sentMessage.id._serialized,
            timestamp: sentMessage.timestamp
        });
    } catch (error) {
        console.error('[API] Erro ao enviar:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Obter conversas (lista de chats)
app.get('/api/chats', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({
                success: false,
                error: 'WhatsApp não conectado'
            });
        }

        const chats = await whatsappClient.getChats();
        const chatsData = [];

        for (const chat of chats) {
            const lastMessage = chat.lastMessage;

            chatsData.push({
                id: chat.id._serialized,
                name: chat.name,
                isGroup: chat.isGroup,
                unreadCount: chat.unreadCount,
                timestamp: chat.timestamp,
                lastMessage: lastMessage ? {
                    body: lastMessage.body,
                    timestamp: lastMessage.timestamp,
                    fromMe: lastMessage.fromMe
                } : null
            });
        }

        // Ordena por timestamp decrescente
        chatsData.sort((a, b) => b.timestamp - a.timestamp);

        res.json({
            success: true,
            chats: chatsData
        });
    } catch (error) {
        console.error('[API] Erro ao buscar chats:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Obter mensagens de uma conversa
app.get('/api/messages/:chatId', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({
                success: false,
                error: 'WhatsApp não conectado'
            });
        }

        const { chatId } = req.params;
        const limit = parseInt(req.query.limit) || 50;

        const chat = await whatsappClient.getChatById(chatId);
        const messages = await chat.fetchMessages({ limit });

        const messagesData = messages.map(msg => ({
            id: msg.id._serialized,
            body: msg.body,
            timestamp: msg.timestamp,
            fromMe: msg.fromMe,
            type: msg.type,
            hasMedia: msg.hasMedia,
            ack: msg.ack,
            contact: {
                name: msg._data.notifyName || 'Desconhecido',
                number: msg.from
            }
        }));

        res.json({
            success: true,
            messages: messagesData
        });
    } catch (error) {
        console.error('[API] Erro ao buscar mensagens:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Marcar conversa como lida
app.post('/api/read/:chatId', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({
                success: false,
                error: 'WhatsApp não conectado'
            });
        }

        const { chatId } = req.params;
        const chat = await whatsappClient.getChatById(chatId);
        await chat.sendSeen();

        res.json({ success: true });
    } catch (error) {
        console.error('[API] Erro ao marcar como lido:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Logout do WhatsApp
app.post('/api/logout', async (req, res) => {
    try {
        if (!whatsappClient) {
            return res.status(400).json({
                success: false,
                error: 'Cliente não inicializado'
            });
        }

        console.log('[WhatsApp] Fazendo logout...');
        await whatsappClient.logout();
        await whatsappClient.destroy();

        isReady = false;
        qrCodeData = null;
        whatsappClient = null;

        // Reinicializa após 2 segundos
        setTimeout(() => {
            initializeWhatsApp();
        }, 2000);

        res.json({ success: true });
    } catch (error) {
        console.error('[API] Erro no logout:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Endpoint para fazer backup manual
app.post('/api/backup', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({
                success: false,
                error: 'WhatsApp não conectado'
            });
        }

        console.log('[Backup] Iniciando backup manual...');

        const chats = await whatsappClient.getChats();
        const result = await backupService.backupConversations(chats, whatsappClient);

        res.json(result);
    } catch (error) {
        console.error('[API] Erro ao fazer backup:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Endpoint para listar backups
app.get('/api/backups', async (req, res) => {
    try {
        const result = await backupService.listBackups();
        res.json(result);
    } catch (error) {
        console.error('[API] Erro ao listar backups:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ============================================================================
// BACKUP AUTOMÁTICO
// ============================================================================

/**
 * Agenda backup automático diário às 2h da manhã
 */
function scheduleAutomaticBackup() {
    // Executa todos os dias às 2:00 AM
    cron.schedule('0 2 * * *', async () => {
        if (!isReady) {
            console.log('[Backup] WhatsApp não conectado, pulando backup agendado');
            return;
        }

        try {
            console.log('[Backup] Iniciando backup automático agendado...');
            const chats = await whatsappClient.getChats();
            const result = await backupService.backupConversations(chats, whatsappClient);

            if (result.success) {
                console.log('[Backup] Backup automático concluído:', result.fileName);
            } else {
                console.error('[Backup] Erro no backup automático:', result.error);
            }
        } catch (error) {
            console.error('[Backup] Erro no backup automático:', error);
        }
    });

    console.log('[Backup] Backup automático agendado para 2h da manhã (diariamente)');
}

// ============================================================================
// INICIALIZAÇÃO
// ============================================================================

const PORT = process.env.PORT || 8080;

app.listen(PORT, async () => {
    console.log(`[Servidor] Rodando na porta ${PORT}`);
    console.log('[Servidor] API REST ativa - SEM WebSocket');
    console.log('[Servidor] Otimizado para Cloud Run - custo mínimo');

    // Inicializa WhatsApp
    initializeWhatsApp();

    // Inicializa Google Drive Backup
    const backupInitialized = await backupService.initialize();
    if (backupInitialized) {
        scheduleAutomaticBackup();
        console.log('[Backup] Sistema de backup do Google Drive ativo');
    } else {
        console.log('[Backup] Sistema de backup do Google Drive DESABILITADO');
        console.log('[Backup] Execute server/google-drive-auth.js para configurar');
    }
});

// Tratamento de erros
process.on('unhandledRejection', (error) => {
    console.error('[Erro]:', error);
});

process.on('SIGINT', async () => {
    console.log('\n[Servidor] Encerrando...');
    if (whatsappClient) {
        await whatsappClient.destroy();
    }
    process.exit(0);
});
