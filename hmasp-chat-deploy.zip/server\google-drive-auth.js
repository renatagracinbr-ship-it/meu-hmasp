/**
 * Script de Autenticação do Google Drive
 * Execute este script UMA VEZ para gerar o token de acesso
 *
 * Uso: node server/google-drive-auth.js
 */

const { google } = require('googleapis');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

const SCOPES = ['https://www.googleapis.com/auth/drive.file'];
const TOKEN_PATH = path.join(__dirname, '..', 'google-token.json');
const CREDENTIALS_PATH = path.join(__dirname, '..', 'google-credentials.json');

/**
 * Cria um novo token OAuth2
 */
async function authorize() {
    try {
        // Lê credenciais
        if (!fs.existsSync(CREDENTIALS_PATH)) {
            console.error('❌ Arquivo google-credentials.json não encontrado!');
            console.log('\n📋 INSTRUÇÕES PARA CONFIGURAR O GOOGLE DRIVE:');
            console.log('1. Acesse: https://console.cloud.google.com/');
            console.log('2. Crie um novo projeto (ou use existente)');
            console.log('3. Ative a "Google Drive API"');
            console.log('4. Vá em "Credenciais" > "Criar credenciais" > "ID do cliente OAuth"');
            console.log('5. Tipo de aplicativo: "Aplicativo para computador"');
            console.log('6. Baixe o arquivo JSON');
            console.log('7. Renomeie para "google-credentials.json"');
            console.log('8. Coloque na raiz do projeto');
            console.log('9. Execute este script novamente\n');
            process.exit(1);
        }

        const credentials = JSON.parse(fs.readFileSync(CREDENTIALS_PATH, 'utf8'));
        const { client_secret, client_id, redirect_uris } = credentials.installed || credentials.web;

        const oAuth2Client = new google.auth.OAuth2(
            client_id,
            client_secret,
            redirect_uris[0]
        );

        // Gera URL de autorização
        const authUrl = oAuth2Client.generateAuthUrl({
            access_type: 'offline',
            scope: SCOPES,
        });

        console.log('🔐 AUTENTICAÇÃO DO GOOGLE DRIVE\n');
        console.log('📱 Abra este link no navegador:');
        console.log('\n' + authUrl + '\n');
        console.log('👤 Faça login com: centralderegulacaohmasp@gmail.com');
        console.log('✅ Autorize o acesso ao Google Drive');
        console.log('\n💡 Cole o código de autorização aqui:');

        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout,
        });

        rl.question('Código: ', async (code) => {
            rl.close();

            try {
                const { tokens } = await oAuth2Client.getToken(code);
                oAuth2Client.setCredentials(tokens);

                // Salva o token
                fs.writeFileSync(TOKEN_PATH, JSON.stringify(tokens, null, 2));

                console.log('\n✅ Token salvo com sucesso em:', TOKEN_PATH);
                console.log('🎉 Autenticação concluída!');
                console.log('📦 O backup automático está configurado!\n');

                process.exit(0);
            } catch (error) {
                console.error('❌ Erro ao obter token:', error);
                process.exit(1);
            }
        });
    } catch (error) {
        console.error('❌ Erro:', error);
        process.exit(1);
    }
}

// Executa
authorize();
