# 🚀 Instalação HMASP Chat - Ubuntu (VM Proxmox)

## 📋 Pré-requisitos

- Ubuntu 20.04 LTS ou superior
- Acesso root ou sudo
- Conexão com a internet (para instalação inicial)
- Acesso ao Proxmox via navegador Firefox

---

## 📦 Passo 1: Preparação do Arquivo ZIP

### No Windows (seu computador local):

1. **Criar o ZIP do projeto completo:**
   - Compacte a pasta inteira do projeto em um arquivo ZIP
   - Certifique-se de incluir:
     - ✅ Pasta `dist/` (build do frontend)
     - ✅ Arquivo `server.js` (servidor backend)
     - ✅ Arquivo `package.json` (dependências)
     - ✅ Pasta `server/` (servidores auxiliares)
     - ✅ Arquivo `.env` (configurações)
     - ✅ **NÃO incluir** `node_modules/` (muito pesado)

2. **Nome sugerido:** `hmasp-chat-deploy.zip`

---

## 🌐 Passo 2: Upload do ZIP para a VM Ubuntu

### Pelo Firefox na VM (via Proxmox):

1. Acesse a VM pelo Proxmox
2. Abra o Firefox
3. Faça o upload do arquivo `hmasp-chat-deploy.zip` para a VM
   - Você pode usar um serviço de transferência temporário
   - Ou compartilhar via rede local
   - Ou baixar de um repositório Git

4. **Salve o arquivo em:** `/home/seu-usuario/hmasp-chat-deploy.zip`

---

## ⚙️ Passo 3: Instalação do Node.js no Ubuntu

### Opção A: Instalação via NodeSource (Recomendado - Node 20 LTS)

```bash
# Atualizar repositórios
sudo apt update

# Instalar curl (se não tiver)
sudo apt install -y curl

# Adicionar repositório NodeSource para Node.js 20.x
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -

# Instalar Node.js e npm
sudo apt install -y nodejs

# Verificar instalação
node --version  # Deve mostrar v20.x.x
npm --version   # Deve mostrar 10.x.x
```

### Opção B: Instalação via APT (Node.js padrão do Ubuntu)

```bash
sudo apt update
sudo apt install -y nodejs npm
node --version
npm --version
```

---

## 📁 Passo 4: Extração e Preparação do Projeto

```bash
# Navegar para o diretório home
cd ~

# Criar diretório para o app (se não existir)
mkdir -p hmasp-chat

# Extrair o ZIP
unzip hmasp-chat-deploy.zip -d hmasp-chat/

# Entrar no diretório
cd hmasp-chat

# Verificar estrutura de arquivos
ls -la

# Você deve ver:
# - dist/
# - server.js
# - package.json
# - .env
# - server/
```

---

## 📦 Passo 5: Instalação de Dependências

```bash
# Dentro do diretório hmasp-chat

# Instalar todas as dependências do Node.js
npm install

# IMPORTANTE: Este processo pode levar alguns minutos
# O npm vai baixar e instalar:
# - whatsapp-web.js
# - express
# - pg (PostgreSQL client)
# - qrcode
# - cors
# - e outras dependências

# Aguarde até ver a mensagem:
# "added XXX packages"
```

---

## 🔧 Passo 6: Configuração do Ambiente

### Editar o arquivo .env

```bash
# Abrir com nano (editor de texto)
nano .env
```

**Configurações importantes:**

```bash
# Porta do servidor (mantenha 3000 ou mude se necessário)
PORT=3000

# Ambiente de produção
NODE_ENV=production

# URLs - AJUSTE CONFORME O IP DA VM
FRONTEND_URL=http://SEU_IP_DA_VM:3000
BACKEND_URL=http://SEU_IP_DA_VM:3000
```

**Salvar:** `Ctrl + O`, `Enter`, `Ctrl + X`

---

## 🗄️ Passo 7: Configuração do PostgreSQL (AGHUse)

### Se você já tem PostgreSQL instalado no Ubuntu:

```bash
# Verificar se PostgreSQL está instalado
psql --version

# Se não estiver instalado:
sudo apt install -y postgresql postgresql-contrib

# Iniciar serviço PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

### Criar banco de dados para logs (OPCIONAL)

```bash
# Acessar PostgreSQL como usuário postgres
sudo -u postgres psql

# Criar banco de dados
CREATE DATABASE hmasp_chat_logs;

# Criar usuário
CREATE USER hmasp_user WITH PASSWORD 'SuaSenhaSegura123';

# Dar permissões
GRANT ALL PRIVILEGES ON DATABASE hmasp_chat_logs TO hmasp_user;

# Sair
\q
```

---

## 🚀 Passo 8: Iniciar o Servidor

### Teste Inicial (modo desenvolvimento)

```bash
# Dentro do diretório hmasp-chat
node server.js
```

**Você deve ver:**
```
[Server] Servidor rodando na porta 3000
[Server] Frontend disponível em: http://SEU_IP:3000
[WhatsApp] Inicializando cliente WhatsApp...
[WhatsApp] QR Code gerado!
```

### Teste no Navegador

1. Abra o Firefox na VM
2. Acesse: `http://localhost:3000`
3. **Você deve ver a interface do HMASP Chat**
4. Escaneie o QR Code com seu WhatsApp

**Se funcionar:** `Ctrl + C` para parar o servidor

---

## 🔄 Passo 9: Configurar Serviço Systemd (Rodar em Background)

### Criar arquivo de serviço

```bash
# Criar arquivo de serviço
sudo nano /etc/systemd/system/hmasp-chat.service
```

**Conteúdo do arquivo:**

```ini
[Unit]
Description=HMASP Chat - Central de Marcação de Consultas
After=network.target postgresql.service

[Service]
Type=simple
User=seu-usuario
WorkingDirectory=/home/seu-usuario/hmasp-chat
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=hmasp-chat
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

**IMPORTANTE:** Substitua `seu-usuario` pelo seu nome de usuário do Ubuntu!

**Salvar:** `Ctrl + O`, `Enter`, `Ctrl + X`

### Ativar e iniciar o serviço

```bash
# Recarregar systemd
sudo systemctl daemon-reload

# Habilitar serviço (inicia automaticamente no boot)
sudo systemctl enable hmasp-chat

# Iniciar serviço
sudo systemctl start hmasp-chat

# Verificar status
sudo systemctl status hmasp-chat

# Você deve ver "active (running)" em verde
```

### Comandos úteis do serviço

```bash
# Parar serviço
sudo systemctl stop hmasp-chat

# Reiniciar serviço
sudo systemctl restart hmasp-chat

# Ver logs em tempo real
sudo journalctl -u hmasp-chat -f

# Ver últimas 100 linhas de log
sudo journalctl -u hmasp-chat -n 100
```

---

## 🔥 Passo 10: Configurar Firewall (UFW)

```bash
# Verificar status do firewall
sudo ufw status

# Se desabilitado, habilitar
sudo ufw enable

# Permitir porta 3000 (HMASP Chat)
sudo ufw allow 3000/tcp

# Permitir SSH (IMPORTANTE - não se tranque fora!)
sudo ufw allow 22/tcp

# Recarregar firewall
sudo ufw reload

# Verificar regras
sudo ufw status verbose
```

---

## 🌐 Passo 11: Acessar de Outros Computadores na Rede

### Descobrir IP da VM

```bash
# Ver IP da VM
ip addr show

# Ou
hostname -I
```

### Acessar de outro computador na rede interna

1. Abra o navegador
2. Digite: `http://IP_DA_VM:3000`
3. Exemplo: `http://192.168.1.100:3000`

---

## ✅ Verificações Finais

### Checklist de Funcionamento

- [ ] Servidor Node.js está rodando (`sudo systemctl status hmasp-chat`)
- [ ] Página carrega no navegador (`http://IP_DA_VM:3000`)
- [ ] App entra direto sem pedir login
- [ ] Indica "Administrador (Acesso Direto)" no topo
- [ ] WhatsApp conecta (QR Code ou já autenticado)
- [ ] Aba "Confirmação de Presença" funciona
- [ ] Aba "Desmarcação de Consultas" funciona
- [ ] Toggle de envio automático funciona
- [ ] Conexão com AGHUse funciona (se configurado)

### Teste de Conectividade AGHUse

1. Abra o Console do navegador (F12)
2. Vá na aba "Confirmação de Presença"
3. Observe os logs:
   - `[AGHUse] ✅ Conectado` = OK
   - `[AGHUse] 🔴 Erro` = Problema de conexão

---

## 🐛 Troubleshooting (Resolução de Problemas)

### Problema: "Cannot find module 'whatsapp-web.js'"

**Solução:**
```bash
cd ~/hmasp-chat
npm install
```

### Problema: "Port 3000 already in use"

**Solução:**
```bash
# Ver o que está usando a porta 3000
sudo lsof -i :3000

# Matar processo (substitua PID pelo número mostrado)
sudo kill -9 PID

# Ou mudar a porta no .env
nano .env
# Mude PORT=3000 para PORT=3001
```

### Problema: "Permission denied" ao criar arquivos

**Solução:**
```bash
# Dar permissões ao usuário
sudo chown -R seu-usuario:seu-usuario ~/hmasp-chat

# Criar pasta de sessão do WhatsApp
mkdir -p ~/hmasp-chat/server/.wwebjs_auth
chmod 755 ~/hmasp-chat/server/.wwebjs_auth
```

### Problema: WhatsApp não conecta

**Solução:**
```bash
# Limpar sessão do WhatsApp
cd ~/hmasp-chat
rm -rf server/.wwebjs_auth

# Reiniciar serviço
sudo systemctl restart hmasp-chat

# Acessar app e escanear QR Code novamente
```

### Problema: AGHUse não conecta

**Verificações:**
1. PostgreSQL está rodando? `sudo systemctl status postgresql`
2. Configurações de IP/porta estão corretas?
3. Firewall do servidor PostgreSQL permite conexões?
4. Credenciais estão corretas?

**Testar conexão:**
```bash
# Testar conexão PostgreSQL
psql -h IP_DO_AGHUSE -p 5432 -U usuario_aghuse -d nome_banco
```

---

## 📊 Monitoramento e Logs

### Ver logs do servidor

```bash
# Logs em tempo real
sudo journalctl -u hmasp-chat -f

# Últimas 50 linhas
sudo journalctl -u hmasp-chat -n 50

# Logs de hoje
sudo journalctl -u hmasp-chat --since today

# Logs de erros apenas
sudo journalctl -u hmasp-chat -p err
```

### Monitorar uso de recursos

```bash
# CPU e memória
top

# Ou usar htop (mais amigável)
sudo apt install htop
htop

# Ver processos Node.js
ps aux | grep node
```

---

## 🔄 Atualização do Sistema

### Quando houver nova versão do app

```bash
# 1. Parar serviço
sudo systemctl stop hmasp-chat

# 2. Backup da versão atual
cd ~
cp -r hmasp-chat hmasp-chat-backup-$(date +%Y%m%d)

# 3. Extrair nova versão
unzip hmasp-chat-deploy-NOVO.zip -d hmasp-chat-temp/
cp -r hmasp-chat-temp/* hmasp-chat/

# 4. Reinstalar dependências (se package.json mudou)
cd hmasp-chat
npm install

# 5. Reiniciar serviço
sudo systemctl start hmasp-chat

# 6. Verificar se está funcionando
sudo systemctl status hmasp-chat
```

---

## 📞 Suporte

### Informações de Contato

- **Sistema:** HMASP Chat v1.0.0
- **Desenvolvido para:** Central de Regulação HMASP
- **Data:** Dezembro 2024

### Arquivos Importantes

- **Servidor Principal:** `server.js`
- **Configurações:** `.env`
- **Frontend:** `dist/`
- **Logs do Sistema:** `/var/log/syslog` ou `journalctl`
- **Sessão WhatsApp:** `server/.wwebjs_auth/`

---

## ⚠️ Observações Importantes

1. **Backup Regular:**
   - Faça backup da pasta `server/.wwebjs_auth/` (sessão do WhatsApp)
   - Faça backup do banco de dados PostgreSQL
   - Faça backup do arquivo `.env`

2. **Segurança:**
   - O sistema NÃO tem autenticação (acesso direto)
   - Qualquer pessoa na rede pode acessar
   - Use firewall para restringir acesso apenas à rede interna do HMASP

3. **Performance:**
   - Recomendado: Mínimo 2GB RAM
   - Recomendado: 2 vCPUs
   - Espaço em disco: Mínimo 10GB

4. **Sessão WhatsApp:**
   - A sessão fica salva em `server/.wwebjs_auth/`
   - Se deletar esta pasta, terá que escanear QR Code novamente
   - Não compartilhe esta pasta (contém dados de autenticação)

---

## ✅ Conclusão

Após seguir todos os passos, o HMASP Chat estará:

- ✅ Instalado no Ubuntu
- ✅ Rodando como serviço em background
- ✅ Iniciando automaticamente no boot
- ✅ Acessível pela rede interna
- ✅ Conectado ao WhatsApp
- ✅ Pronto para uso pela Central de Regulação

**Acesso:** `http://IP_DA_VM:3000`

**Primeira vez:** O app abre direto como Administrador, sem necessidade de login.

---

**🎉 Instalação Concluída!**
