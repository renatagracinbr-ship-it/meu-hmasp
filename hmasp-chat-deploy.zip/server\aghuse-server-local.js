/**
 * Servidor Local AGHUse - Backend
 *
 * EXECUÇÃO:
 * node server/aghuse-server-local.js
 *
 * PORTA: 3001
 * ACESSO: Apenas via intranet do hospital ou VPN
 * FUNÇÃO: Integração com PostgreSQL AGHUse
 */

const express = require('express');
const cors = require('cors');
const aghuseServer = require('./aghuse-server');

const app = express();
const PORT = 3001;

// Middlewares
app.use(cors());
app.use(express.json());

// ============================================================================
// ROTAS DA API - AGHUse
// ============================================================================

/**
 * Testa conexão com AGHUse
 */
app.get('/api/aghuse/test-connection', async (req, res) => {
    try {
        const result = await aghuseServer.testConnection();
        res.json(result);
    } catch (error) {
        console.error('[API AGHUse] Erro ao testar conexão:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

/**
 * Busca consultas marcadas recentemente
 */
app.get('/api/aghuse/recent-appointments', async (req, res) => {
    try {
        const minutes = parseInt(req.query.minutes) || 5;
        const appointments = await aghuseServer.fetchRecentlyScheduledAppointments(minutes);
        res.json({ success: true, appointments });
    } catch (error) {
        console.error('[API AGHUse] Erro ao buscar consultas:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

/**
 * Busca consultas desmarcadas recentemente
 */
app.get('/api/aghuse/cancelled-appointments', async (req, res) => {
    try {
        const minutes = parseInt(req.query.minutes) || 60;
        const appointments = await aghuseServer.fetchRecentlyCancelledAppointments(minutes);
        res.json({ success: true, appointments });
    } catch (error) {
        console.error('[API AGHUse] Erro ao buscar consultas desmarcadas:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

/**
 * Busca consultas que acontecerão em 72 horas (para lembrete)
 */
app.get('/api/aghuse/appointments-72h', async (req, res) => {
    try {
        const appointments = await aghuseServer.fetchAppointmentsIn72Hours();
        res.json({ success: true, appointments });
    } catch (error) {
        console.error('[API AGHUse] Erro ao buscar consultas 72h:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

/**
 * Health check
 */
app.get('/health', (req, res) => {
    res.json({
        status: 'ok',
        service: 'AGHUse Backend',
        timestamp: new Date().toISOString()
    });
});

// Página inicial
app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>HMASP - AGHUse Backend</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    max-width: 800px;
                    margin: 50px auto;
                    padding: 20px;
                    background: #f5f5f5;
                }
                .container {
                    background: white;
                    padding: 30px;
                    border-radius: 10px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                }
                h1 {
                    color: #333;
                    border-bottom: 3px solid #4CAF50;
                    padding-bottom: 10px;
                }
                .endpoint {
                    background: #f9f9f9;
                    padding: 15px;
                    margin: 10px 0;
                    border-left: 4px solid #4CAF50;
                    border-radius: 3px;
                }
                .endpoint code {
                    color: #d63031;
                    background: #fff;
                    padding: 2px 6px;
                    border-radius: 3px;
                }
                .status {
                    display: inline-block;
                    padding: 5px 15px;
                    background: #4CAF50;
                    color: white;
                    border-radius: 20px;
                    font-weight: bold;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>🏥 HMASP - AGHUse Backend</h1>
                <p><span class="status">✓ ONLINE</span></p>

                <h2>📋 Endpoints Disponíveis:</h2>

                <div class="endpoint">
                    <strong>GET</strong> <code>/api/aghuse/test-connection</code>
                    <p>Testa conexão com banco AGHUse</p>
                </div>

                <div class="endpoint">
                    <strong>GET</strong> <code>/api/aghuse/recent-appointments?minutes=5</code>
                    <p>Busca consultas marcadas nos últimos X minutos</p>
                </div>

                <div class="endpoint">
                    <strong>GET</strong> <code>/api/aghuse/cancelled-appointments?minutes=60</code>
                    <p>Busca consultas desmarcadas nos últimos X minutos</p>
                </div>

                <div class="endpoint">
                    <strong>GET</strong> <code>/health</code>
                    <p>Health check do serviço</p>
                </div>

                <h2>⚙️ Configuração:</h2>
                <ul>
                    <li><strong>Porta:</strong> ${PORT}</li>
                    <li><strong>Banco:</strong> PostgreSQL (10.12.40.219:5432)</li>
                    <li><strong>Acesso:</strong> Apenas intranet/VPN</li>
                </ul>
            </div>
        </body>
        </html>
    `);
});

// ============================================================================
// INICIALIZAÇÃO
// ============================================================================

app.listen(PORT, () => {
    console.log('============================================');
    console.log('  HMASP - AGHUse Backend Local');
    console.log('============================================');
    console.log(`✓ Servidor rodando em: http://localhost:${PORT}`);
    console.log('✓ Acesso: Apenas via intranet ou VPN');
    console.log('');
    console.log('✓ Endpoints:');
    console.log(`  - GET  /api/aghuse/test-connection`);
    console.log(`  - GET  /api/aghuse/recent-appointments`);
    console.log(`  - GET  /api/aghuse/cancelled-appointments`);
    console.log(`  - GET  /health`);
    console.log('============================================');
    console.log('');
});

// Tratamento de erros
process.on('uncaughtException', (error) => {
    console.error('[ERRO] Exceção não capturada:', error);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('[ERRO] Promise rejeitada:', reason);
});
