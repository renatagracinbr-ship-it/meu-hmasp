/**
 * Servidor WhatsApp para Google Compute Engine
 * Versão simples e funcional - SEM Google Contacts
 */

const express = require('express');
const cors = require('cors');
const { Client, LocalAuth } = require('whatsapp-web.js');
const WwebjsSender = require('@deathabyss/wwebjs-sender');
const qrcode = require('qrcode');
const path = require('path');
const auth = require('./server/auth');
const aghuse = require('./server/aghuse-server');

const app = express();
const PORT = 3000;

// Middlewares
app.use(cors());
app.use(express.json());

// Servir frontend estático PRIMEIRO (antes de todas as rotas)
app.use(express.static(path.join(__dirname, 'dist')));

// Estado do WhatsApp
let whatsappClient = null;
let isReady = false;
let qrCodeData = null;
let heartbeatInterval = null;

// Heartbeat para manter conexão ativa
function startHeartbeat() {
    if (heartbeatInterval) return; // Já está rodando

    console.log('[WhatsApp] 💓 Iniciando heartbeat (a cada 30s)');
    heartbeatInterval = setInterval(async () => {
        if (!isReady || !whatsappClient) return;

        try {
            // Verifica se o cliente está realmente conectado
            const state = await whatsappClient.getState();
            if (state !== 'CONNECTED') {
                console.log('[WhatsApp] ⚠️ Estado não conectado:', state);
                isReady = false;
            } else {
                console.log('[WhatsApp] 💓 Heartbeat OK');
            }
        } catch (error) {
            console.error('[WhatsApp] ❌ Erro no heartbeat:', error.message);
            isReady = false;
        }
    }, 30000); // A cada 30 segundos
}

function stopHeartbeat() {
    if (heartbeatInterval) {
        console.log('[WhatsApp] Parando heartbeat');
        clearInterval(heartbeatInterval);
        heartbeatInterval = null;
    }
}

// ============================================================================
// AUTENTICAÇÃO - ENDPOINTS
// ============================================================================

// Verifica auto-login (VM)
app.get('/api/auth/auto-login', async (req, res) => {
    try {
        const user = await auth.checkAutoLogin();
        if (user) {
            const token = await auth.createSession(user.username, user.role);
            console.log('[Auth] Auto-login realizado:', user.username);
            res.json({ success: true, user, token });
        } else {
            res.json({ success: false });
        }
    } catch (error) {
        console.error('[Auth] Erro no auto-login:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Login normal
app.post('/api/auth/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ success: false, error: 'Usuário e senha são obrigatórios' });
        }

        const user = await auth.authenticateUser(username, password);
        if (!user) {
            return res.status(401).json({ success: false, error: 'Usuário ou senha inválidos' });
        }

        const token = await auth.createSession(user.username, user.role);
        console.log('[Auth] Login realizado:', user.username);

        res.json({ success: true, user, token });
    } catch (error) {
        console.error('[Auth] Erro no login:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Solicitar acesso (para novos usuários)
app.post('/api/auth/request-access', async (req, res) => {
    try {
        const { username, password, name, requestedRole, deviceInfo } = req.body;

        if (!username || !password || !name) {
            return res.status(400).json({
                success: false,
                error: 'Usuário, senha e nome são obrigatórios'
            });
        }

        const result = await auth.requestAccess(username, password, name, requestedRole, deviceInfo);
        res.json(result);
    } catch (error) {
        console.error('[Auth] Erro ao solicitar acesso:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Validar sessão
app.get('/api/auth/session', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        if (!token) {
            return res.status(401).json({ success: false, error: 'Token não fornecido' });
        }

        const session = await auth.validateSession(token);
        if (!session) {
            return res.status(401).json({ success: false, error: 'Sessão inválida ou expirada' });
        }

        res.json({ success: true, session });
    } catch (error) {
        console.error('[Auth] Erro ao validar sessão:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Logout
app.post('/api/auth/logout', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        if (token) {
            await auth.deleteSession(token);
        }
        res.json({ success: true });
    } catch (error) {
        console.error('[Auth] Erro no logout:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Listar usuários (apenas admin)
app.get('/api/auth/users', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        const session = await auth.validateSession(token);

        if (!session || session.role !== 'admin') {
            return res.status(403).json({ success: false, error: 'Acesso negado' });
        }

        const users = await auth.getUsers();
        res.json({ success: true, users });
    } catch (error) {
        console.error('[Auth] Erro ao listar usuários:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Listar pedidos pendentes (apenas admin)
app.get('/api/auth/pending', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        const session = await auth.validateSession(token);

        if (!session || session.role !== 'admin') {
            return res.status(403).json({ success: false, error: 'Acesso negado' });
        }

        const pending = await auth.getPendingApprovals();
        res.json({ success: true, pending });
    } catch (error) {
        console.error('[Auth] Erro ao listar pendentes:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Aprovar usuário (apenas admin)
app.post('/api/auth/approve/:requestId', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        const session = await auth.validateSession(token);

        if (!session || session.role !== 'admin') {
            return res.status(403).json({ success: false, error: 'Acesso negado' });
        }

        const { requestId } = req.params;
        const result = await auth.approveUser(requestId, session.username);
        res.json(result);
    } catch (error) {
        console.error('[Auth] Erro ao aprovar usuário:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Rejeitar usuário (apenas admin)
app.post('/api/auth/reject/:requestId', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        const session = await auth.validateSession(token);

        if (!session || session.role !== 'admin') {
            return res.status(403).json({ success: false, error: 'Acesso negado' });
        }

        const { requestId } = req.params;
        const result = await auth.rejectUser(requestId);
        res.json(result);
    } catch (error) {
        console.error('[Auth] Erro ao rejeitar usuário:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Atualizar status de usuário (apenas admin)
app.patch('/api/auth/users/:userId/status', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        const session = await auth.validateSession(token);

        if (!session || session.role !== 'admin') {
            return res.status(403).json({ success: false, error: 'Acesso negado' });
        }

        const { userId } = req.params;
        const { status } = req.body;

        const result = await auth.updateUserStatus(userId, status);
        res.json(result);
    } catch (error) {
        console.error('[Auth] Erro ao atualizar status:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Criar novo usuário (apenas admin)
app.post('/api/auth/users', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        const session = await auth.validateSession(token);

        if (!session || session.role !== 'admin') {
            return res.status(403).json({ success: false, error: 'Acesso negado' });
        }

        const { username, password, name, role } = req.body;

        if (!username || !password || !name || !role) {
            return res.status(400).json({
                success: false,
                error: 'Todos os campos são obrigatórios: username, password, name, role'
            });
        }

        const result = await auth.createUser(username, password, name, role);
        res.json(result);
    } catch (error) {
        console.error('[Auth] Erro ao criar usuário:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Atualizar perfil de usuário (apenas admin)
app.patch('/api/auth/users/:userId/role', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        const session = await auth.validateSession(token);

        if (!session || session.role !== 'admin') {
            return res.status(403).json({ success: false, error: 'Acesso negado' });
        }

        const { userId } = req.params;
        const { role } = req.body;

        if (!role) {
            return res.status(400).json({ success: false, error: 'Perfil é obrigatório' });
        }

        const result = await auth.updateUserRole(userId, role);
        res.json(result);
    } catch (error) {
        console.error('[Auth] Erro ao atualizar perfil:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============================================================================
// WHATSAPP - INICIALIZAÇÃO
// ============================================================================

function initializeWhatsApp() {
    if (whatsappClient) {
        console.log('[WhatsApp] Cliente já existe');
        return;
    }

    console.log('[WhatsApp] Inicializando...');

    whatsappClient = new Client({
        authStrategy: new LocalAuth({
            dataPath: path.join(__dirname, '.wwebjs_auth')
        }),
        puppeteer: {
            headless: true,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-gpu',
                '--disable-software-rasterizer',
                '--disable-dev-tools',
                '--no-first-run',
                '--disable-extensions',
                '--disable-backgrounding-occluded-windows',
                '--disable-renderer-backgrounding',
                '--disable-background-timer-throttling',
                '--disable-ipc-flooding-protection',
                '--disable-hang-monitor'
            ],
            timeout: 60000
        }
    });

    // Evento: QR Code
    whatsappClient.on('qr', async (qr) => {
        console.log('[WhatsApp] QR Code gerado');
        try {
            qrCodeData = await qrcode.toDataURL(qr);
        } catch (err) {
            console.error('[WhatsApp] Erro ao gerar QR Code:', err);
        }
    });

    // Evento: Autenticado
    whatsappClient.on('authenticated', () => {
        console.log('[WhatsApp] Autenticado!');
        qrCodeData = null;
    });

    // Evento: Pronto
    whatsappClient.on('ready', () => {
        console.log('[WhatsApp] Pronto!');
        isReady = true;
        qrCodeData = null;

        // Inicia heartbeat para manter conexão ativa
        startHeartbeat();
    });

    // Evento: Desconectado
    whatsappClient.on('disconnected', (reason) => {
        console.log('[WhatsApp] ⚠️ Desconectado:', reason);
        isReady = false;
        stopHeartbeat();

        // Tenta reconectar após 5 segundos
        setTimeout(() => {
            console.log('[WhatsApp] Tentando reconectar...');
            whatsappClient.initialize();
        }, 5000);
    });

    // Evento: Auth failure
    whatsappClient.on('auth_failure', (msg) => {
        console.error('[WhatsApp] ❌ Falha na autenticação:', msg);
        isReady = false;
    });

    // Evento: Mensagem recebida (para processar respostas)
    whatsappClient.on('message', async (msg) => {
        try {
            // Ignora mensagens enviadas por nós
            if (msg.fromMe) return;

            const body = msg.body.trim().toLowerCase();
            const phoneNumber = msg.from;

            console.log('[WhatsApp] Mensagem recebida de', phoneNumber, ':', body);

            // Detecta contexto da última mensagem enviada para esse chat
            const contexto = global.chatContextos?.[phoneNumber];

            // Detecta resposta numérica
            let respostaDetectada = null;
            let tipoDesmarcacao = null; // Para desmarcações: reagendamento, sem_reagendamento, paciente_solicitou

            // CONFIRMAÇÃO DE PRESENÇA (padrão atual)
            if (body === '1' || body.includes('confirmo') || body.includes('sim') || body.includes('✅')) {
                respostaDetectada = 'confirmed';
            } else if (body === '2' || body.includes('não') || body.includes('nao') || body.includes('❌')) {
                // Se o contexto for desmarcação, resposta 2 = paciente_solicitou (nova ordem)
                if (contexto === 'desmarcacao') {
                    tipoDesmarcacao = 'paciente_solicitou';
                } else {
                    respostaDetectada = 'declined';
                }
            } else if (body === '3' || body.includes('não agendei') || body.includes('nao agendei')) {
                // Se o contexto for desmarcação, resposta 3 = sem_reagendamento (nova ordem)
                if (contexto === 'desmarcacao') {
                    tipoDesmarcacao = 'sem_reagendamento';
                } else {
                    respostaDetectada = 'not_scheduled';
                }
            }

            // Se contexto for desmarcação e resposta for 1, mapeia para reagendamento
            if (contexto === 'desmarcacao' && body === '1') {
                tipoDesmarcacao = 'reagendamento';
                respostaDetectada = null;
            }

            if (respostaDetectada || tipoDesmarcacao) {
                console.log('[WhatsApp] Resposta detectada:', tipoDesmarcacao || respostaDetectada, 'de', phoneNumber);

                // Salva resposta em memória global
                if (!global.whatsappResponses) {
                    global.whatsappResponses = [];
                }
                global.whatsappResponses.push({
                    telefone: phoneNumber,
                    status: respostaDetectada,
                    tipoDesmarcacao: tipoDesmarcacao,
                    contexto: contexto,
                    messageBody: msg.body,
                    timestamp: new Date().toISOString()
                });

                // Simula digitação humana: mostra "digitando..." e espera alguns segundos
                const chat = await msg.getChat();
                await chat.sendStateTyping();

                // Delay aleatório entre 3-6 segundos para parecer humano
                const delaySeconds = 3 + Math.random() * 3;
                await new Promise(resolve => setTimeout(resolve, delaySeconds * 1000));

                // RESPOSTAS PARA DESMARCAÇÃO
                if (tipoDesmarcacao === 'reagendamento') {
                    await msg.reply('✅ *Agradecemos o retorno!*\n\nSua consulta será reagendada e você será informado assim que tivermos uma nova data disponível. Contamos com a sua compreensão.\n\n_HMASP - Central de Marcação de Consultas_');
                } else if (tipoDesmarcacao === 'sem_reagendamento') {
                    await msg.reply('✅ *Agradecemos pela informação!*\n\nCaso precise de um novo agendamento no futuro, estamos à disposição através dos nossos canais de atendimento. Desejamos saúde e bem-estar.\n\n_HMASP - Central de Marcação de Consultas_');
                } else if (tipoDesmarcacao === 'paciente_solicitou') {
                    await msg.reply('✅ *Agradecemos o retorno!*\n\nCompreendemos sua solicitação. Ficamos à disposição caso precise reagendar. Desejamos saúde e bem-estar.\n\n_HMASP - Central de Marcação de Consultas_');
                }
                // RESPOSTAS PARA CONFIRMAÇÃO DE PRESENÇA
                else if (respostaDetectada === 'confirmed') {
                    await msg.reply('✅ *Presença confirmada!* Obrigado. Aguardamos você na data e horário marcados.\n\n_HMASP - Central de Marcação de Consultas_');
                } else if (respostaDetectada === 'declined') {
                    await msg.reply('❌ *Entendido.* Sua consulta foi desmarcada. Em caso de dúvidas, entre em contato com a Central de Marcação de Consultas.\n\n_HMASP - Central de Marcação de Consultas_');
                } else if (respostaDetectada === 'not_scheduled') {
                    await msg.reply('⚠️ *Obrigado pelo retorno.* Verificaremos o agendamento. Se necessário, entraremos em contato.\n\n_HMASP - Central de Marcação de Consultas_');
                }

                // Limpa contexto após processar resposta
                if (global.chatContextos && global.chatContextos[phoneNumber]) {
                    delete global.chatContextos[phoneNumber];
                }
            }
        } catch (error) {
            console.error('[WhatsApp] Erro ao processar mensagem:', error);
        }
    });

    // Evento: Desconectado
    whatsappClient.on('disconnected', (reason) => {
        console.log('[WhatsApp] Desconectado:', reason);
        isReady = false;
        whatsappClient = null;
        setTimeout(initializeWhatsApp, 5000);
    });

    // Evento: Erro de autenticação
    whatsappClient.on('auth_failure', (error) => {
        console.error('[WhatsApp] Falha na autenticação:', error);
        qrCodeData = null;
    });

    // Inicializa
    whatsappClient.initialize();
}

// ============================================================================
// API REST - ENDPOINTS
// ============================================================================

// Status do WhatsApp
app.get('/api/status', (req, res) => {
    res.json({
        isReady: isReady,
        hasQr: qrCodeData !== null,
        timestamp: new Date().toISOString()
    });
});

// Endpoint para frontend consultar respostas do WhatsApp
app.get('/api/responses', (req, res) => {
    try {
        const responses = global.whatsappResponses || [];
        res.json({ success: true, responses: responses });

        // Limpa as respostas após enviar (para não reprocessar)
        global.whatsappResponses = [];
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// QR Code para autenticação
app.get('/api/qr', (req, res) => {
    if (qrCodeData) {
        res.json({ qr: qrCodeData });
    } else if (isReady) {
        res.json({ qr: null, message: 'Já autenticado' });
    } else {
        res.json({ qr: null, message: 'Aguardando QR Code...' });
    }
});

// Listar conversas - TODOS OS DADOS
app.get('/api/chats', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({ success: false, error: 'WhatsApp não está conectado' });
        }

        const chats = await whatsappClient.getChats();

        // Retorna TODOS os dados disponíveis do chat
        const chatList = await Promise.all(chats.map(async (chat) => {
            // Serializa o objeto chat completo
            const chatData = JSON.parse(JSON.stringify(chat));

            // Adiciona dados extras do contato se for chat individual
            if (!chat.isGroup) {
                try {
                    const contact = await whatsappClient.getContactById(chat.id._serialized);
                    chatData.contactDetails = JSON.parse(JSON.stringify(contact));
                } catch (err) {
                    console.error('[API] Erro ao buscar contato:', err.message);
                }
            }

            return chatData;
        }));

        res.json({ success: true, chats: chatList, total: chatList.length });
    } catch (error) {
        console.error('[API] Erro ao buscar chats:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Buscar informações do contato - TODOS OS DADOS
app.get('/api/contact/:contactId', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({ success: false, error: 'WhatsApp não está conectado' });
        }

        const { contactId } = req.params;
        const contact = await whatsappClient.getContactById(contactId);

        // Serializa TODOS os dados do contato
        const contactInfo = JSON.parse(JSON.stringify(contact));

        // Busca foto do perfil
        try {
            contactInfo.profilePicUrl = await contact.getProfilePicUrl();
        } catch (err) {
            contactInfo.profilePicUrl = null;
        }

        // Busca about (status/bio)
        try {
            contactInfo.about = await contact.getAbout();
        } catch (err) {
            contactInfo.about = null;
        }

        res.json({ success: true, contact: contactInfo });
    } catch (error) {
        console.error('[API] Erro ao buscar informações do contato:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Buscar mensagens de um chat - TODOS OS DADOS
app.get('/api/messages/:chatId', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({ success: false, error: 'WhatsApp não está conectado' });
        }

        const { chatId } = req.params;
        const limit = parseInt(req.query.limit) || 50;

        const chat = await whatsappClient.getChatById(chatId);
        const messages = await chat.fetchMessages({ limit });

        // Retorna TODOS os campos das mensagens
        const messageList = messages.map(msg => JSON.parse(JSON.stringify(msg)));

        res.json({ success: true, messages: messageList, total: messageList.length });
    } catch (error) {
        console.error('[API] Erro ao buscar mensagens:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Enviar mensagem
app.post('/api/send', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({ success: false, error: 'WhatsApp não está conectado' });
        }

        const { to, message, buttons } = req.body;

        if (!to || !message) {
            return res.status(400).json({ success: false, error: 'Campos "to" e "message" são obrigatórios' });
        }

        // Inicializa contextos se não existir
        if (!global.chatContextos) {
            global.chatContextos = {};
        }

        // Detecta tipo de mensagem pelo conteúdo
        if (message.includes('DESMARCADA por indisponibilidade do profissional')) {
            // Mensagem de desmarcação
            global.chatContextos[to] = 'desmarcacao';
            console.log('[WhatsApp] Contexto salvo: desmarcacao para', to);
        } else if (message.includes('confirmar sua presença') || message.includes('Confirmar presença')) {
            // Mensagem de confirmação de presença
            global.chatContextos[to] = 'confirmacao';
            console.log('[WhatsApp] Contexto salvo: confirmacao para', to);
        }

        let sentMessage;

        // NOTA: WhatsApp descontinuou botões interativos (deprecated)
        // Agora enviamos mensagem simples com instruções de resposta por texto

        // Se tiver botões, converte para texto com opções numeradas
        if (buttons && buttons.length > 0) {
            console.log('[API] Convertendo botões para texto (botões deprecated pelo WhatsApp)');
            console.log('[API] Botões recebidos:', JSON.stringify(buttons));

            // Adiciona opções de resposta ao final da mensagem
            let messageWithOptions = message + '\n\n';
            messageWithOptions += '📝 *Para responder, digite:*\n';
            buttons.forEach((btn) => {
                // Tenta acessar texto de várias formas possíveis
                const textoBtn = btn.texto || btn.text || btn.label || JSON.stringify(btn);
                console.log('[API] Processando botão:', textoBtn);
                messageWithOptions += `${textoBtn}\n`;
            });

            console.log('[API] Mensagem final com botões:', messageWithOptions);
            sentMessage = await whatsappClient.sendMessage(to, messageWithOptions);
            console.log('[API] Mensagem com opções de resposta enviada');
        } else {
            // Mensagem simples sem botões (com formatação Markdown)
            sentMessage = await whatsappClient.sendMessage(to, message);
        }
        res.json({
            success: true,
            messageId: sentMessage.id._serialized,
            timestamp: sentMessage.timestamp
        });
    } catch (error) {
        console.error('[API] Erro ao enviar mensagem:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Marcar chat como lido
app.post('/api/read/:chatId', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({ success: false, error: 'WhatsApp não está conectado' });
        }

        const { chatId } = req.params;
        const chat = await whatsappClient.getChatById(chatId);
        await chat.sendSeen();

        res.json({ success: true });
    } catch (error) {
        console.error('[API] Erro ao marcar como lido:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Recuperar respostas do WhatsApp (para atualização automática dos cards)
app.get('/api/whatsapp/responses', (req, res) => {
    try {
        // Retorna todas as respostas pendentes
        const responses = global.whatsappResponses || [];

        // Limpa array de respostas após retornar (para não processar duplicado)
        global.whatsappResponses = [];

        res.json({
            success: true,
            responses: responses,
            count: responses.length
        });
    } catch (error) {
        console.error('[API] Erro ao recuperar respostas:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Logout
app.post('/api/logout', async (req, res) => {
    try {
        if (whatsappClient) {
            await whatsappClient.logout();
            whatsappClient = null;
            isReady = false;
            qrCodeData = null;
        }
        res.json({ success: true });
    } catch (error) {
        console.error('[API] Erro ao fazer logout:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Download de mídia (imagens, áudios, vídeos, documentos)
app.get('/api/media/:chatId/:messageId', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({ success: false, error: 'WhatsApp não está conectado' });
        }

        const { chatId, messageId } = req.params;

        try {
            // Busca a mensagem diretamente pelo ID
            const chat = await whatsappClient.getChatById(chatId);

            // Tenta buscar mais mensagens para encontrar mensagens antigas
            const messages = await chat.fetchMessages({ limit: 500 });
            const message = messages.find(msg => msg.id._serialized === messageId || msg.id.id === messageId);

            if (!message) {
                // Mídia não encontrada - comum para mensagens muito antigas
                // Retorna 404 silenciosamente (sem log de erro)
                return res.status(404).json({ success: false, error: 'Mensagem não encontrada' });
            }

            if (!message.hasMedia) {
                return res.status(400).json({ success: false, error: 'Mensagem não contém mídia' });
            }

            // Faz download da mídia
            const media = await message.downloadMedia();

            // IMPORTANTE: downloadMedia() retorna undefined quando:
            // - Mídia foi deletada do telefone
            // - Mídia expirou nos servidores do WhatsApp (comum em stickers antigos)
            // - Mídia não está mais disponível para download
            // Fonte: https://wwebjs.dev/guide/creating-your-bot/handling-attachments
            if (!media) {
                // Retorna 404 silenciosamente - comportamento esperado para mídias antigas
                return res.status(404).json({
                    success: false,
                    error: 'Mídia expirada ou não disponível'
                });
            }

            // Converte base64 para buffer
            const buffer = Buffer.from(media.data, 'base64');

            // Define tipo de conteúdo
            res.set('Content-Type', media.mimetype);
            res.set('Content-Length', buffer.length);

            // Envia arquivo
            res.send(buffer);
        } catch (mediaError) {
            // Erro ao processar - retorna 404 silenciosamente para evitar spam de logs
            // Stickers e mídias antigas frequentemente não estão mais disponíveis
            return res.status(404).json({
                success: false,
                error: 'Mídia não disponível'
            });
        }
    } catch (error) {
        console.error('[API] Erro ao baixar mídia:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============================================================================
// NOVOS ENDPOINTS - DADOS COMPLETOS DA API
// ============================================================================

// Obter todos os contatos - TODOS OS DADOS
app.get('/api/contacts', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({ success: false, error: 'WhatsApp não está conectado' });
        }

        const contacts = await whatsappClient.getContacts();

        // Retorna TODOS os campos disponíveis
        const contactList = contacts.slice(0, 50).map(contact => {
            return JSON.parse(JSON.stringify(contact));
        });

        res.json({ success: true, contacts: contactList, total: contacts.length });
    } catch (error) {
        console.error('[API] Erro ao buscar contatos:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Obter contatos bloqueados
app.get('/api/blocked', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({ success: false, error: 'WhatsApp não está conectado' });
        }

        const blocked = await whatsappClient.getBlockedContacts();
        const blockedList = blocked.map(contact => ({
            id: contact.id._serialized,
            number: contact.number,
            name: contact.name || contact.pushname || contact.number
        }));

        res.json({ success: true, blocked: blockedList, total: blocked.length });
    } catch (error) {
        console.error('[API] Erro ao buscar bloqueados:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Obter labels (etiquetas)
app.get('/api/labels', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({ success: false, error: 'WhatsApp não está conectado' });
        }

        const labels = await whatsappClient.getLabels();
        const labelList = labels.map(label => ({
            id: label.id,
            name: label.name,
            color: label.color
        }));

        res.json({ success: true, labels: labelList, total: labels.length });
    } catch (error) {
        console.error('[API] Erro ao buscar labels:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Obter informações do cliente (perfil próprio)
app.get('/api/info', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({ success: false, error: 'WhatsApp não está conectado' });
        }

        const info = whatsappClient.info;
        const profilePic = await whatsappClient.getProfilePicUrl(info.wid._serialized).catch(() => null);

        res.json({
            success: true,
            info: {
                wid: info.wid._serialized,
                pushname: info.pushname,
                phone: info.wid.user,
                platform: info.platform,
                profilePicUrl: profilePic
            }
        });
    } catch (error) {
        console.error('[API] Erro ao buscar info:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Obter estado da conexão
app.get('/api/state', async (req, res) => {
    try {
        if (!whatsappClient) {
            return res.json({ success: true, state: 'DISCONNECTED' });
        }

        const state = await whatsappClient.getState();
        res.json({ success: true, state: state });
    } catch (error) {
        console.error('[API] Erro ao buscar estado:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Buscar mensagens (pesquisa global)
app.get('/api/search', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({ success: false, error: 'WhatsApp não está conectado' });
        }

        const query = req.query.q || '';
        if (!query) {
            return res.status(400).json({ success: false, error: 'Parâmetro "q" é obrigatório' });
        }

        const results = await whatsappClient.searchMessages(query, { limit: 20 });
        const messageList = results.map(msg => ({
            id: msg.id._serialized,
            body: msg.body,
            from: msg.from,
            timestamp: msg.timestamp,
            fromMe: msg.fromMe
        }));

        res.json({ success: true, messages: messageList, total: results.length });
    } catch (error) {
        console.error('[API] Erro ao buscar mensagens:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Obter TODOS os detalhes de um chat específico
app.get('/api/chat/:chatId/full', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({ success: false, error: 'WhatsApp não está conectado' });
        }

        const { chatId } = req.params;
        const chat = await whatsappClient.getChatById(chatId);

        // Serializa todos os dados do chat
        const chatData = JSON.parse(JSON.stringify(chat));

        // Adiciona dados extras se for grupo
        if (chat.isGroup) {
            try {
                // Participantes do grupo
                chatData.participants = chat.participants;

                // Convite do grupo
                try {
                    chatData.inviteCode = await chat.getInviteCode();
                } catch (err) {
                    chatData.inviteCode = null;
                }
            } catch (err) {
                console.error('[API] Erro ao buscar dados do grupo:', err.message);
            }
        }

        // Últimas mensagens (10)
        try {
            const messages = await chat.fetchMessages({ limit: 10 });
            chatData.recentMessages = messages.map(msg => JSON.parse(JSON.stringify(msg)));
        } catch (err) {
            chatData.recentMessages = [];
        }

        res.json({ success: true, chat: chatData });
    } catch (error) {
        console.error('[API] Erro ao buscar detalhes do chat:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Estatísticas gerais
app.get('/api/stats', async (req, res) => {
    try {
        if (!isReady) {
            return res.status(503).json({ success: false, error: 'WhatsApp não está conectado' });
        }

        const chats = await whatsappClient.getChats();
        const contacts = await whatsappClient.getContacts();

        const groups = chats.filter(c => c.isGroup);
        const privateChats = chats.filter(c => !c.isGroup);
        const unreadChats = chats.filter(c => c.unreadCount > 0);
        const totalUnread = chats.reduce((sum, c) => sum + c.unreadCount, 0);
        const archivedChats = chats.filter(c => c.archived);
        const pinnedChats = chats.filter(c => c.pinned);

        res.json({
            success: true,
            stats: {
                totalChats: chats.length,
                groups: groups.length,
                privateChats: privateChats.length,
                unreadChats: unreadChats.length,
                totalUnreadMessages: totalUnread,
                archivedChats: archivedChats.length,
                pinnedChats: pinnedChats.length,
                totalContacts: contacts.length,
                myContacts: contacts.filter(c => c.isMyContact).length
            }
        });
    } catch (error) {
        console.error('[API] Erro ao buscar estatísticas:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Página de diagnóstico do WhatsApp - movida para /api/dashboard
app.get('/api/dashboard', (req, res) => {
    const uptimeSeconds = Math.floor(process.uptime());
    const uptimeMinutes = Math.floor(uptimeSeconds / 60);
    const uptimeHours = Math.floor(uptimeMinutes / 60);
    const memoryUsage = process.memoryUsage();
    const memoryMB = Math.round(memoryUsage.heapUsed / 1024 / 1024);

    res.send(`
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>HMASP Chat - Servidor WhatsApp</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                    padding: 20px;
                }
                .container {
                    max-width: 1200px;
                    margin: 0 auto;
                }
                .header {
                    background: white;
                    padding: 30px;
                    border-radius: 15px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                    margin-bottom: 20px;
                    text-align: center;
                }
                .header h1 {
                    color: #333;
                    font-size: 32px;
                    margin-bottom: 10px;
                }
                .header .subtitle {
                    color: #666;
                    font-size: 16px;
                }
                .status-card {
                    background: white;
                    padding: 25px;
                    border-radius: 15px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                    margin-bottom: 20px;
                }
                .status-indicator {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: 15px;
                    font-size: 28px;
                    font-weight: bold;
                    padding: 20px;
                    border-radius: 10px;
                    margin-bottom: 20px;
                    ${isReady
                        ? 'background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white;'
                        : 'background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white;'}
                }
                .qr-section {
                    background: #f9fafb;
                    padding: 30px;
                    border-radius: 10px;
                    text-align: center;
                    margin-top: 20px;
                }
                .qr-code {
                    background: white;
                    padding: 20px;
                    border-radius: 10px;
                    display: inline-block;
                    margin-top: 15px;
                }
                .qr-code img {
                    max-width: 300px;
                    display: block;
                }
                .info-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 15px;
                    margin-top: 20px;
                }
                .info-item {
                    background: #f9fafb;
                    padding: 15px;
                    border-radius: 10px;
                    border-left: 4px solid #667eea;
                }
                .info-item strong {
                    display: block;
                    color: #666;
                    font-size: 12px;
                    text-transform: uppercase;
                    margin-bottom: 5px;
                }
                .info-item span {
                    color: #333;
                    font-size: 18px;
                    font-weight: 600;
                }
                .links {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 12px;
                    margin-top: 20px;
                }
                .link-card {
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    padding: 20px;
                    border-radius: 10px;
                    text-decoration: none;
                    display: flex;
                    align-items: center;
                    gap: 15px;
                    transition: transform 0.2s;
                }
                .link-card:hover {
                    transform: translateY(-5px);
                }
                .link-card .icon {
                    font-size: 32px;
                }
                .link-card .text h3 {
                    font-size: 15px;
                    margin-bottom: 5px;
                }
                .link-card .text p {
                    font-size: 12px;
                    opacity: 0.9;
                }
                .instructions {
                    background: #fef3c7;
                    border-left: 4px solid #f59e0b;
                    padding: 20px;
                    border-radius: 10px;
                    margin-top: 20px;
                }
                .instructions h3 {
                    color: #92400e;
                    margin-bottom: 10px;
                }
                .instructions ol {
                    color: #78350f;
                    margin-left: 20px;
                    line-height: 1.8;
                }
                .footer {
                    text-align: center;
                    color: white;
                    margin-top: 30px;
                    opacity: 0.8;
                }
                .api-panel {
                    background: #f9fafb;
                    border-radius: 10px;
                    margin-top: 15px;
                    overflow: hidden;
                    max-height: 0;
                    transition: max-height 0.3s ease-out;
                }
                .api-panel.active {
                    max-height: 600px;
                    border: 2px solid #667eea;
                }
                .api-content {
                    padding: 20px;
                }
                .json-viewer {
                    background: #1e293b;
                    color: #e2e8f0;
                    padding: 15px;
                    border-radius: 8px;
                    font-family: 'Courier New', monospace;
                    font-size: 13px;
                    max-height: 400px;
                    overflow: auto;
                    white-space: pre-wrap;
                    word-wrap: break-word;
                }
                .toggle-btn {
                    background: none;
                    border: none;
                    color: inherit;
                    width: 100%;
                    cursor: pointer;
                }
                .data-grid {
                    display: grid;
                    gap: 10px;
                    margin-top: 15px;
                }
                .data-row {
                    background: white;
                    padding: 12px;
                    border-radius: 8px;
                    border-left: 3px solid #667eea;
                    display: grid;
                    grid-template-columns: 150px 1fr;
                    gap: 10px;
                }
                .data-row strong {
                    color: #666;
                    font-size: 13px;
                }
                .data-row span {
                    color: #333;
                    font-size: 14px;
                }
                .loading {
                    text-align: center;
                    color: #666;
                    padding: 20px;
                }
            </style>
            <script>
                // Toggle panels
                function togglePanel(panelId) {
                    const panel = document.getElementById(panelId);
                    const allPanels = document.querySelectorAll('.api-panel');

                    // Fecha outros painéis
                    allPanels.forEach(p => {
                        if (p.id !== panelId) p.classList.remove('active');
                    });

                    // Toggle este painel
                    panel.classList.toggle('active');

                    // Carrega dados se estiver abrindo
                    if (panel.classList.contains('active')) {
                        loadPanelData(panelId);
                    }
                }

                // Carrega dados do painel
                async function loadPanelData(panelId) {
                    const content = document.getElementById(panelId + '-content');
                    content.innerHTML = '<div class="loading">⏳ Carregando dados...</div>';

                    try {
                        let data, html;

                        if (panelId === 'status-panel') {
                            const response = await fetch('/api/status');
                            data = await response.json();
                            html = \`
                                <div class="data-grid">
                                    <div class="data-row">
                                        <strong>Status:</strong>
                                        <span>\${data.isReady ? '✅ Conectado' : '❌ Desconectado'}</span>
                                    </div>
                                    <div class="data-row">
                                        <strong>Tem QR Code:</strong>
                                        <span>\${data.hasQr ? '✅ Sim' : '❌ Não'}</span>
                                    </div>
                                    <div class="data-row">
                                        <strong>Timestamp:</strong>
                                        <span>\${new Date(data.timestamp).toLocaleString('pt-BR')}</span>
                                    </div>
                                </div>
                                <h4 style="margin-top: 20px; margin-bottom: 10px;">📄 JSON Completo:</h4>
                                <div class="json-viewer">\${JSON.stringify(data, null, 2)}</div>
                            \`;
                        } else if (panelId === 'info-panel') {
                            const response = await fetch('/api/info');
                            data = await response.json();

                            if (data.success && data.info) {
                                const info = data.info;
                                html = \`
                                    \${info.profilePicUrl ? \`<div style="text-align: center; margin-bottom: 20px;"><img src="\${info.profilePicUrl}" style="width: 150px; height: 150px; border-radius: 50%; border: 3px solid #667eea;"></div>\` : ''}
                                    <div class="data-grid">
                                        <div class="data-row">
                                            <strong>Nome:</strong>
                                            <span>\${info.pushname}</span>
                                        </div>
                                        <div class="data-row">
                                            <strong>Telefone:</strong>
                                            <span>\${info.phone}</span>
                                        </div>
                                        <div class="data-row">
                                            <strong>ID WhatsApp:</strong>
                                            <span>\${info.wid}</span>
                                        </div>
                                        <div class="data-row">
                                            <strong>Plataforma:</strong>
                                            <span>\${info.platform}</span>
                                        </div>
                                    </div>
                                    <h4 style="margin-top: 20px; margin-bottom: 10px;">📄 JSON Completo:</h4>
                                    <div class="json-viewer">\${JSON.stringify(data.info, null, 2)}</div>
                                \`;
                            } else {
                                html = '<div class="loading">❌ WhatsApp não conectado</div>';
                            }
                        } else if (panelId === 'stats-panel') {
                            const response = await fetch('/api/stats');
                            data = await response.json();

                            if (data.success && data.stats) {
                                const s = data.stats;
                                html = \`
                                    <h3 style="margin-bottom: 15px;">📊 Estatísticas Gerais</h3>
                                    <div class="data-grid">
                                        <div class="data-row">
                                            <strong>Total de Chats:</strong>
                                            <span>\${s.totalChats}</span>
                                        </div>
                                        <div class="data-row">
                                            <strong>Grupos:</strong>
                                            <span>\${s.groups}</span>
                                        </div>
                                        <div class="data-row">
                                            <strong>Chats Privados:</strong>
                                            <span>\${s.privateChats}</span>
                                        </div>
                                        <div class="data-row">
                                            <strong>Chats Não Lidos:</strong>
                                            <span>\${s.unreadChats}</span>
                                        </div>
                                        <div class="data-row">
                                            <strong>Mensagens Não Lidas:</strong>
                                            <span>\${s.totalUnreadMessages}</span>
                                        </div>
                                        <div class="data-row">
                                            <strong>Chats Arquivados:</strong>
                                            <span>\${s.archivedChats}</span>
                                        </div>
                                        <div class="data-row">
                                            <strong>Chats Fixados:</strong>
                                            <span>\${s.pinnedChats}</span>
                                        </div>
                                        <div class="data-row">
                                            <strong>Total de Contatos:</strong>
                                            <span>\${s.totalContacts}</span>
                                        </div>
                                        <div class="data-row">
                                            <strong>Meus Contatos:</strong>
                                            <span>\${s.myContacts}</span>
                                        </div>
                                    </div>
                                    <h4 style="margin-top: 20px; margin-bottom: 10px;">📄 JSON Completo:</h4>
                                    <div class="json-viewer">\${JSON.stringify(data.stats, null, 2)}</div>
                                \`;
                            } else {
                                html = '<div class="loading">❌ WhatsApp não conectado</div>';
                            }
                        } else if (panelId === 'chats-panel') {
                            const response = await fetch('/api/chats');
                            data = await response.json();

                            if (data.success && data.chats && data.chats.length > 0) {
                                const chatsHtml = data.chats.slice(0, 20).map((chat, i) => \`
                                    <div class="data-row">
                                        <strong>\${chat.isGroup ? '👥' : '👤'} Chat \${i + 1}:</strong>
                                        <span>\${chat.name || chat.id} \${chat.unreadCount > 0 ? '(' + chat.unreadCount + ' não lidas)' : ''}</span>
                                    </div>
                                \`).join('');

                                html = \`
                                    <h3 style="margin-bottom: 15px;">💬 Conversas (20 primeiras de \${data.chats.length})</h3>
                                    <div class="data-grid">\${chatsHtml}</div>
                                    <h4 style="margin-top: 20px; margin-bottom: 10px;">📄 JSON Completo:</h4>
                                    <div class="json-viewer">\${JSON.stringify(data.chats.slice(0, 20), null, 2)}</div>
                                \`;
                            } else {
                                html = '<div class="loading">❌ Nenhum chat encontrado ou WhatsApp não conectado</div>';
                            }
                        } else if (panelId === 'contacts-panel') {
                            const response = await fetch('/api/contacts');
                            data = await response.json();

                            if (data.success && data.contacts && data.contacts.length > 0) {
                                const contactsHtml = data.contacts.map((contact, i) => \`
                                    <div class="data-row">
                                        <strong>\${contact.isMyContact ? '📇' : '👤'} Contato \${i + 1}:</strong>
                                        <span>\${contact.name} (\${contact.number || contact.id})</span>
                                    </div>
                                \`).join('');

                                html = \`
                                    <h3 style="margin-bottom: 15px;">👥 Contatos (50 primeiros de \${data.total})</h3>
                                    <div class="data-grid">\${contactsHtml}</div>
                                    <h4 style="margin-top: 20px; margin-bottom: 10px;">📄 JSON Completo:</h4>
                                    <div class="json-viewer">\${JSON.stringify(data.contacts, null, 2)}</div>
                                \`;
                            } else {
                                html = '<div class="loading">❌ Nenhum contato encontrado ou WhatsApp não conectado</div>';
                            }
                        } else if (panelId === 'labels-panel') {
                            const response = await fetch('/api/labels');
                            data = await response.json();

                            if (data.success && data.labels && data.labels.length > 0) {
                                const labelsHtml = data.labels.map((label, i) => \`
                                    <div class="data-row">
                                        <strong>🏷️ Label \${i + 1}:</strong>
                                        <span>\${label.name} <span style="display: inline-block; width: 20px; height: 20px; background: \${label.color || '#ccc'}; border-radius: 3px; vertical-align: middle;"></span></span>
                                    </div>
                                \`).join('');

                                html = \`
                                    <h3 style="margin-bottom: 15px;">🏷️ Etiquetas (\${data.total})</h3>
                                    <div class="data-grid">\${labelsHtml}</div>
                                    <h4 style="margin-top: 20px; margin-bottom: 10px;">📄 JSON Completo:</h4>
                                    <div class="json-viewer">\${JSON.stringify(data.labels, null, 2)}</div>
                                \`;
                            } else {
                                html = '<div class="loading">❌ Nenhuma etiqueta encontrada ou WhatsApp não conectado</div>';
                            }
                        } else if (panelId === 'blocked-panel') {
                            const response = await fetch('/api/blocked');
                            data = await response.json();

                            if (data.success && data.blocked && data.blocked.length > 0) {
                                const blockedHtml = data.blocked.map((contact, i) => \`
                                    <div class="data-row">
                                        <strong>🚫 Bloqueado \${i + 1}:</strong>
                                        <span>\${contact.name} (\${contact.number || contact.id})</span>
                                    </div>
                                \`).join('');

                                html = \`
                                    <h3 style="margin-bottom: 15px;">🚫 Contatos Bloqueados (\${data.total})</h3>
                                    <div class="data-grid">\${blockedHtml}</div>
                                    <h4 style="margin-top: 20px; margin-bottom: 10px;">📄 JSON Completo:</h4>
                                    <div class="json-viewer">\${JSON.stringify(data.blocked, null, 2)}</div>
                                \`;
                            } else {
                                html = '<div class="loading">✅ Nenhum contato bloqueado</div>';
                            }
                        } else if (panelId === 'state-panel') {
                            const response = await fetch('/api/state');
                            data = await response.json();

                            const stateEmoji = {
                                'CONNECTED': '✅',
                                'OPENING': '🔄',
                                'PAIRING': '⏳',
                                'TIMEOUT': '⏱️',
                                'CONFLICT': '⚠️',
                                'UNLAUNCHED': '🔌',
                                'PROXYBLOCK': '🚫',
                                'TOS_BLOCK': '⛔',
                                'SMB_TOS_BLOCK': '⛔',
                                'DISCONNECTED': '❌'
                            };

                            html = \`
                                <div class="data-grid">
                                    <div class="data-row">
                                        <strong>Estado da Conexão:</strong>
                                        <span>\${stateEmoji[data.state] || '❓'} \${data.state}</span>
                                    </div>
                                </div>
                                <h4 style="margin-top: 20px; margin-bottom: 10px;">📖 Possíveis Estados:</h4>
                                <div class="data-grid">
                                    <div class="data-row"><strong>CONNECTED:</strong><span>✅ Conectado</span></div>
                                    <div class="data-row"><strong>OPENING:</strong><span>🔄 Abrindo conexão</span></div>
                                    <div class="data-row"><strong>PAIRING:</strong><span>⏳ Pareando dispositivo</span></div>
                                    <div class="data-row"><strong>DISCONNECTED:</strong><span>❌ Desconectado</span></div>
                                    <div class="data-row"><strong>CONFLICT:</strong><span>⚠️ Conflito (outro dispositivo)</span></div>
                                </div>
                                <h4 style="margin-top: 20px; margin-bottom: 10px;">📄 JSON Completo:</h4>
                                <div class="json-viewer">\${JSON.stringify(data, null, 2)}</div>
                            \`;
                        }

                        content.innerHTML = html;
                    } catch (error) {
                        content.innerHTML = \`<div class="loading">❌ Erro ao carregar: \${error.message}</div>\`;
                    }
                }

                // Atualiza status a cada 3 segundos
                setInterval(async () => {
                    try {
                        const response = await fetch('/api/status');
                        const data = await response.json();

                        const statusEl = document.getElementById('status-indicator');
                        const qrSection = document.getElementById('qr-section');

                        if (data.isReady) {
                            statusEl.innerHTML = '✅ WhatsApp Conectado e Pronto';
                            statusEl.style.background = 'linear-gradient(135deg, #10b981 0%, #059669 100%)';
                            if (qrSection) qrSection.style.display = 'none';
                        } else if (data.hasQr) {
                            statusEl.innerHTML = '⏳ Aguardando Conexão - Escaneie o QR Code';
                            statusEl.style.background = 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)';
                            if (qrSection) qrSection.style.display = 'block';

                            // Atualiza QR Code
                            const qrResponse = await fetch('/api/qr');
                            const qrData = await qrResponse.json();
                            if (qrData.qr) {
                                document.getElementById('qr-img').src = qrData.qr;
                            }
                        } else {
                            statusEl.innerHTML = '🔄 Inicializando WhatsApp...';
                            statusEl.style.background = 'linear-gradient(135deg, #6b7280 0%, #4b5563 100%)';
                        }
                    } catch (error) {
                        console.error('Erro ao atualizar status:', error);
                    }
                }, 3000);
            </script>
        </head>
        <body>
            <div class="container">
                <!-- Header -->
                <div class="header">
                    <h1>📱 HMASP Chat - Servidor WhatsApp</h1>
                    <p class="subtitle">Servidor Local - HMASP São Paulo</p>
                </div>

                <!-- Status -->
                <div class="status-card">
                    <div class="status-indicator" id="status-indicator">
                        ${isReady ? '✅ WhatsApp Conectado e Pronto' : (qrCodeData ? '⏳ Aguardando Conexão - Escaneie o QR Code' : '🔄 Inicializando WhatsApp...')}
                    </div>

                    <!-- QR Code Section -->
                    ${!isReady && qrCodeData ? `
                    <div class="qr-section" id="qr-section">
                        <h3>📲 Conectar WhatsApp</h3>
                        <p>Abra o WhatsApp no celular e escaneie o código abaixo:</p>
                        <div class="qr-code">
                            <img id="qr-img" src="${qrCodeData}" alt="QR Code WhatsApp">
                        </div>
                        <div class="instructions">
                            <h3>Como Conectar:</h3>
                            <ol>
                                <li>Abra o <strong>WhatsApp</strong> no seu celular</li>
                                <li>Toque em <strong>Menu (⋮)</strong> ou <strong>Configurações</strong></li>
                                <li>Toque em <strong>Aparelhos Conectados</strong></li>
                                <li>Toque em <strong>Conectar um aparelho</strong></li>
                                <li><strong>Escaneie o QR Code</strong> acima</li>
                            </ol>
                        </div>
                    </div>
                    ` : ''}

                    <!-- Info Grid -->
                    <div class="info-grid">
                        <div class="info-item">
                            <strong>Porta</strong>
                            <span>localhost:3000</span>
                        </div>
                        <div class="info-item">
                            <strong>Tempo Online</strong>
                            <span>${uptimeHours}h ${uptimeMinutes % 60}m</span>
                        </div>
                        <div class="info-item">
                            <strong>Memória</strong>
                            <span>${memoryMB} MB</span>
                        </div>
                        <div class="info-item">
                            <strong>Node.js</strong>
                            <span>${process.version}</span>
                        </div>
                    </div>
                </div>

                <!-- Dados da API -->
                <div class="status-card">
                    <h2 style="margin-bottom: 15px;">📊 Visualizar TODOS os Dados da API WhatsApp</h2>
                    <p style="color: #666; margin-bottom: 15px; font-size: 14px;">⚠️ Agora retornando TODOS os campos disponíveis de cada objeto (sem filtros)</p>
                    <div class="links">
                        <a href="http://localhost:5173" class="link-card" target="_blank">
                            <div class="icon">🌐</div>
                            <div class="text">
                                <h3>Interface Web</h3>
                                <p>Abrir aplicação (nova aba)</p>
                            </div>
                        </a>
                        <button class="link-card toggle-btn" onclick="togglePanel('status-panel')">
                            <div class="icon">📊</div>
                            <div class="text">
                                <h3>Status</h3>
                                <p>Status da conexão</p>
                            </div>
                        </button>
                        <button class="link-card toggle-btn" onclick="togglePanel('info-panel')">
                            <div class="icon">👤</div>
                            <div class="text">
                                <h3>Meu Perfil</h3>
                                <p>Dados do perfil conectado</p>
                            </div>
                        </button>
                        <button class="link-card toggle-btn" onclick="togglePanel('stats-panel')">
                            <div class="icon">📈</div>
                            <div class="text">
                                <h3>Estatísticas</h3>
                                <p>Resumo geral dos dados</p>
                            </div>
                        </button>
                        <button class="link-card toggle-btn" onclick="togglePanel('chats-panel')">
                            <div class="icon">💬</div>
                            <div class="text">
                                <h3>Conversas</h3>
                                <p>Lista de chats ativos</p>
                            </div>
                        </button>
                        <button class="link-card toggle-btn" onclick="togglePanel('contacts-panel')">
                            <div class="icon">👥</div>
                            <div class="text">
                                <h3>Contatos</h3>
                                <p>Todos os contatos (50)</p>
                            </div>
                        </button>
                        <button class="link-card toggle-btn" onclick="togglePanel('labels-panel')">
                            <div class="icon">🏷️</div>
                            <div class="text">
                                <h3>Etiquetas</h3>
                                <p>Labels do WhatsApp</p>
                            </div>
                        </button>
                        <button class="link-card toggle-btn" onclick="togglePanel('blocked-panel')">
                            <div class="icon">🚫</div>
                            <div class="text">
                                <h3>Bloqueados</h3>
                                <p>Contatos bloqueados</p>
                            </div>
                        </button>
                        <button class="link-card toggle-btn" onclick="togglePanel('state-panel')">
                            <div class="icon">🔗</div>
                            <div class="text">
                                <h3>Estado</h3>
                                <p>Estado da conexão</p>
                            </div>
                        </button>
                    </div>

                    <!-- Painel Status -->
                    <div id="status-panel" class="api-panel">
                        <div class="api-content" id="status-panel-content">
                            <div class="loading">Carregando...</div>
                        </div>
                    </div>

                    <!-- Painel Info (Perfil) -->
                    <div id="info-panel" class="api-panel">
                        <div class="api-content" id="info-panel-content">
                            <div class="loading">Carregando...</div>
                        </div>
                    </div>

                    <!-- Painel Estatísticas -->
                    <div id="stats-panel" class="api-panel">
                        <div class="api-content" id="stats-panel-content">
                            <div class="loading">Carregando...</div>
                        </div>
                    </div>

                    <!-- Painel Chats -->
                    <div id="chats-panel" class="api-panel">
                        <div class="api-content" id="chats-panel-content">
                            <div class="loading">Carregando...</div>
                        </div>
                    </div>

                    <!-- Painel Contatos -->
                    <div id="contacts-panel" class="api-panel">
                        <div class="api-content" id="contacts-panel-content">
                            <div class="loading">Carregando...</div>
                        </div>
                    </div>

                    <!-- Painel Labels -->
                    <div id="labels-panel" class="api-panel">
                        <div class="api-content" id="labels-panel-content">
                            <div class="loading">Carregando...</div>
                        </div>
                    </div>

                    <!-- Painel Bloqueados -->
                    <div id="blocked-panel" class="api-panel">
                        <div class="api-content" id="blocked-panel-content">
                            <div class="loading">Carregando...</div>
                        </div>
                    </div>

                    <!-- Painel Estado -->
                    <div id="state-panel" class="api-panel">
                        <div class="api-content" id="state-panel-content">
                            <div class="loading">Carregando...</div>
                        </div>
                    </div>
                </div>

                <!-- Footer -->
                <div class="footer">
                    <p>Hospital Militar de Área de São Paulo</p>
                    <p style="font-size: 14px; margin-top: 5px;">Central de Regulação - Marcação de Consultas</p>
                </div>
            </div>
        </body>
        </html>
    `);
});

// ============================================================================
// ROTAS AGHUSE - Integração com Banco de Dados
// ============================================================================

// Testar conexão com AGHUse
app.get('/api/aghuse/test-connection', async (req, res) => {
    try {
        console.log('[AGHUse] Testando conexão...');
        const result = await aghuse.testConnection();
        res.json(result);
    } catch (error) {
        console.error('[AGHUse] Erro ao testar conexão:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Buscar consultas marcadas recentemente
app.get('/api/aghuse/recent-appointments', async (req, res) => {
    try {
        const minutes = parseInt(req.query.minutes) || 5;
        const offset = parseInt(req.query.offset) || 0;
        const limit = parseInt(req.query.limit) || 100;
        console.log(`[AGHUse] Buscando consultas dos últimos ${minutes} minutos (offset: ${offset}, limit: ${limit})...`);

        const appointments = await aghuse.fetchRecentlyScheduledAppointments(minutes, { offset, limit });
        res.json({
            success: true,
            count: appointments.length,
            offset,
            limit,
            hasMore: appointments.length === limit,  // Se retornou limite completo, pode ter mais
            appointments
        });
    } catch (error) {
        console.error('[AGHUse] Erro ao buscar consultas:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Buscar consultas desmarcadas recentemente
app.get('/api/aghuse/recent-cancellations', async (req, res) => {
    try {
        const minutes = parseInt(req.query.minutes) || 60;
        console.log(`[AGHUse] Buscando cancelamentos dos últimos ${minutes} minutos...`);

        const cancellations = await aghuse.fetchRecentlyCancelledAppointments(minutes);
        res.json({
            success: true,
            count: cancellations.length,
            cancellations
        });
    } catch (error) {
        console.error('[AGHUse] Erro ao buscar cancelamentos:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Alias para cancelled-appointments (compatibilidade com frontend)
app.get('/api/aghuse/cancelled-appointments', async (req, res) => {
    try {
        const minutes = parseInt(req.query.minutes) || 60;
        const offset = parseInt(req.query.offset) || 0;
        const limit = parseInt(req.query.limit) || 100;
        console.log(`[AGHUse] Buscando cancelamentos dos últimos ${minutes} minutos (offset: ${offset}, limit: ${limit})...`);

        const appointments = await aghuse.fetchRecentlyCancelledAppointments(minutes, { offset, limit });
        res.json({
            success: true,
            count: appointments.length,
            offset,
            limit,
            hasMore: appointments.length === limit,  // Se retornou limite completo, pode ter mais
            appointments  // IMPORTANTE: frontend espera "appointments", não "cancellations"
        });
    } catch (error) {
        console.error('[AGHUse] Erro ao buscar cancelamentos:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Buscar consultas para lembrete 72h
app.get('/api/aghuse/appointments-72h', async (req, res) => {
    try {
        console.log('[AGHUse] Buscando consultas para lembrete 72h...');

        const appointments = await aghuse.fetchAppointmentsIn72Hours();
        res.json({
            success: true,
            count: appointments.length,
            appointments
        });
    } catch (error) {
        console.error('[AGHUse] Erro ao buscar consultas 72h:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============================================================================
// DATABASE - Endpoints de Monitoramento (PostgreSQL Local)
// ============================================================================

// Estado do monitoramento (em memória por enquanto, pode migrar para PostgreSQL depois)
let monitoramentoState = {
    ativo: false,
    ultimaVerificacao: null,
    totalEnviadas: 0,
    totalFalhas: 0
};

const consultasProcessadas = new Map(); // consultaNumero -> { status, detalhes, timestamp }

// GET /api/database/monitoramento/state - Obtém estado do monitoramento
app.get('/api/database/monitoramento/state', (req, res) => {
    res.json({
        success: true,
        state: monitoramentoState
    });
});

// POST /api/database/monitoramento/state - Salva estado do monitoramento
app.post('/api/database/monitoramento/state', (req, res) => {
    const { ativo, ultimaVerificacao, totalEnviadas, totalFalhas } = req.body;

    monitoramentoState = {
        ativo: ativo !== undefined ? ativo : monitoramentoState.ativo,
        ultimaVerificacao: ultimaVerificacao || monitoramentoState.ultimaVerificacao,
        totalEnviadas: totalEnviadas !== undefined ? totalEnviadas : monitoramentoState.totalEnviadas,
        totalFalhas: totalFalhas !== undefined ? totalFalhas : monitoramentoState.totalFalhas
    };

    console.log('[Database] Estado do monitoramento salvo:', monitoramentoState);

    res.json({
        success: true,
        state: monitoramentoState
    });
});

// POST /api/database/monitoramento/consulta - Registra consulta processada
app.post('/api/database/monitoramento/consulta', (req, res) => {
    const { consultaNumero, status, detalhes } = req.body;

    consultasProcessadas.set(consultaNumero, {
        status,
        detalhes,
        timestamp: new Date().toISOString()
    });

    console.log(`[Database] Consulta ${consultaNumero} registrada como ${status}`);

    res.json({ success: true });
});

// GET /api/database/monitoramento/consulta/:numero - Verifica se consulta foi processada
app.get('/api/database/monitoramento/consulta/:numero', (req, res) => {
    const { numero } = req.params;
    const processada = consultasProcessadas.has(numero);

    res.json({
        success: true,
        processada,
        dados: processada ? consultasProcessadas.get(numero) : null
    });
});

// POST /api/database/monitoramento/consultas/filtrar - Filtra consultas não processadas
app.post('/api/database/monitoramento/consultas/filtrar', (req, res) => {
    const { consultas } = req.body;

    const naoProcessadas = consultas.filter(c => !consultasProcessadas.has(c.numero));

    res.json({
        success: true,
        total: consultas.length,
        naoProcessadasCount: naoProcessadas.length,
        naoProcessadas
    });
});

// GET /api/database/monitoramento/stats - Estatísticas
app.get('/api/database/monitoramento/stats', (req, res) => {
    res.json({
        success: true,
        stats: {
            totalProcessadas: consultasProcessadas.size,
            totalEnviadas: monitoramentoState.totalEnviadas,
            totalFalhas: monitoramentoState.totalFalhas,
            ultimaVerificacao: monitoramentoState.ultimaVerificacao
        }
    });
});

// DELETE /api/database/monitoramento/reset - Reseta monitoramento
app.delete('/api/database/monitoramento/reset', (req, res) => {
    consultasProcessadas.clear();
    monitoramentoState = {
        ativo: false,
        ultimaVerificacao: null,
        totalEnviadas: 0,
        totalFalhas: 0
    };

    console.log('[Database] Monitoramento resetado');

    res.json({ success: true });
});

// POST /api/database/monitoramento/clear - Limpa banco (alias do reset)
app.post('/api/database/monitoramento/clear', (req, res) => {
    consultasProcessadas.clear();
    console.log('[Database] Banco limpo');
    res.json({ success: true });
});

// ============================================================================
// ADMIN - Endpoint de Atualização Remota
// ============================================================================

// Endpoint de emergência para configurar Git (bootstrap)
app.post('/api/fix-git', async (req, res) => {
    const { exec } = require('child_process');
    const { promisify } = require('util');
    const execAsync = promisify(exec);

    console.log('[FIX-GIT] 🔧 Configurando Git...');

    try {
        const command = 'sudo -u sistema-whats git config --global --add safe.directory /opt/hmasp/hmasp-chat-v2';
        console.log('[FIX-GIT] Executando:', command);

        const { stdout, stderr } = await execAsync(command, {
            cwd: '/opt/hmasp/hmasp-chat-v2',
            timeout: 10000
        });

        res.json({
            success: true,
            message: 'Git configurado! Agora pode usar /api/force-update',
            output: stdout || 'OK',
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message,
            stderr: error.stderr,
            stdout: error.stdout
        });
    }
});

// Endpoint de força-bruta para bootstrap inicial
app.post('/api/force-update', async (req, res) => {
    const { exec } = require('child_process');
    const { promisify } = require('util');
    const execAsync = promisify(exec);

    console.log('[FORCE-UPDATE] 🚀 Recebida solicitação de atualização forçada!');
    console.log('[FORCE-UPDATE] Data/Hora:', new Date().toISOString());

    try {
        // Comandos de atualização forçada (executar como usuário sistema-whats)
        const commands = [
            'cd /opt/hmasp/hmasp-chat-v2',
            'sudo -u sistema-whats git config --global --add safe.directory /opt/hmasp/hmasp-chat-v2',
            'sudo -u sistema-whats git fetch origin',
            'sudo -u sistema-whats git reset --hard origin/main',
            'sudo -u sistema-whats npm install',
            'sudo -u sistema-whats npm run build'
        ];

        const command = commands.join(' && ');
        console.log('[FORCE-UPDATE] Executando:', command);

        const { stdout, stderr } = await execAsync(command, {
            cwd: __dirname,
            timeout: 180000, // 3 minutos
            maxBuffer: 10 * 1024 * 1024 // 10MB
        });

        console.log('[FORCE-UPDATE] ✅ Atualização concluída!');
        if (stdout) console.log('[FORCE-UPDATE] stdout:', stdout);
        if (stderr) console.log('[FORCE-UPDATE] stderr:', stderr);

        // Responder sucesso
        res.json({
            success: true,
            message: 'Sistema atualizado! Reiniciando servidor...',
            output: stdout,
            timestamp: new Date().toISOString()
        });

        // Reiniciar após 2 segundos
        setTimeout(() => {
            console.log('[FORCE-UPDATE] Reiniciando servidor...');
            process.exit(0); // systemd reinicia automaticamente
        }, 2000);

    } catch (error) {
        console.error('[FORCE-UPDATE] ❌ Erro:', error.message);
        res.status(500).json({
            success: false,
            error: error.message,
            stderr: error.stderr,
            stdout: error.stdout,
            timestamp: new Date().toISOString()
        });
    }
});

// ============================================================================
// ENDPOINTS DE DIAGNÓSTICO E CONTROLE REMOTO
// ============================================================================

// GET /api/diagnostic - Diagnóstico completo do sistema
app.get('/api/diagnostic', async (req, res) => {
    const { exec } = require('child_process');
    const { promisify } = require('util');
    const execAsync = promisify(exec);
    const fs = require('fs').promises;

    try {
        const diagnostic = {
            timestamp: new Date().toISOString(),
            server: {},
            git: {},
            frontend: {},
            processes: {}
        };

        // Git status
        try {
            const { stdout: gitLog } = await execAsync('git log -1 --oneline', { cwd: __dirname });
            const { stdout: gitStatus } = await execAsync('git status --porcelain', { cwd: __dirname });
            const { stdout: gitBranch } = await execAsync('git branch --show-current', { cwd: __dirname });

            diagnostic.git = {
                commit: gitLog.trim(),
                branch: gitBranch.trim(),
                modified_files: gitStatus.trim().split('\n').filter(Boolean).length,
                clean: gitStatus.trim() === ''
            };
        } catch (err) {
            diagnostic.git.error = err.message;
        }

        // Frontend dist status
        try {
            const distExists = await fs.access(__dirname + '/dist').then(() => true).catch(() => false);
            if (distExists) {
                const distFiles = await fs.readdir(__dirname + '/dist');
                const assetsExists = await fs.access(__dirname + '/dist/assets').then(() => true).catch(() => false);
                let assetFiles = [];
                if (assetsExists) {
                    assetFiles = await fs.readdir(__dirname + '/dist/assets');
                }

                diagnostic.frontend = {
                    dist_exists: true,
                    dist_files: distFiles.length,
                    assets_files: assetFiles.length,
                    has_index: distFiles.includes('index.html')
                };
            } else {
                diagnostic.frontend = { dist_exists: false };
            }
        } catch (err) {
            diagnostic.frontend.error = err.message;
        }

        // Processos Node
        try {
            const { stdout: processes } = await execAsync('ps aux | grep node | grep -v grep');
            diagnostic.processes = {
                count: processes.trim().split('\n').length,
                details: processes.trim()
            };
        } catch (err) {
            diagnostic.processes = { count: 0 };
        }

        // Config do servidor
        diagnostic.server = {
            port: PORT,
            env: process.env.NODE_ENV || 'production',
            uptime: process.uptime(),
            cwd: __dirname
        };

        res.json({ success: true, diagnostic });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// POST /api/rebuild-frontend - Rebuild apenas do frontend
app.post('/api/rebuild-frontend', async (req, res) => {
    const { exec } = require('child_process');
    const { promisify } = require('util');
    const execAsync = promisify(exec);

    console.log('[REBUILD] Iniciando rebuild do frontend...');

    try {
        const { stdout, stderr } = await execAsync('npm run build', {
            cwd: __dirname,
            timeout: 180000 // 3 minutos
        });

        console.log('[REBUILD] ✅ Build concluído!');
        res.json({
            success: true,
            message: 'Frontend rebuilded com sucesso!',
            output: stdout,
            stderr: stderr
        });
    } catch (error) {
        console.error('[REBUILD] ❌ Erro:', error.message);
        res.status(500).json({
            success: false,
            error: error.message,
            stderr: error.stderr,
            stdout: error.stdout
        });
    }
});

// POST /api/full-sync - Git pull + npm install + build + restart
app.post('/api/full-sync', async (req, res) => {
    const { exec } = require('child_process');
    const { promisify } = require('util');
    const execAsync = promisify(exec);

    console.log('[FULL-SYNC] Iniciando sincronização completa...');

    try {
        const steps = [];

        // Step 1: Git safe directory
        console.log('[FULL-SYNC] Step 1: Configurando Git...');
        await execAsync('git config --global --add safe.directory /opt/hmasp/hmasp-chat-v2');
        steps.push('Git configurado');

        // Step 2: Git pull
        console.log('[FULL-SYNC] Step 2: Git pull...');
        const { stdout: gitOut } = await execAsync('git pull origin main', { cwd: __dirname });
        steps.push('Git pull: ' + gitOut.trim().substring(0, 100));

        // Step 3: npm install
        console.log('[FULL-SYNC] Step 3: npm install...');
        const { stdout: npmOut } = await execAsync('npm install', {
            cwd: __dirname,
            timeout: 120000
        });
        steps.push('npm install concluído');

        // Step 4: build
        console.log('[FULL-SYNC] Step 4: Building frontend...');
        const { stdout: buildOut } = await execAsync('npm run build', {
            cwd: __dirname,
            timeout: 180000
        });
        steps.push('Build concluído');

        console.log('[FULL-SYNC] ✅ Sincronização completa! Reiniciando em 2s...');

        res.json({
            success: true,
            message: 'Sincronização completa! Servidor reiniciando...',
            steps: steps
        });

        // Restart
        setTimeout(() => {
            console.log('[FULL-SYNC] Reiniciando...');
            process.exit(0);
        }, 2000);

    } catch (error) {
        console.error('[FULL-SYNC] ❌ Erro:', error.message);
        res.status(500).json({
            success: false,
            error: error.message,
            stderr: error.stderr,
            stdout: error.stdout
        });
    }
});

app.post('/api/admin/update', async (req, res) => {
    const { exec } = require('child_process');
    const { promisify } = require('util');
    const execAsync = promisify(exec);

    console.log('[ADMIN] Recebida solicitação de atualização...');

    try {
        // Executar comandos de atualização
        const commands = [
            'cd /opt/hmasp/hmasp-chat-v2',
            'git reset --hard',
            'git pull origin main',
            'npm install --production'
        ];

        const command = commands.join(' && ');
        console.log('[ADMIN] Executando:', command);

        const { stdout, stderr } = await execAsync(command, {
            cwd: __dirname,
            timeout: 60000
        });

        console.log('[ADMIN] Atualização concluída com sucesso!');
        console.log('[ADMIN] stdout:', stdout);
        if (stderr) console.log('[ADMIN] stderr:', stderr);

        // Responder antes de reiniciar
        res.json({
            success: true,
            message: 'Atualização concluída! Servidor será reiniciado em 3 segundos...',
            output: stdout
        });

        // Reiniciar servidor após 3 segundos
        setTimeout(() => {
            console.log('[ADMIN] Reiniciando servidor...');
            process.exit(0); // systemd reinicia automaticamente
        }, 3000);

    } catch (error) {
        console.error('[ADMIN] Erro ao atualizar:', error);
        res.status(500).json({
            success: false,
            error: error.message,
            stderr: error.stderr,
            stdout: error.stdout
        });
    }
});

// ============================================================================
// FALLBACK PARA SPA - Todas as rotas não-API servem o index.html
// ============================================================================

app.get('*', (req, res, next) => {
    // Ignora rotas de API e dashboard
    if (req.path.startsWith('/api/')) {
        return next();
    }

    // Serve o index.html do frontend (SPA)
    const indexPath = path.join(__dirname, 'dist', 'index.html');
    res.sendFile(indexPath, (err) => {
        if (err) {
            console.error('[Frontend] Erro ao servir index.html:', err);
            res.status(404).send('Frontend não encontrado. Execute: npm run build');
        }
    });
});

// ============================================================================
// INICIALIZAÇÃO
// ============================================================================

app.listen(PORT, '0.0.0.0', () => {
    console.log('============================================');
    console.log('  HMASP Chat - Servidor WhatsApp');
    console.log('  Localização: HMASP São Paulo');
    console.log('============================================');
    console.log(`Servidor: http://localhost:${PORT}`);
    console.log('============================================');

    // Inicializa WhatsApp
    initializeWhatsApp();
});

// Porta 3001 para compatibilidade temporária
// (Frontend antigo configurado para 3001, mas agora tudo roda em 3000)
app.listen(3001, '0.0.0.0', () => {
    console.log('[INFO] Servidor também escutando na porta 3001 (compatibilidade temporária)');
});

// Tratamento de erros
process.on('uncaughtException', (error) => {
    console.error('[ERRO]', error);
});

process.on('unhandledRejection', (reason) => {
    console.error('[ERRO]', reason);
});
