/**
 * Google Drive Backup Service
 * Backup automático de conversas do WhatsApp
 * Conta: centralderegulacaohmasp@gmail.com
 */

const { google } = require('googleapis');
const fs = require('fs');
const path = require('path');

class GoogleDriveBackup {
    constructor() {
        this.auth = null;
        this.drive = null;
        this.backupFolderId = null;
    }

    /**
     * Inicializa autenticação com Google Drive
     *
     * IMPORTANTE: Para usar este serviço, você precisa:
     * 1. Criar um projeto no Google Cloud Console
     * 2. Ativar a Google Drive API
     * 3. Criar credenciais OAuth 2.0
     * 4. Baixar o arquivo credentials.json
     * 5. Colocar na raiz do projeto como 'google-credentials.json'
     */
    async initialize() {
        try {
            const credentialsPath = path.join(__dirname, '..', 'google-credentials.json');

            // Verifica se existe o arquivo de credenciais
            if (!fs.existsSync(credentialsPath)) {
                console.warn('[Backup] Arquivo google-credentials.json não encontrado');
                console.warn('[Backup] Backup do Google Drive desabilitado');
                console.warn('[Backup] Para habilitar, siga as instruções em google-drive-backup.js');
                return false;
            }

            const credentials = JSON.parse(fs.readFileSync(credentialsPath, 'utf8'));

            // Cria cliente OAuth2
            const { client_secret, client_id, redirect_uris } = credentials.installed || credentials.web;
            const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);

            // Tenta carregar token salvo
            const tokenPath = path.join(__dirname, '..', 'google-token.json');
            if (fs.existsSync(tokenPath)) {
                const token = JSON.parse(fs.readFileSync(tokenPath, 'utf8'));
                oAuth2Client.setCredentials(token);
            } else {
                console.warn('[Backup] Token não encontrado. Execute o script de autenticação primeiro.');
                return false;
            }

            this.auth = oAuth2Client;
            this.drive = google.drive({ version: 'v3', auth: this.auth });

            // Cria ou encontra pasta de backups
            await this.ensureBackupFolder();

            console.log('[Backup] Google Drive inicializado com sucesso');
            return true;
        } catch (error) {
            console.error('[Backup] Erro ao inicializar Google Drive:', error);
            return false;
        }
    }

    /**
     * Garante que a pasta de backups existe no Google Drive
     */
    async ensureBackupFolder() {
        const folderName = 'HMASP_Chat_Backups';

        try {
            // Procura pela pasta
            const response = await this.drive.files.list({
                q: `name='${folderName}' and mimeType='application/vnd.google-apps.folder' and trashed=false`,
                fields: 'files(id, name)',
                spaces: 'drive'
            });

            if (response.data.files.length > 0) {
                // Pasta já existe
                this.backupFolderId = response.data.files[0].id;
                console.log('[Backup] Pasta de backups encontrada:', this.backupFolderId);
            } else {
                // Cria nova pasta
                const fileMetadata = {
                    name: folderName,
                    mimeType: 'application/vnd.google-apps.folder'
                };

                const folder = await this.drive.files.create({
                    resource: fileMetadata,
                    fields: 'id'
                });

                this.backupFolderId = folder.data.id;
                console.log('[Backup] Pasta de backups criada:', this.backupFolderId);
            }
        } catch (error) {
            console.error('[Backup] Erro ao criar/encontrar pasta:', error);
            throw error;
        }
    }

    /**
     * Faz backup das conversas
     * @param {Array} chats - Lista de conversas do WhatsApp
     * @param {Object} whatsappClient - Cliente WhatsApp para buscar mensagens
     */
    async backupConversations(chats, whatsappClient) {
        if (!this.drive || !this.backupFolderId) {
            console.warn('[Backup] Google Drive não inicializado');
            return { success: false, error: 'Google Drive não inicializado' };
        }

        try {
            console.log('[Backup] Iniciando backup de', chats.length, 'conversas...');

            const backupData = {
                timestamp: new Date().toISOString(),
                totalChats: chats.length,
                conversations: []
            };

            // Exporta cada conversa com suas mensagens
            for (const chat of chats) {
                try {
                    // Busca mensagens da conversa (últimas 100)
                    const chatObj = await whatsappClient.getChatById(chat.id);
                    const messages = await chatObj.fetchMessages({ limit: 100 });

                    const conversationData = {
                        id: chat.id,
                        name: chat.name,
                        isGroup: chat.isGroup,
                        timestamp: chat.timestamp,
                        messageCount: messages.length,
                        messages: messages.map(msg => ({
                            id: msg.id._serialized,
                            body: msg.body,
                            timestamp: msg.timestamp,
                            fromMe: msg.fromMe,
                            type: msg.type,
                            contact: {
                                name: msg._data.notifyName || 'Desconhecido',
                                number: msg.from
                            }
                        }))
                    };

                    backupData.conversations.push(conversationData);
                } catch (error) {
                    console.error(`[Backup] Erro ao exportar conversa ${chat.name}:`, error.message);
                }
            }

            // Nome do arquivo com data/hora
            const now = new Date();
            const fileName = `backup_${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}_${String(now.getHours()).padStart(2, '0')}h${String(now.getMinutes()).padStart(2, '0')}.json`;

            // Converte para JSON
            const jsonContent = JSON.stringify(backupData, null, 2);
            const buffer = Buffer.from(jsonContent);

            // Upload para Google Drive
            const fileMetadata = {
                name: fileName,
                parents: [this.backupFolderId]
            };

            const media = {
                mimeType: 'application/json',
                body: require('stream').Readable.from(buffer)
            };

            const file = await this.drive.files.create({
                resource: fileMetadata,
                media: media,
                fields: 'id, name, size'
            });

            console.log('[Backup] Backup salvo com sucesso:', file.data.name);
            console.log('[Backup] Tamanho:', Math.round(file.data.size / 1024), 'KB');

            // Limpa backups antigos (mantém últimos 30 dias)
            await this.cleanOldBackups();

            return {
                success: true,
                fileName: file.data.name,
                fileId: file.data.id,
                size: file.data.size,
                conversationsCount: backupData.conversations.length
            };
        } catch (error) {
            console.error('[Backup] Erro ao fazer backup:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * Remove backups com mais de 30 dias
     */
    async cleanOldBackups() {
        try {
            const thirtyDaysAgo = new Date();
            thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

            // Lista arquivos na pasta de backup
            const response = await this.drive.files.list({
                q: `'${this.backupFolderId}' in parents and trashed=false`,
                fields: 'files(id, name, createdTime)',
                orderBy: 'createdTime desc'
            });

            const files = response.data.files;
            let deletedCount = 0;

            for (const file of files) {
                const fileDate = new Date(file.createdTime);

                if (fileDate < thirtyDaysAgo) {
                    await this.drive.files.delete({ fileId: file.id });
                    console.log('[Backup] Arquivo antigo removido:', file.name);
                    deletedCount++;
                }
            }

            if (deletedCount > 0) {
                console.log(`[Backup] ${deletedCount} backup(s) antigo(s) removido(s)`);
            }
        } catch (error) {
            console.error('[Backup] Erro ao limpar backups antigos:', error);
        }
    }

    /**
     * Lista backups disponíveis
     */
    async listBackups() {
        if (!this.drive || !this.backupFolderId) {
            return { success: false, error: 'Google Drive não inicializado' };
        }

        try {
            const response = await this.drive.files.list({
                q: `'${this.backupFolderId}' in parents and trashed=false`,
                fields: 'files(id, name, size, createdTime)',
                orderBy: 'createdTime desc'
            });

            return {
                success: true,
                backups: response.data.files.map(file => ({
                    id: file.id,
                    name: file.name,
                    size: file.size,
                    createdAt: file.createdTime
                }))
            };
        } catch (error) {
            console.error('[Backup] Erro ao listar backups:', error);
            return { success: false, error: error.message };
        }
    }
}

module.exports = GoogleDriveBackup;
